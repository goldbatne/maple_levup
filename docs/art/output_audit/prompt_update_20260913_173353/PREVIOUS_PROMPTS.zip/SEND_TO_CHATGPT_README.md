# ChatGPT 전달 방법

각 Area는 아래 두 파일만 함께 사용한다.

1. `AREA_XX_IMAGES_INPUT.zip`
2. `AREA_XX_CHATGPT_PRODUCTION_PROMPT.txt`

일반 ChatGPT에서 ZIP을 첨부하고 같은 번호의 prompt 텍스트를 메시지로 보내면 된다. 별도의 장문 설명을 다시 작성할 필요는 없다.

prompt는 다음을 이미 포함한다.

- AREA_MANIFEST와 모든 몬스터 문서의 읽기 순서
- 실제 MONSTER_IMAGE와 스킬 WHAT 고정
- AREA 00 수정 후보의 마감 품질 사용 범위
- MSW 공식 리소스 팩의 역할·프레임 구조 사용 범위
- VFX frame-separated RGBA PNG와 256x256 기본 ICON 규격
- 포스터형 결과, 가짜 alpha, 몬스터 본체, 타 스킬 고유 소재 금지
- 스킬별 품질 게이트, preview, manifest, RESULT_INFO, validation, OUTPUT ZIP 요구

AREA 06은 프로젝트에서 폐기된 지하 하수도 설계이므로 파일이 없다. 현재 운용 Area는 00~05와 07~20이다.

전체 파일 목록과 SHA-256은 `ALL_AREAS_INDEX.md/.csv`, 검증 결과는 `PACKAGE_VALIDATION_REPORT.md/.json`에서 확인한다.
