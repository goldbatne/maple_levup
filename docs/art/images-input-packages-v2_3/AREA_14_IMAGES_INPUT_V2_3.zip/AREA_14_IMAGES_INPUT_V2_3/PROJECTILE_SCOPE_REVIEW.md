# PROJECTILE SCOPE REVIEW — V2.3

All 12 actual monster projectile visual roles are NEW_ART. Engine movement is unchanged; existing projectile RUIDs remain evidence only until approved import.

| Area | monster | skill | current RUID | new files | timing | targeting | impact | future target |
|---|---|---|---|---|---|---|---|---|
| area_14 | `m_roid` | `s_mon_roid` | `e51545cbf94349f59f4431e2e76d2cdc` | `PROJECTILE/004_m_roid_s_mon_roid_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 7 | 0.8 after 0.35s | `projectile_ruid` |
| area_14 | `m_chimera` | `s_mon_chimera` | `ab113d9a5ca5402d85ecc2ab7a4f51a1` | `PROJECTILE/005_m_chimera_s_mon_chimera_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 6.8 | 0.8 after 0.35s | `projectile_ruid` |

- Stumpy has no CAST and remains PROJECTILE+ICON only.
- The other 11 keep their CAST requirement and add an independent PROJECTILE requirement.
- No HIT role is added because ResolveThrowHit has no visual asset field or effect spawn call.
