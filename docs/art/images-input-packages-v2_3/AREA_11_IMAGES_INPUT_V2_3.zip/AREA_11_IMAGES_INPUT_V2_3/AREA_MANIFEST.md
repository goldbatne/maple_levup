# AREA MANIFEST — V2.3

FULL_ART_SCOPE.csv와 OUTPUT_REQUIREMENTS.csv가 역할별 제작 범위 원장이다. 확정 기획/런타임 수치는 V2.2에서 변경하지 않았다.

| order | monster | skill | roles | decisions | production | import | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_ratz` | `s_mon_ratz` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 2 | `m_drumming_bunny` | `s_mon_drumming_bunny` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 3 | `m_bloctopus` | `s_mon_bloctopus` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 4 | `m_king_bloctopus` | `s_mon_king_bloctopus` | ICON|CAST_VFX|PROJECTILE | NEW_ART|NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 5 | `m_rombot` | `s_mon_rombot` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
