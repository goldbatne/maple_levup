# Runtime Role Map — m_faust / s_mon_faust — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/005_m_faust_s_mon_faust_ICON.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/005_m_faust_s_mon_faust_CAST_F00.png..._CAST_F11.png` | 12f / 512x512 RGBA / 0.08 / non-loop one-shot | `layer_ruids` | none |
| PROJECTILE | true · projectile_ruid | NEW_ART | `PROJECTILE/005_m_faust_s_mon_faust_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4f / 512x512 RGBA / 0.08 / non-loop complete playback within 0.35s entity lifetime | `projectile_ruid` | import must author AnimationClip non-loop at 0.08s/frame; Maker runtime not run |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX|PROJECTILE`
- production_decisions: `NEW_ART|NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids|projectile_ruid`
- confirmed design effect preserved: INT 계수 1.55로 반경 4 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: INT 계수 1.55; skill.range=4wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- runtime_motion preserved: skill.range=4wu는 플레이어 조준 거리이며 몬스터 사용 시 2.668wu로 대상 탐색한다. projectile_ruid 49b21aaa1d574ba787149841a31bf1a5를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. L1 delay=0s duration=0.9s offset=(0,0.1)wu drift=(0,0)wu/s; L2 delay=0.18s duration=0.75s offset=(0,0.05)wu drift=(0,0)wu/s.
- targeting_range=4 / impact_radius=0.8 / impact_delay=0.35 / max_targets=unlimited

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
