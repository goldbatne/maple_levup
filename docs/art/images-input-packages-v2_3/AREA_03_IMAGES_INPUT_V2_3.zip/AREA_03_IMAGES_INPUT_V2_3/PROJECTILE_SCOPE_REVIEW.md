# PROJECTILE SCOPE REVIEW — V2.3

All 12 actual monster projectile visual roles are NEW_ART. Engine movement is unchanged; existing projectile RUIDs remain evidence only until approved import.

| Area | monster | skill | current RUID | new files | timing | targeting | impact | future target |
|---|---|---|---|---|---|---|---|---|
| area_03 | `m_faust` | `s_mon_faust` | `49b21aaa1d574ba787149841a31bf1a5` | `PROJECTILE/005_m_faust_s_mon_faust_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 4 | 0.8 after 0.35s | `projectile_ruid` |

- Stumpy has no CAST and remains PROJECTILE+ICON only.
- The other 11 keep their CAST requirement and add an independent PROJECTILE requirement.
- No HIT role is added because ResolveThrowHit has no visual asset field or effect spawn call.
