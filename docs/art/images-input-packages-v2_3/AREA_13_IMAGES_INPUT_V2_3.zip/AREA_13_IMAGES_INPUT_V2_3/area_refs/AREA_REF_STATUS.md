# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t65/nihal`
- 합성 대상: 00_desert_sand.png, 01_wind_sand.png, 02_ruin_slab.png, 03_quicksand.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
