# Monster Reference — 모래난쟁이

- 작업 순번: 004
- level: 128
- Area: `area_13` / 니할 사막
- monster_id: `m_sand_dwarf`
- model_id: `sanddwarf`
- image RUID: `64f166fa4e5445bc982071dea297d988`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_sand_dwarf`
- skill name/type: 사막 대장장이의 체력 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/SandDwarf.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `32508448188d7626b9e291989084bf8fbed9ef1e81c46ebe20f5ffe6f75e3f54`
- image: 320×240 RGBA / alpha 0~255 / bbox [53, 0, 267, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
