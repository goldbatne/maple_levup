# Runtime Role Map — m_sand_dwarf / s_mon_sand_dwarf — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/004_m_sand_dwarf_s_mon_sand_dwarf_ICON.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | input_reference_only · reference source; not runtime field | NEW_ART | `REFERENCE/004_m_sand_dwarf_s_mon_sand_dwarf_REFERENCE_F00.png..._REFERENCE_F05.png` | 6f / 256x256 RGBA / 0.10 / preview-only non-loop | `none` | none |

## Authoritative contract

- required_roles: `ICON|REFERENCE_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|none`
- confirmed design effect preserved: 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2
- runtime_effect preserved: 보유 수량 기반 STR 컬렉션 포인트 계산 후보. GameDataVerify/PlayerStats 지원 여부는 별도 런타임 상태를 따른다.
- runtime_motion preserved: CAST 호출 없음. PlayerStats가 보유 수량을 읽어 스탯을 계산한다. REFERENCE_VFX는 제작 검수용이며 runtime_use=false다.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
