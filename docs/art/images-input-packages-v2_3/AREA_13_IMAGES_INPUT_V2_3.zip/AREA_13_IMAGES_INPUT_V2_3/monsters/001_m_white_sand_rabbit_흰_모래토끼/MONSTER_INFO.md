# Monster Reference — 흰 모래토끼

- 작업 순번: 001
- level: 121
- Area: `area_13` / 니할 사막
- monster_id: `m_white_sand_rabbit`
- model_id: `whitesandrabbit`
- image RUID: `981c64ae30bd4f98aef886e9314d8e64`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_white_sand_rabbit`
- skill name/type: 사막 굴착탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/WhiteSandRabbit.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `de9fd37727b97e83a05143abf6a9d37404d00231217e665262fe9b03a08d893a`
- image: 320×240 RGBA / alpha 0~255 / bbox [38, 14, 278, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
