# Monster Reference — 미요캐츠

- 작업 순번: 003
- level: 125
- Area: `area_13` / 니할 사막
- monster_id: `m_meercat`
- model_id: `meercat`
- image RUID: `fc3c2944ce44425c8d7f302a8610b886`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_meercat`
- skill name/type: 미요캐츠의 모래매복 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Meercat.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a6c5101d1db03e24fce39cf19bc9ace7670b47a2e99960863a6dc69d849cd87b`
- image: 320×240 RGBA / alpha 0~255 / bbox [92, 7, 222, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
