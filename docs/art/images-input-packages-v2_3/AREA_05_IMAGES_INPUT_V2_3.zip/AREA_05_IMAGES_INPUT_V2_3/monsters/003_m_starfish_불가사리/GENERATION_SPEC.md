# GENERATION SPEC — 불가사리 / 별가시 회전

## 확정 데이터

- 작업 순번: 003
- 레벨: 45
- Area: `area_05` / 노틸러스
- monster_id: `m_starfish`
- 몬스터 이름: 불가사리
- monster image RUID: `03351051e9e54fca87469eaa47c5398b`
- skill_id: `s_mon_starfish`
- 최종 스킬 이름: **별가시 회전**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): ATK 계수 1.95로 반경 4 범위 최대 3대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.55s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.06s duration=0.68s offset=(0,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 불가사리의 모델 ID·RUID와 노틸러스 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 별 모양 가시가 회전하며 남기는 다섯 갈래 수중 잔상. ‘불가사리 / 별가시 회전’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 불가사리 주황 #F39B45; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 바닷물 청록 #5CC8C4; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=69656381a8e04edcbb8a2c8599567ab3, type=animationclip, style=clip, delay=0s, duration=0.55s, scale=0.55, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=2c12c1e835a04c2a9ec1c5724846a7b6, type=animationclip, style=clip, delay=0.06s, duration=0.68s, scale=0.72, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘회전 별가시’, 보조 효과 1개는 ‘물결 잔상’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 출력 프로필

- ICON: NEW_ART / ICON/003_m_starfish_s_mon_starfish_ICON.png / 256x256 RGBA
- CAST_VFX: NEW_ART / CAST/003_m_starfish_s_mon_starfish_CAST_F00.png..._CAST_F07.png / 8 frames × 384x384 RGBA / 0.10s per frame / non-loop one-shot
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.3 전체 아트 제작 계약

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=NEW_ART; field=icon_ruid; files=ICON/003_m_starfish_s_mon_starfish_ICON.png; target=icon_ruid
- CAST_VFX: current=true; decision=NEW_ART; field=layer_ruids; files=CAST/003_m_starfish_s_mon_starfish_CAST_F00.png..._CAST_F07.png; target=layer_ruids
- PROJECTILE: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none

### Shared constraints

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
