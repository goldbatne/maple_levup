# ChatGPT Images Master Prompt — area_05 노틸러스

첨부된 ZIP 전체를 먼저 분석하세요. 이 ZIP은 `area_05` / **노틸러스**의 포획 가능 몬스터 5종에 대한 제작 INPUT입니다. `READY`는 입력 준비 상태이며 결과 아트 승인이나 게임 반입 성공을 뜻하지 않습니다.

1. `PACKAGE_REVISION.md`, `AREA_MANIFEST`, 모든 `GENERATION_SPEC.md`, `RUNTIME_ROLE_MAP.md`, `SOURCE_PROVENANCE.md`를 먼저 읽으세요.
2. 몬스터 원본은 `MONSTER_IMAGE.png`를 그대로 참조합니다. 원본 몬스터를 재생성하거나 Preview에서 새로 그리지 말고 INPUT 이미지를 기계적으로 합성하세요.
3. WHAT(IDs, 이름, 타입, 효과, 동작)은 확정값입니다. 변경·재설계하지 말고 HOW만 제작하세요.
4. 공통 라이브러리는 프로젝트와 공식 검색에서 확보한 **183개 수집본**이며 메이플 전체 스킬 전수 자료가 아닙니다. `RECENT_PRIMARY`는 검증 가능한 시기 근거가 있을 때만 최신 우선으로 씁니다. 현재 `RECENT_SECONDARY`는 6차/HEXA 검색 후보일 뿐 시기·버전이 검증되지 않았으므로 최신으로 자동 승격하지 않습니다. `UNKNOWN`, `LEGACY_REFERENCE`도 보조 비교용이며 다운로드 시각은 아트 제작·업데이트 시각이 아닙니다.
5. `STYLE_INDEX`의 `role_classification`을 지키세요. `MONSTER_CHARACTER`, `SCENE`, `EXCLUDE_STYLE`의 본체·장면 실루엣을 신규 VFX 외형으로 가져오지 마세요. 혼합 자료는 VFX의 선·명암·알파 가장자리만 참고합니다.
6. 기존 스킬의 캐릭터, 무기, 고유 실루엣, 메커니즘을 복제하지 않습니다. 어두운 외곽→중간톤 형상→밝은 코어, 제한된 발광·반투명 층, 타격광, 잔상, 파편, 자연스러운 fade 같은 렌더링 문법만 참고합니다.
7. 각 `GENERATION_SPEC`의 역할별 산출물을 따릅니다. 엔진이 PROJECTILE 또는 layer drift를 이동시키면 이미지 안에서 캔버스 전체를 다시 이동시키지 않습니다. CAST/PROJECTILE/REFERENCE_VFX를 한 불명확한 시트로 합치지 않습니다.
8. VFX 원본 생성과 코드 후처리를 구분합니다. 원본 시트로 생성했다면 시트 원본과 정확한 분할 좌표를 보존하고, 주 납품물은 연속된 개별 RGBA PNG입니다. autocrop/recenter 금지, 동일 캔버스·피봇 유지, 빈 프레임·누락·다른 셀 조각 금지입니다.
9. RGBA라는 파일 모드만 확인하지 말고 실제 배경 alpha, 잘림, 셀 경계 침범을 검사하세요. 픽셀 검사는 아트 정합성 승인을 대신하지 않으며 `AUTO_VALIDATION`과 `USER_ART_APPROVAL`을 별도 기록합니다.
10. ICON은 256×256 RGBA 1장입니다. VFX/ICON에 텍스트·숫자·UI·워터마크·몬스터 본체 전체를 넣지 않습니다.
11. 출력 루트는 반드시 `AREA_05_IMAGES_OUTPUT/`입니다. 실제 PNG 파일과 다운로드 가능한 OUTPUT ZIP이 없으면 COMPLETE/PASS로 기록하지 마세요. 도구 한도 중단 시 완료분·미완료분을 나누고 한도 해제나 무인 완주를 약속하지 마세요.

AREA 00 승인 재사용 파일이 `approved_reuse/AREA_00/`에 있으면 호환 확인된 그 자산을 그대로 재사용하며 다시 생성하지 않습니다. 다른 스킬의 모양·색을 AREA 00에서 복사하지 않습니다.

## V2.3 mandatory delivery contract

- 게임용 원본: 프레임 분리형 F00... RGBA PNG와 ICON 256×256 RGBA.
- 몬스터별 검수 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 MONSTER_IMAGE를 재생성·재해석하지 않고 그대로 합성한다.
- Area 검수 Preview: 출력 루트의 `AREA_OVERVIEW_PREVIEW.png` 필수.
- Preview는 검수 산출물이며 Resource Storage 반입 원본이 아니다.
- 원본 시트가 생성된 경우 시트와 분할 좌표를 보존하되 주 납품물은 분리 프레임이다.
- RGBA 표기뿐 아니라 실제 alpha, 잘림, 다른 셀 조각, 빈 프레임을 검사한다.
- 파일 검사 PASS와 사용자 아트 승인은 별도다. 도구 한도를 프롬프트로 해제하거나 무인 완주를 보장한다고 쓰지 않는다.
- 출력 루트는 `AREA_XX_IMAGES_OUTPUT`이며 ZIP 밖 절대경로에 의존하지 않는다.
- 스타일 선택 시 `preview_usable=true`인 자료만 주 분석에 사용한다. RECENT_SECONDARY는 최신으로 자동 승격하지 않는다.

## V2.3 authoritative production scope

1. Read AREA_MANIFEST, FULL_ART_SCOPE, every GENERATION_SPEC/RUNTIME_ROLE_MAP, then OUTPUT_REQUIREMENTS.
2. Produce every `NEW_ART` role and copy every `AREA00_APPROVED_REUSE` role. Do not create `NO_RUNTIME_ROLE` files.
3. CAST and PROJECTILE are separate deliverables. The 11 formerly retained projectile artworks are now NEW_ART.
4. Existing RUIDs are evidence/current bindings, not permission to retain old art. Only the three exact Area 00 approved pairs are reuse exceptions.
5. Keep gameplay values and motion unchanged. Engine movement and art-local animation are separate.
6. Output to `AREA_05_IMAGES_OUTPUT/`; frame-separated PNGs and mandatory previews are required.
7. An INPUT READY status is not import/runtime/art approval.
