# GENERATION SPEC — 스톤골렘 / 암석 피부

## 확정 데이터

- 작업 순번: 001
- 레벨: 10
- Area: `area_02` / 페리온
- monster_id: `m_stone_golem`
- 몬스터 이름: 스톤골렘
- monster image RUID: `23761b84fca14bbfa671436791e4e0bb`
- skill_id: `s_mon_stone`
- 최종 스킬 이름: **암석 피부**
- 스킬 타입: **버프**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): 자신에게 5초 동안 피해 50% 감소
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어/몬스터 모두 자기 효과 적용 성공 후 시전자 위치에서 방향 반전 없이 CAST한다. L1 delay=0s duration=0.65s offset=(0,-0.06)wu drift=(0,0)wu/s; L2 delay=0.12s duration=0.72s offset=(0,-0.06)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 스톤골렘의 모델 ID·RUID와 페리온 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 맞물린 암석 판 두 겹과 틈새에서 새는 흙빛 광선. ‘스톤골렘 / 암석 피부’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 화강암 회색 #77736D; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 토황색 #C3A56A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 진행 방향·엔진 이동: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다. layer drift는 엔진 적용: L1 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0s, duration=0.65s, scale=0.8, offset=(0,-0.06) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.72s, scale=0.9, offset=(0,-0.06) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 자신만 감싼다. 다른 대상, 타격점, 공격 폭발은 표시하지 않는다.
- 화면 점유율: 중소형(캐릭터 중심 0.8~1.2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음~중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 시전자 둘레 윤곽 출현 → 보호 구조 닫힘 → 반사광 절정 → 실드 지속과 혼동되지 않게 짧게 페이드.
- 판정 정렬: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘겹친 바위판’, 보조 효과 1개는 ‘균열광’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 출력 프로필

- ICON: NEW_ART / ICON/001_m_stone_golem_s_mon_stone_ICON.png / 256x256 RGBA
- CAST_VFX: NEW_ART / CAST/001_m_stone_golem_s_mon_stone_CAST_F00.png..._CAST_F07.png / 8 frames × 256x256 RGBA / 0.10s per frame / non-loop one-shot
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.3 전체 아트 제작 계약

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=NEW_ART; field=icon_ruid; files=ICON/001_m_stone_golem_s_mon_stone_ICON.png; target=icon_ruid
- CAST_VFX: current=true; decision=NEW_ART; field=layer_ruids; files=CAST/001_m_stone_golem_s_mon_stone_CAST_F00.png..._CAST_F07.png; target=layer_ruids
- PROJECTILE: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none

### Shared constraints

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
