# Runtime Role Map — m_stone_golem / s_mon_stone — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/001_m_stone_golem_s_mon_stone_ICON.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/001_m_stone_golem_s_mon_stone_CAST_F00.png..._CAST_F07.png` | 8f / 256x256 RGBA / 0.10 / non-loop one-shot | `layer_ruids` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- confirmed design effect preserved: 자신에게 5초 동안 피해 50% 감소
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어/몬스터 모두 자기 효과 적용 성공 후 시전자 위치에서 방향 반전 없이 CAST한다. L1 delay=0s duration=0.65s offset=(0,-0.06)wu drift=(0,0)wu/s; L2 delay=0.12s duration=0.72s offset=(0,-0.06)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
