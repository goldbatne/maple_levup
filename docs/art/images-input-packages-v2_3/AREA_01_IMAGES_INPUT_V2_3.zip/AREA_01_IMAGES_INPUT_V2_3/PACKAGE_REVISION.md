# Package Revision V2

```json
{
  "revision": "V2",
  "base_zip": "docs/art/images-input-packages/AREA_01_IMAGES_INPUT.zip",
  "base_zip_sha256": "d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343",
  "area_id": "area_01",
  "area_name": "헤네시스 근교",
  "scope": "INPUT 문서·검증·재사용 파일 보정만; 게임 데이터/아트/리소스 미변경",
  "skill_table_source": {
    "source": "git:HEAD:RootDesk/MyDesk/GameData/SkillTable.csv",
    "state": "HEAD_fallback_working_file_missing",
    "sha256": "f0cb65e6390c3f154d91abbcc622b76c93aa1ca8bf0baf81d57bfe8f3b0f0d69"
  },
  "status": "READY",
  "unresolved": [
    "s_mon_snail_dew_trail: 작업 트리 SkillTable 삭제로 행 직접 재조회 불가; AREA 00 승인 런타임/manifest와 일치하여 승인 재사용만 허용"
  ]
}
```
