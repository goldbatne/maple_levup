# AREA MANIFEST — V2.3

FULL_ART_SCOPE.csv와 OUTPUT_REQUIREMENTS.csv가 역할별 제작 범위 원장이다. 확정 기획/런타임 수치는 V2.2에서 변경하지 않았다.

| order | monster | skill | roles | decisions | production | import | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_snail` | `s_mon_snail_dew_trail` | ICON|CAST_VFX | AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE | READY | NOT_READY_ASSETS_NOT_GENERATED | AREA00_APPROVED_NOT_RERUN |
| 2 | `m_blue_snail` | `s_mon_blue_snail` | ICON|CAST_VFX | AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE | READY | NOT_READY_ASSETS_NOT_GENERATED | AREA00_APPROVED_NOT_RERUN |
| 3 | `m_mushroom` | `s_mon_mushroom` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 4 | `m_mushmom` | `s_mon_mushmom` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 5 | `m_horny_mushroom` | `s_mon_horny_mushroom` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
