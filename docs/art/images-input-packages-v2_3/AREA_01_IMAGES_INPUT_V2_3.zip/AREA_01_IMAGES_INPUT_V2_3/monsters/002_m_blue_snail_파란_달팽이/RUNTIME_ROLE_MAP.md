# Runtime Role Map — m_blue_snail / s_mon_blue_snail — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png` | 8f / 256x256 RGBA / 0.1 / approved existing | `approved existing layer_ruids` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid|approved existing layer_ruids`
- confirmed design effect preserved: 자신에게 3초 동안 피해 40% 감소
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어/몬스터 모두 자기 효과 적용 성공 후 시전자 위치에서 방향 반전 없이 CAST한다. L1 delay=0s duration=0.85s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.12s duration=0.7s offset=(0,0)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
