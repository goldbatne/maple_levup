# Monster Reference — 파란 달팽이

- 작업 순번: 002
- level: 3
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_blue_snail`
- model_id: `bluesnail`
- image RUID: `0c69164656d24f64bd1a1f6ee4019dff`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_snail`
- skill name/type: 푸른 껍질 / 버프

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BlueSnail.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `813a6a78fed06176d0dd826370a3e2d8cbc36dc580973b6cc455f245bbd008ba`
- image: 320×240 RGBA / alpha 0~255 / bbox [37, 0, 284, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
