# Monster Reference — 주황 버섯

- 작업 순번: 003
- level: 5
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_mushroom`
- model_id: `mushroom`
- image RUID: `a95cfed2c8fe4d2cb64cbb62db051f92`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mushroom`
- skill name/type: 포자 살포 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Mushroom.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `0e795f604587cf4f6a4ff0637e518469c8ef35473bcb21ae257d723fe3f8dc89`
- image: 320×240 RGBA / alpha 0~255 / bbox [29, 10, 290, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
