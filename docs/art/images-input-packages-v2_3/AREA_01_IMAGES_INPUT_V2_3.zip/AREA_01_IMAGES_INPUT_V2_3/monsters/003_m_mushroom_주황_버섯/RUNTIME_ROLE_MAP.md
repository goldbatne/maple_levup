# Runtime Role Map — m_mushroom / s_mon_mushroom — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/003_m_mushroom_s_mon_mushroom_ICON.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/003_m_mushroom_s_mon_mushroom_CAST_F00.png..._CAST_F07.png` | 8f / 384x384 RGBA / 0.10 / non-loop one-shot | `layer_ruids` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- confirmed design effect preserved: INT 계수 1.1로 반경 2.5 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.55s offset=(-0.28,0)wu drift=(-0.28,0.12)wu/s; L2 delay=0.08s duration=0.6s offset=(0,0.04)wu drift=(0,0.18)wu/s; L3 delay=0.16s duration=0.65s offset=(0.28,-0.04)wu drift=(0.28,0.12)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
