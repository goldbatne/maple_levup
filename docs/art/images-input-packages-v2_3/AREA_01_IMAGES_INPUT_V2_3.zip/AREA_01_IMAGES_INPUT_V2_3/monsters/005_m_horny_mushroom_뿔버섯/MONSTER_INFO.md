# Monster Reference — 뿔버섯

- 작업 순번: 005
- level: 12
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_horny_mushroom`
- model_id: `hornymushroom`
- image RUID: `574596d79f004965a293d2551343633f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_horny_mushroom`
- skill name/type: 단단한 뿔 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/HornyMushroom.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `b6b0a1b34bbf5f7ac0ffbb4e4179cb6bd7445a2ae45fbd235d661ac390f1db54`
- image: 320×240 RGBA / alpha 0~255 / bbox [31, 0, 289, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
