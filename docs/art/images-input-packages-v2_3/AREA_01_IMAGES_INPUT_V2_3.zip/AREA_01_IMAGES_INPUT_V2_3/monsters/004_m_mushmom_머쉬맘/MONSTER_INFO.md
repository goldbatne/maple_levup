# Monster Reference — 머쉬맘

- 작업 순번: 004
- level: 10
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_mushmom`
- model_id: `mushmom`
- image RUID: `86015373d23b4b05bb8fcc6086354652`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mushmom`
- skill name/type: 머쉬맘의 포자 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Mushmom.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `d475d084a2630c88270472a946ceb2603b0494efd1a9eb873d2b09fa7788991b`
- image: 320×240 RGBA / alpha 0~255 / bbox [30, 0, 290, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
