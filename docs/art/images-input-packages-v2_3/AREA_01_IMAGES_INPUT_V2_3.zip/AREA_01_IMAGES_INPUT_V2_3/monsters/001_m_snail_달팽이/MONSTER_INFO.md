# Monster Reference — 달팽이

- 작업 순번: 001
- level: 1
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_snail`
- model_id: `snail`
- image RUID: `2db94405cf0445f5be2b60a02c21dda5`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_snail_dew_trail`
- skill name/type: 이슬 미끄럼길 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Snail.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `da97ef20db013d41f9dd683c31fbce8aa579774446cd7893d93570958ca72fad`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 8, 320, 233]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
