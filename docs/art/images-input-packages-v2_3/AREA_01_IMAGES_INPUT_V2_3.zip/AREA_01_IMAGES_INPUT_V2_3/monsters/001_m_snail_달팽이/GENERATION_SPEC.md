# GENERATION SPEC — 달팽이 / 이슬 미끄럼길

## 확정 데이터

- 작업 순번: 001
- 레벨: 1
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_snail`
- 몬스터 이름: 달팽이
- monster image RUID: `2db94405cf0445f5be2b60a02c21dda5`
- skill_id: `s_mon_snail_dew_trail`
- 최종 스킬 이름: **이슬 미끄럼길**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.8s offset=(0,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 달팽이 점액 이동과는 자연스럽지만 ‘이슬’은 Images 2.5 파일럿에서 더한 창작 설정이다.

## 시각 번역

- 핵심 소재: 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울. ‘달팽이 / 이슬 미끄럼길’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 맑은 이슬 청록 #7EDFD1; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 연한 풀잎 연두 #B8E86A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 효과 발생 위치: 시전자 발밑 바로 앞에서 ‘이슬 미끄럼길’의 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울이 낮은 지면 접촉선으로 시작
- 진행 방향: 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울의 긴 축이 오른쪽으로 미끄러지듯 늘어나고 끝부분 물방울만 뒤따라 소멸
- 대상 표현: 확정 효과 ‘ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8’의 반경 안 다중 대상을 낮은 점액 파문과 작은 접촉광으로 구분
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 준비(핵심 형상 출현) → 상승(형상 확대·보조 입자) → 절정(밝은 코어/타격광) → 소멸(형상 분해·알파 fade)
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘큰 이슬방울’, 보조 효과 1개는 ‘낮게 미끄러지는 점액 꼬리’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함


- 스타일 적용 우선순위: 시기 근거가 검증된 RECENT_PRIMARY만 최신 우선으로 사용한다. RECENT_SECONDARY는 최신 대체 세트가 아니며 UNKNOWN/LEGACY와 함께 보조 비교로만 사용한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 출력 프로필

- ICON: AREA00_APPROVED_REUSE / approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png / 256x256 RGBA
- CAST_VFX: AREA00_APPROVED_REUSE / approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png / 8 frames × 384x384 RGBA / 0.1s per frame / approved existing
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.3 전체 아트 제작 계약

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid|approved existing layer_ruids`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=AREA00_APPROVED_REUSE; field=icon_ruid; files=approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png; target=icon_ruid
- CAST_VFX: current=true; decision=AREA00_APPROVED_REUSE; field=layer_ruids; files=approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png; target=approved existing layer_ruids
- PROJECTILE: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none

### Shared constraints

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
