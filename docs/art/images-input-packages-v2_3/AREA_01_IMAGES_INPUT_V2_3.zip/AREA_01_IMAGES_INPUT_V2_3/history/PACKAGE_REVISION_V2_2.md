# PACKAGE REVISION — V2.2

- source: `AREA_01_IMAGES_INPUT_V2_1.zip`
- source_sha256: `057adf2e7122b23a08e53b3ff217b89ff108d006c67f2010737b166c77aff050`
- built_utc: `2026-09-12T01:39:56.024177+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
