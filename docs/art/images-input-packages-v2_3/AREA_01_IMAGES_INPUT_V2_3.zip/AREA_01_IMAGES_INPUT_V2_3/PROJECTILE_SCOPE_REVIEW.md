# PROJECTILE SCOPE REVIEW — V2.3

All 12 actual monster projectile visual roles are NEW_ART. Engine movement is unchanged; existing projectile RUIDs remain evidence only until approved import.

| Area | monster | skill | current RUID | new files | timing | targeting | impact | future target |
|---|---|---|---|---|---|---|---|---|

- Stumpy has no CAST and remains PROJECTILE+ICON only.
- The other 11 keep their CAST requirement and add an independent PROJECTILE requirement.
- No HIT role is added because ResolveThrowHit has no visual asset field or effect spawn call.
