# AREA 00 승인 에셋 재사용

아래 파일은 AREA 00 승인 OUTPUT의 바이트 복사본이다. 호환되는 동일 monster_id + skill_id에만 재사용하며 다시 생성하지 않는다.

## m_snail / s_mon_snail_dew_trail

- source: `docs/art/area00-images-output/AREA_00_IMAGES_OUTPUT/monsters/001_m_snail_달팽이`
- files:
  - `approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png` — SHA-256 `9e4c5c2bf3f0edd39e3de4855d0eb2c16a049d879a88fe104fb91e5eb76a5446`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png` — SHA-256 `fb8219560516c240f9a18a7744b483ebcf487e895a8c8a7f6fd28c21e7bdc98e`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/labeled_preview.png` — SHA-256 `b2848ad484da3d67b10a3a1616be47fd2c9cd85659e617b429ac08b52cda5d32`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png` — SHA-256 `b7e74d47734d5b6bbcdbe3c68d99ed67b360eff4c6c73bcf4b141ba69b4d3525`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png` — SHA-256 `41302b32898fa0136beeba6c6959da7694f35bab7bf6c63a4f6b0f9a45e94b7b`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png` — SHA-256 `3e4aec6879b1765ebe8a38bdc3caf37b17cb412d113d5b3272e125f39ced6df8`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png` — SHA-256 `f9d41b208b4b5211ec7192e517b63e83b9584c97a27140e408efc1381954ba0b`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png` — SHA-256 `f74cc1f1679ee8075bb00b561de00036e26927f29630e28641ab8cb550dcf873`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png` — SHA-256 `e42797fa98dd5ebd9ece312428850a4d002758e900040402c20a9a3c67b7e006`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png` — SHA-256 `6fcb2783109b7be3a201ced278d107019a85b1b508ff10f9e8db2b8ef80d5f7f`
  - `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png` — SHA-256 `a10fa4be7113d815469390317d352bf33593777576ef66f81ebeae5055159c9a`

## m_blue_snail / s_mon_blue_snail

- source: `docs/art/area00-images-output/AREA_00_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이`
- files:
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png` — SHA-256 `defd113ea3c59d8b570f73a79533b4253b5e72f789347e13aaa6cdbfefe65d27`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png` — SHA-256 `ae99795e61bc6eb9e14c0396fcaa576cda252dbf9ec738a1902bebfbf30c2424`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/labeled_preview.png` — SHA-256 `31869bf284cf60325a6c2a833d1ea993c1593b36796977843760bad3858a44ea`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png` — SHA-256 `d7b55014803cf9feed39d079ceb5deef7bf7f2780bfbbca351f8b3f6c00d8b7c`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png` — SHA-256 `cfac5775668a4cbc3538bc0bf5d3128c156420b4b10154719e7b40b2f3e954c8`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png` — SHA-256 `9c712f7984fa7cee2a34642bb6ea82d48e65ff40136722336230d5c108ed5cde`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png` — SHA-256 `9637aba5fa8311195959dfb12a284ce6ae384861e8b7e861b18c2a5fa9a6ff13`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png` — SHA-256 `0bce8d96d2dbfc9ed65f5735bf440ff5467d1e6daddf44769af7c501530720b7`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png` — SHA-256 `7c711af880e09179d6e35cb0592244949ccf816ed2e0e843fb141e36b2f39d23`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png` — SHA-256 `1a97d84716a4518c8af8262bb8cf503d43d9737ed0db3b262308d6a508bb0653`
  - `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png` — SHA-256 `d28d8ff99b111634ba2a755761085a260dda2100f83cf2e729812242dc98f7c1`
