# PROJECTILE SCOPE REVIEW — V2.3

All 12 actual monster projectile visual roles are NEW_ART. Engine movement is unchanged; existing projectile RUIDs remain evidence only until approved import.

| Area | monster | skill | current RUID | new files | timing | targeting | impact | future target |
|---|---|---|---|---|---|---|---|---|
| area_15 | `m_peach_monkey` | `s_mon_peach_monkey` | `9ca14ee512b1489cbb54b2b9833388cd` | `PROJECTILE/003_m_peach_monkey_s_mon_peach_monkey_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 7 | 0.8 after 0.35s | `projectile_ruid` |
| area_15 | `m_tae_roon` | `s_mon_tae_roon` | `5328a3875a32437784c949579f259a00` | `PROJECTILE/005_m_tae_roon_s_mon_tae_roon_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 6.6 | 0.8 after 0.35s | `projectile_ruid` |

- Stumpy has no CAST and remains PROJECTILE+ICON only.
- The other 11 keep their CAST requirement and add an independent PROJECTILE requirement.
- No HIT role is added because ResolveThrowHit has no visual asset field or effect spawn call.
