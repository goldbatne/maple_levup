# Monster Reference — 수련용 짚인형

- 작업 순번: 001
- level: 141
- Area: `area_15` / 무릉도원
- monster_id: `m_straw_dummy`
- model_id: `strawdummy`
- image RUID: `4b1d55e35ae9462b944297691025429a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_straw_dummy`
- skill name/type: 짚단 균형감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/StrawDummy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `18a14ae9237b527df49f0fefb3364d4f7dc8e7bc1478faa33d583ba29dadcbab`
- image: 320×240 RGBA / alpha 0~255 / bbox [47, 0, 266, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
