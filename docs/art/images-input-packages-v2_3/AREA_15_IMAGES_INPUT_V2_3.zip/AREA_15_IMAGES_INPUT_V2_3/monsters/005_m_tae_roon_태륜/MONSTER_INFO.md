# Monster Reference — 태륜

- 작업 순번: 005
- level: 150
- Area: `area_15` / 무릉도원
- monster_id: `m_tae_roon`
- model_id: `taeroon`
- image RUID: `0e1e782401624d7693959777c0b16ebe`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_tae_roon`
- skill name/type: 태륜의 쌍권풍 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/TaeRoon.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `f64e011225b8b48ba63dcfe1966b5d927ba4a2d511a657c66d5172fd8e50e2d2`
- image: 320×240 RGBA / alpha 0~255 / bbox [15, 2, 307, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
