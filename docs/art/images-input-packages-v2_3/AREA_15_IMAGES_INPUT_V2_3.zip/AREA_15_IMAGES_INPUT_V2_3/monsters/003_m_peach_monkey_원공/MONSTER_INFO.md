# Monster Reference — 원공

- 작업 순번: 003
- level: 145
- Area: `area_15` / 무릉도원
- monster_id: `m_peach_monkey`
- model_id: `peachmonkey`
- image RUID: `15e255981ed54cf092a136b1526aa055`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_peach_monkey`
- skill name/type: 천도 투척 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/PeachMonkey.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `672ac19e33efb0adef8638e7c9520e033a7c6e30f4c10078d185914229bbaca3`
- image: 320×240 RGBA / alpha 0~255 / bbox [28, 0, 293, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
