# Monster Reference — 수련용 나무인형

- 작업 순번: 002
- level: 143
- Area: `area_15` / 무릉도원
- monster_id: `m_wooden_dummy`
- model_id: `woodendummy`
- image RUID: `91ff481190624f0fa850c86c8d3bdbde`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wooden_dummy`
- skill name/type: 목인 회전타 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/WoodenDummy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `c35db2d48e08257067668cb6c65ff97fc0cb2b78546364b93b394566fa371ab4`
- image: 320×240 RGBA / alpha 0~255 / bbox [42, 0, 272, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
