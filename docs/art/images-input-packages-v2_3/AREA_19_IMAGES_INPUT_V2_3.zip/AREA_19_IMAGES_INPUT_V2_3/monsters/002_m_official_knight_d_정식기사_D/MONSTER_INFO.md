# Monster Reference — 정식기사 D

- 작업 순번: 002
- level: 183
- Area: `area_19` / 미래의 문
- monster_id: `m_official_knight_d`
- model_id: `officialknightd`
- image RUID: `1b11119e13474135882191d052342552`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_official_knight_d`
- skill name/type: 기사단의 바람 조준 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/OfficialKnightD.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `ea75c5807194bf4b90906c6a0c1217e2f320b03c620456d29ab96e2a4ae286a1`
- image: 320×240 RGBA / alpha 0~255 / bbox [96, 1, 224, 239]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
