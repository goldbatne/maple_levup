# Monster Reference — 정식기사 C

- 작업 순번: 001
- level: 181
- Area: `area_19` / 미래의 문
- monster_id: `m_official_knight_c`
- model_id: `officialknightc`
- image RUID: `da57403b50694b12bf0e19aa3a64112d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_official_knight_c`
- skill name/type: 기사단 뇌전 연각 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/OfficialKnightC.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `b1397b8b5ffbec9ec67416efdba8463478740111afbfa07ddcd6dc23f09ceaa5`
- image: 320×240 RGBA / alpha 0~255 / bbox [81, 1, 240, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
