# Monster Reference — 상급기사 B

- 작업 순번: 004
- level: 188
- Area: `area_19` / 미래의 문
- monster_id: `m_advanced_knight_b`
- model_id: `advancedknightb`
- image RUID: `3a107a08957f442d8b3e191258198056`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_advanced_knight_b`
- skill name/type: 상급기사의 이프리트 화염 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/AdvancedKnightB.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a3d91d0df41111eaa2fc9a6a415f1906104efbd5b6fe66ab27a74731941eebf8`
- image: 320×240 RGBA / alpha 0~255 / bbox [65, 1, 256, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
