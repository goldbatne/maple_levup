# Output Format Spec — V2.3

- `FULL_ART_SCOPE.csv` defines every actual/new/reused/absent role; `OUTPUT_REQUIREMENTS.csv` mirrors it.
- Primary art delivery is frame-separated RGBA PNG. Same role means identical canvas/pivot/scale.
- CAST uses the existing skill profile recorded in GENERATION_SPEC.
- Every actual PROJECTILE is newly produced as 4 frames × 0.08s = 0.32s non-loop within unchanged 0.35s entity life. Stumpy remains this exact contract.
- PROJECTILE artwork is direction-neutral and does not duplicate engine translation/ZRotation. Current code has no PROJECTILE FlipX/travel alignment.
- ICON is 256×256 RGBA. Passive REFERENCE is preview-only and runtime_use=false.
- No dedicated HIT/PERSISTENT visual path exists; do not generate those roles.
- targeting_range is not impact_radius. Do not depict target-search range as impact damage coverage.
- PACKAGE_VALIDATION/PRODUCTION_READY/IMPORT_READY/RUNTIME_VALIDATION/ART_APPROVAL remain separate.
