# Monster Reference — 마스크피쉬

- 작업 순번: 002
- level: 93
- Area: `area_10` / 아쿠아로드
- monster_id: `m_mask_fish`
- model_id: `maskfish`
- image RUID: `fb9037f43fcd442a971ee007b9f7cc26`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mask_fish`
- skill name/type: 가면 아래의 감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MaskFish.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a3777aafb92af452241b2e1203b433ded4b537718d82983cf0cb97fa86a3910a`
- image: 320×240 RGBA / alpha 0~255 / bbox [10, 0, 303, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
