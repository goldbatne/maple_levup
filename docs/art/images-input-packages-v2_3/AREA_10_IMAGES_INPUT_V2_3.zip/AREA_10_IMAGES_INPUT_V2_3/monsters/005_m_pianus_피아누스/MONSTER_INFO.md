# Monster Reference — 피아누스

- 작업 순번: 005
- level: 100
- Area: `area_10` / 아쿠아로드
- monster_id: `m_pianus`
- model_id: `pianus`
- image RUID: `207c5d6dcee243ad9a141397244ba9a9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_pianus`
- skill name/type: 심해왕의 광선 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Pianus.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `2a158f17438656ed52b80362ef68066b75765ade80805d78dba2020477fcfc12`
- image: 320×240 RGBA / alpha 0~255 / bbox [26, 1, 296, 237]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
