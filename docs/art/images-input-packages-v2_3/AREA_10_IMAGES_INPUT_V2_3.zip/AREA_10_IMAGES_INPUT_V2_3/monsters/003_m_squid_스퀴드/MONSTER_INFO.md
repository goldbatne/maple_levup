# Monster Reference — 스퀴드

- 작업 순번: 003
- level: 95
- Area: `area_10` / 아쿠아로드
- monster_id: `m_squid`
- model_id: `squid`
- image RUID: `013b3e6ba18249269e4a1b85c536a0d9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_squid`
- skill name/type: 심해 먹물 폭발 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Squid.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `cb5bcd900206f14e38c207d3a057e6fd8f550991aa9a66697d4ff8e3709d9465`
- image: 320×240 RGBA / alpha 0~255 / bbox [3, 4, 319, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
