# Runtime Role Map — m_squid / s_mon_squid — V2.3

| role | current | production | files | timing | future target | unresolved |
|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/003_m_squid_s_mon_squid_ICON.png` | 1f / 256x256 RGBA / static / static | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/003_m_squid_s_mon_squid_CAST_F00.png..._CAST_F07.png` | 8f / 384x384 RGBA / 0.10 / non-loop one-shot | `layer_ruids` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- confirmed design effect preserved: INT 계수 3로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0.12s duration=0.82s offset=(0,0)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
