# Monster Reference — 샤크

- 작업 순번: 004
- level: 98
- Area: `area_10` / 아쿠아로드
- monster_id: `m_shark`
- model_id: `shark`
- image RUID: `b95f05df46124b3485d0a15bb79b10fb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_shark`
- skill name/type: 포식자의 수류탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Shark.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `0badca0ca226e8e225e614cfcf818451a99c5e8fce747bf7864e0065e88b99ef`
- image: 320×240 RGBA / alpha 0~255 / bbox [8, 1, 306, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
