# Monster Reference — 버블피쉬

- 작업 순번: 001
- level: 91
- Area: `area_10` / 아쿠아로드
- monster_id: `m_bubble_fish`
- model_id: `bubblefish`
- image RUID: `c968133e75534a1b933d28da29c4e584`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_bubble_fish`
- skill name/type: 기포막 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BubbleFish.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `ebf6c9bc5a22a049c695a7bc0ad600355251997484626ba907bc3dd3abf49b30`
- image: 320×240 RGBA / alpha 0~255 / bbox [14, 0, 296, 238]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
