# 수련용 나무인형

## 현행 분류 — V2.2

- RUID: `1ad77c5bc77f4ee3a7b212d6394f0b13`
- 출처: MSW 공식 리소스 검색 API thumbnail
- reference_role: `MONSTER_CHARACTER`
- style_priority: `EXCLUDE_STYLE`
- role_basis: 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상
- preview_usable: `true`
- 사용 규칙: 본체·캐릭터·장면이 주 형상이므로 신규 VFX의 렌더링 우선 레퍼런스에서 제외한다. RUID와 이미지는 대조 이력으로만 보존한다.

## 변경 이력 — 현행 지시 아님

- V2.1 이전 상단 표기 style_priority: `UNKNOWN`
- V2.1 이전 상단 표기 effect_family: `layered VFX`
- 변경 이유: STYLE_INDEX.csv의 시각 검수 분류와 상충해 V2.2에서 현행 값을 단일화했다.
