# STYLE ATLAS — V2.2

- 전체 수집본: 183
- 역할: ICON 40 / MONSTER_CHARACTER 10 / SCENE 5 / UNCONFIRMED 23 / VFX 105
- 우선순위: EXCLUDE_STYLE 15 / LEGACY_REFERENCE 41 / RECENT_SECONDARY 19 / UNKNOWN 108
- preview_usable=false: 8
- 현행 분류 원장: `../STYLE_INDEX.csv`
- RECENT_PRIMARY만 검증된 시기 근거가 있을 때 최신 우선으로 쓴다. RECENT_SECONDARY는 자동 대체 세트가 아니다.
- UNKNOWN/LEGACY_REFERENCE는 보조 비교이고 EXCLUDE_STYLE은 최종 렌더링 레퍼런스에서 제외한다.
- 몬스터·캐릭터 본체와 장면 실루엣은 신규 VFX 외형으로 복제하지 않는다.
