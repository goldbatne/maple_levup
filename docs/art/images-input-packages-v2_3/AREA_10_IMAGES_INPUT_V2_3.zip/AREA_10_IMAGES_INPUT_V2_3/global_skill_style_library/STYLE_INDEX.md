# Global Skill Style Library Index — V2.2

현행 분류의 단일 원장은 `STYLE_INDEX.csv`다. 개별 info.md의 `현행 분류 — V2.2`와 동일해야 한다.
이 183개는 프로젝트 확보 수집본이지 메이플 전체 스킬 전수 자료가 아니다.
RECENT_PRIMARY는 검증된 시기 근거가 있을 때만 최신 우선이다. RECENT_SECONDARY를 자동 승격하지 않는다.
UNKNOWN/LEGACY_REFERENCE는 보조 비교, EXCLUDE_STYLE은 분류 이력 보존용이다.

| index | name | RUID | reference_role | style_priority | preview_usable | reason |
|---:|---|---|---|---|---|---|
| 1 | 미니 블루 드래곤 | `01663ed8b2a94562956e8029a79c03b5` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 2 | animationclip-655540 | `01dbde634dd944e685b45727289bd9b8` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 3 | animationclip-655555 | `01f39ee5971246ed8306bc471d44a1fd` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 4 | animationclip-655557 | `0207c85c05dd4c4eac12f9ee735d0545` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 5 | 돌아온 머쉬맘 | `05113e9dc86448cb8581731824106d75` | VFX | UNKNOWN | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 6 | animationclip-1041550 | `057c2da13da2492c95cb92db424803db` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 7 | 롬바드 | `06bbe7d534094761b54b147f3a79ca38` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 8 | 설산의 마녀 | `0719861214fa45578488a1083f49df5a` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 9 | 스퀴드 | `0906c3a7455940ce9e9db0b0f0278741` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 10 | 단단한 뿔 | `0928f98bbd114efc935696c1200c9d39` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 11 | sprite-8907568 | `0af9fd3ccfb540799043da5e580aebbd` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 12 | 머쉬맘의 포자 충격 | `0b09a6a325c54caca2282859ae624b22` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 13 | 어둠의 뿌리 | `0fbbe12552664c5f87944ff56a630178` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 14 | 능력의 다크 와이번 | `1215ca4153664cb18a207cddcc5ab22c` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 15 | 키메라 | `127defcb953144368b79da1417f8b4b4` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 16 | 마뇽 | `128fe611ea9347aab589c5b5d4d8fc5b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 17 | animationclip-656600 | `12b8ddbe34324edf81ba40fc36f4ad56` | UNCONFIRMED | UNKNOWN | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 18 | 구미호 | `1660382723ff40c296845e8ded7bbc86` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 19 | [★] 정식기사C | `1a648542a3b447f594b5c331cf44503f` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 20 | 수련용 나무인형 | `1ad77c5bc77f4ee3a7b212d6394f0b13` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 21 | 시그너스 | `1c8327eff1fa4321bef0fe5410a6ddef` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 22 | sprite-8909804 | `1dc02c9673284efb94da9c86e7414eeb` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 23 | 밀로 | `1ea2d50c388645df9502190ef8092d94` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 24 | 블러드 하프 | `1f2bdb3b15a145ea8f3db3fbfb61296b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 25 | 메카티안 | `1fe5c891382642d3aa35a89414f43fce` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 26 | 흰 모래토끼 | `201c4ae9d7c24438b56fb4d731ed9245` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 27 | 샤크 | `209c4567073b424e8d445cea7efb80e3` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 28 | animationclip-657546 | `22444db0645d47f48f300f36b3d90e4b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 29 | 마티안 | `22db356cc60940089b7f5d592c7d5813` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 30 | sprite-8910424 | `22f848d3e25941d88f3bccaebe6f7f64` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 31 | sprite-8910555 | `2403c0085abe432b8120278f1c82442c` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 32 | animationclip-657650 | `24a41e7c8ab9445589d9b637528b7a1c` | SCENE | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음 |
| 33 | sprite-8910806 | `25f430af296748f39f48de4a6a6faea7` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 34 | animationclip-657764 | `2643498ff2bb4b4a8a55c480f00373a4` | UNCONFIRMED | UNKNOWN | false | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 35 | animationclip-657878 | `27e15f18340044509dc75492c362c865` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 36 | animationclip-658065 | `2ba72c9b0bdd4e2fb33269262e9a7dea` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 37 | animationclip-1038614 | `2c12c1e835a04c2a9ec1c5724846a7b6` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 38 | animationclip-658167 | `2d3a1370a91d4da99ecfb42d7cced7c5` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 39 | animationclip-658323 | `2ed6be9152eb4bf0b22f4ca6e6fff9fe` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 40 | animationclip-1040037 | `2f4311e974a44f218bedd1011a561310` | SCENE | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음 |
| 41 | 피아누스 | `306a9aafa3fb43498f1b783b85512305` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 42 | animationclip-658386 | `30afd80ab7a34a3d978efd8e83a6eb31` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 43 | 태륜 | `353079a9d111455ab55d75577f9d7967` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 44 | 에인션트 다크골렘 | `3803b5c17bf04b56bef115b3afbf388b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 45 | 피아누스 | `3822f5bc47af488585cef2f0929ec811` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 46 | 고목의 생기탄 | `383249b0f9254764aa758b1bcc9bfee9` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 47 | 타우로마시스 | `3cbd85dcfe3c41c4989adec59385c257` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 48 | 타이머 | `3ef6b2dcc75f4d4990e6e7f106bda49e` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 49 | 네오 휴로이드 | `3ff44a80daba4bb4a903778e036f551d` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 50 | 시스템 몬스터E10 | `412bce166c844b07ba1b4aa3ddcd53fa` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 51 | 추억의 수호대장 | `4147dea424e9475ca1a61773421a3397` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 52 | sprite-8914285 | `429228115d56462ab0f65e7294a51609` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 53 | ??? | `4292e76ef5034a42976afa7988d0a85c` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 54 | [★] 정식기사C | `439308ddd0bf4405a8463340c67a464b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 55 | animationclip-659710 | `46198aa7dd8245b59ea37305c57df9f0` | SCENE | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음 |
| 56 | sprite-12846807 | `483690e55c974444aef84df3a6331d93` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 57 | 파우스트 | `49b21aaa1d574ba787149841a31bf1a5` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 58 | 루나픽시 | `4f6509d9539f4d76a9bb4e8f17e12cc7` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 59 | 메카티안 | `50eff4b9b8064efa8db5246e7a912c4d` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 60 | 몸통 박치기 | `518cc119c1c04b8797090175d9f015f2` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 61 | 블러드 하프 | `518e72a0592d48b3b3e451be46a4f39e` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 62 | sprite-8916132 | `52162587bc534b9385af8c77513d93d4` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 63 | animationclip-1038337 | `5308ef85369c4f31843d6e8cde4b1012` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 64 | 태륜 | `5328a3875a32437784c949579f259a00` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 65 | animationclip-660545 | `544b4092b87a41948b74e6645d530b88` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 66 | animationclip-1040165 | `5518aba1defc4a53b7593109b09959b4` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 67 | animationclip-660634 | `55fd196846694198bd65c59356de0830` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 68 | 정체모를 주니어 발록 | `5638984319fd476ca3d89e2aaca7f32a` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 69 | animationclip-660656 | `566b0886b4cf4f3997a29ecd3a1954b5` | VFX | UNKNOWN | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 70 | 물방울 마력 | `572a7a12dcb449bcb0582fc2ccf5be07` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 71 | animationclip-660879 | `5a19a94eb91e49428d698172dcc6b060` | UNCONFIRMED | UNKNOWN | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 72 | 마뇽 | `5ac6554c0ea94009bbd9389df0542339` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 73 | animationclip-1039437 | `5bc3cb66370a45ae9ba7349672a7cf2b` | UNCONFIRMED | UNKNOWN | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 74 | animationclip-1038154 | `5c3501dc981941c5b04c2f690351bce8` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 75 | animationclip-661184 | `5f2d779cdb8b4cdb9620b2c235e51f25` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 76 | 요정의 마법가루 | `5f5ebe88b8f2426195c793b3440012e4` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 77 | animationclip-661347 | `623d68d21e784ac9949fd7941ab53f67` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 78 | animationclip-661393 | `6294c62288bd46beb2ff548bd8671ee0` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 79 | 뼈 무덤 | `637abac61bd14f788b157d6aaf1fa08f` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 80 | sprite-8918337 | `644fc39bcc684c209264eb9d9a4cd6f8` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 81 | animationclip-1042815 | `6486822ba9284f41b5c8c3a240d3a52b` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 82 | animationclip-661507 | `64f775829e234918bd65e9d22214bb06` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 83 | animationclip-1042090 | `6611bd12f23d4f3e8c45689533ff6e1d` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 84 | animationclip-661888 | `67a9ec7922374ed79f28d6bb3096aff4` | SCENE | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음 |
| 85 | 포자 살포 | `6923ce8064e4445d8e63176645943fb1` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 86 | animationclip-1038620 | `69656381a8e04edcbb8a2c8599567ab3` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 87 | 에인션트 다크골렘 | `6ad623bf86ad46f0ad423c10e383a28e` | VFX | UNKNOWN | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 88 | 루나픽시 | `6d96350411834e2b90a2fe18ff542159` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 89 | 스타픽시 | `6ffbabe486c24e5ea6cda2c54022033b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 90 | 마티안 | `70f170cb7f644da28dc93915a8e70dd9` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 91 | sprite-12921354 | `71a82cb186bb41799e6dbb3a421cb474` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 92 | 끈적한 몸통 | `72d1dd0939714240bddc0b6865eb93ce` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 93 | 도도 | `72e16f10f6ec4cf0a1fe3146e73f0856` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 94 | 푸른 껍질 | `73c1bdafcb7e42bc8db0041883226449` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 95 | 이슬 미끄럼길 | `74cd5784067849bf865c80b2f2ebf795` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 96 | 수련용 나무인형 | `7598c7485ce9483b8b1178386b7d8f73` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 97 | 스타픽시 | `78e3188f0fc14797a8383658e626e3ea` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 98 | animationclip-1040852 | `79c9b3b094dd49eda90e80d178f0ff28` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 99 | 설귀도 화이트팽 | `7a41e40ee7d846908e29ec10b94630b0` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 100 | animationclip-1040678 | `7d1673d31f0d48ba96061c8a840c64af` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 101 | animationclip-1040706 | `7e11c40b5fcf4d688c40b539b71350a3` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 102 | 단단한 밑동 | `8061aa7a332b4e7ba783b3cd582ebb4b` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 103 | 킹크랑 | `8394705c13394b78a8b9a38e1313cb22` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 104 | animationclip-1043227 | `86734a2715504c10b1e50ae810609e25` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 105 | animationclip-663441 | `86c80043cbfa4a17ae2df502318f96e8` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 106 | 시그너스 | `875053c636494f6d807b803dd95bc3eb` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 107 | 마노 | `890da64fbb374f018a722d9ed040098d` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 108 | 상급기사B | `89e2fa1739754ade99ddca6ca3653182` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 109 | 상급기사B | `8a8c83af487246b89a8f4e4ff92edd66` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 110 | animationclip-663687 | `8b26a0cdb63d455e82d1ca0fddf5e139` | VFX | LEGACY_REFERENCE | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 111 | 태륜 | `8e38989c6f3d4f87876d37e431ee11c1` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 112 | animationclip-663973 | `9051254fb84a4a898f3d99a213a896ec` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 113 | 제노 | `908710847a0249c98cf8e935dfb1ddd8` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 114 | 롬바드 | `91c5d5dd661e4e079271b4446f7eb262` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 115 | animationclip-664261 | `9520049ad5844acb847351928c162169` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 116 | 데우 | `98cd61bf1b2c4ff496455ad956cd95d5` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 117 | animationclip-664520 | `997628810df4448f9e534bc426d6794a` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 118 | 데우 | `9af96df994cf4794882fec71c027da2b` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 119 | animationclip-1039919 | `9c927f6388e74628b1050dfc8490246c` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 120 | 원공 | `9ca14ee512b1489cbb54b2b9833388cd` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 121 | 변형된 아이언호그 | `9d71fbaf9b154c51bbdb481eaa2fc52f` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 122 | animationclip-664798 | `9defa2b61ad94ae3bc50d707979770e6` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 123 | 설귀도 화이트팽 | `9fae493a549a4396a2f1378c39f7386f` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 124 | sprite-8925662 | `a04302b1969248d2a7de250f3cb654b5` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 125 | 변형된 아이언호그 | `a29334463fbf4a7bbc8e4cb7325229b7` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 126 | 킹 블록퍼스 | `a2da67e687994755a8943c2bcf871902` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 127 | animationclip-1042336 | `a610b14bbc55477cbc78777a5a2e7ed1` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 128 | animationclip-665317 | `a6696166fce347e7b6394508f83dd687` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 129 | 샤크 | `a6ab8a49e4174a29bd45a835ed6d3460` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 130 | animationclip-665381 | `a77ea54c400e4b56a44ed05091a0ae53` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 131 | [★] 망각의 수호대장 | `aa3d9ed3c4a3435298afcb494ac7fcac` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 132 | 키메라 | `ab113d9a5ca5402d85ecc2ab7a4f51a1` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 133 | animationclip-1043000 | `af4e6abe766e4970a0e90aca58c6cc1c` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 134 | 도끼 휘두르기 | `b03001aaa4cf4dfe82d34a48c58cb342` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 135 | 엘리쟈 | `b14b3dbca0504af28e8d085c12b22000` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 136 | 원공 | `b22bb4955588482cbe450b97cff20c19` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 137 | sprite-8928057 | `b4fc4ca0e970498781b49ddfdffe9ff1` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 138 | 스타픽시 | `b61e7e2a50b2405794f88fdddf44b73a` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 139 | 저돌 맹진 | `b656b6744e204375a345782b5119aea2` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 140 | 마뇽 | `b6b5849af24a416ab1680a1dced9697f` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 141 | 설귀도 화이트팽 | `b9d0ab716c054c58a18c0c38b07695a5` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 142 | animationclip-666784 | `beabe4fd1d6d442dafe41d0d086e622e` | UNCONFIRMED | RECENT_SECONDARY | false | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 143 | 저주의 인형 | `c07ed26000af460a8438a3486e16f3ec` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 144 | 추억의 신관 | `c25e7243baaf4b21bb70ee10dcd33890` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 145 | sprite-8929715 | `c2b8ef247cb243268aae39b3d51f89e7` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 146 | animationclip-667168 | `c4f8dce4ee2745cda0f211514605261b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 147 | 킹크랑 | `c57b15ccc8dd408b98c627617144d3cd` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 148 | 설산의 마녀 | `c5a807748e9443348e5b14162948f26b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 149 | sprite-12921677 | `c65619c9037a4018a344e1625fe2a753` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 150 | 제노 | `c68a17e01f83412882ac127cda104ee3` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 151 | 스텀피 | `c6b3f052e977479ea5ad5329ce0981ca` | SCENE | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음 |
| 152 | animationclip-1038917 | `c912850a22804b7ab7fee10252397397` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 153 | 암석 피부 | `cba9471e009f46ee9c786f31d29c3848` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 154 | 도도 | `cf2fe8e1a8954e7099bd2243cfb908d7` | VFX | UNKNOWN | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 155 | animationclip-668335 | `d8cbacc0ed7545d4afa1a948fafca99b` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 156 | animationclip-668383 | `d96be74e6b014ce884413a98c139a136` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 157 | 강철 발굽 | `da712fe9654b4ea2940cee669043bceb` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 158 | animationclip-668461 | `db2b67de20f5418cb7b5050ce0641df1` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 159 | animationclip-668557 | `dccb430baeae4e0293035a3394b5e288` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 160 | sprite-8932807 | `dcfc97ad90e146d08a46225082ae590b` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 161 | 설귀도 화이트팽 | `dd098279908940fa938d3c5cb3dda732` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 162 | sprite-12899995 | `de5f2ecbd5ae4a7c9fe5c25f1ed9728a` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 163 | 변형된 스텀피 | `dfb0126bee6f48fb9bdb289bddef870b` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 164 | animationclip-1040017 | `e2a05bd4787543618ffcbbe719288ee8` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 165 | 네오 휴로이드 | `e51545cbf94349f59f4431e2e76d2cdc` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 166 | 킹 블록퍼스 | `e53471f0f7114343907be7beb520751f` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 167 | 타이머 | `e5558e07445143b6999f20246768a3fe` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 168 | sprite-12850151 | `e5591a8f17a84f7d966499a0048cf15a` | ICON | UNKNOWN | true | SkillTable icon_ruid 사용처 |
| 169 | 변형된 스텀피 | `e79a4d871f6a4cbdbf75a7126982013e` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 170 | 루나픽시 | `e7ee1a40564c43afbced2da544471266` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 171 | 마티안 | `e9d2e8cba2aa4245ae29cfb516746a04` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 172 | animationclip-669396 | `eaa71284041b4c8390c32ade11286e16` | VFX | LEGACY_REFERENCE | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 173 | 키메라 | `ec7b571a85244965b296d26e6511e06d` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 174 | 도도 | `ee1dc1a6f4e6452b860a43ce291c62a3` | VFX | UNKNOWN | false | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 175 | animationclip-669873 | `f2193098cb774d9e820a5831e486a6a8` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 176 | animationclip-1040508 | `f4b476d028ea4c95b7bb26247954cdcf` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 177 | sprite-8935626 | `f527f0a168f34f31bd8b17e1059f3769` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 178 | 설산의 마녀 | `f55dd57a708e43238b64715c02bb06cc` | VFX | UNKNOWN | true | preview 시각 검수 + SkillTable 시각 필드 사용처 |
| 179 | sprite-8935754 | `f62b353e3f704eb097e427b7fc97980e` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 180 | animationclip-670288 | `f8a5f012719d401c9281b0a81617aafb` | UNCONFIRMED | RECENT_SECONDARY | true | 프리뷰만으로 기능 역할을 확정할 메타데이터 부족 |
| 181 | 화염 돌풍 | `f960bb921fb44bea91c95ea6b95f1d85` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
| 182 | 장난감 목마 | `fc4857ea48be477c9546c775e0f31d49` | MONSTER_CHARACTER | EXCLUDE_STYLE | true | 183개 preview contact sheet 시각 검수: 몬스터/캐릭터 본체가 주 형상 |
| 183 | sprite-8936578 | `fd051469cf104e0bb1597e6930619354` | ICON | LEGACY_REFERENCE | true | SkillTable icon_ruid 사용처 |
