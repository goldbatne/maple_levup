# area_12 루디브리엄 Manifest

- 처리 순서: 12
- 레벨 범위: Lv111~120
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 111 | area_12 | 루디브리엄 | m_brown_teddy | 브라운테니 | 46fd51a318b64738a36beeb3db02a970 | 확보 | s_mon_brown_teddy | 솜인형 완충 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_brown_teddy_브라운테니 |
| 2 | 113 | area_12 | 루디브리엄 | m_toy_trojan | 장난감 목마 | f9a2d6e8feaf4c90a3e00d022932fdaa | 확보 | s_mon_toy_trojan | 태엽 목마 돌진 | 액티브 | ATK 계수 3.55로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8; 6.8 거리 돌진 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.7초; 시전자가 목표 방향으로 돌진 | N | monsters/002_m_toy_trojan_장난감_목마 |
| 3 | 115 | area_12 | 루디브리엄 | m_master_robo | 마스터 로보 | f5d65e28cb0e4990bf5727015f22e0f1 | 확보 | s_mon_master_robo | 정밀 태엽회로 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_master_robo_마스터_로보 |
| 4 | 118 | area_12 | 루디브리엄 | m_chronos | 크로노스 | 1356c7ad27254459aaf789b51a75875c | 확보 | s_mon_chronos | 크로노스의 시간편린 | 액티브 | INT 계수 3.7로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.12초; 지속 0.8초 | N | monsters/004_m_chronos_크로노스 |
| 5 | 120 | area_12 | 루디브리엄 | m_timer | 타이머 | cbdd230e5cd34b7b9eeb1cd206d19f34 | 확보 | s_mon_timer | 시간 정지 충격 | 액티브 | INT 계수 4로 반경 6.2 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.78/0.88초 | Y | monsters/005_m_timer_타이머 |
