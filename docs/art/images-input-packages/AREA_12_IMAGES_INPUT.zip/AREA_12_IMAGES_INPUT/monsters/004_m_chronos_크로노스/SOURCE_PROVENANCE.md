# Source provenance — 크로노스 / 크로노스의 시간편린

- rebuild run: `20260913_153134`
- base package: `AREA_12_IMAGES_INPUT.zip`
- base package SHA-256: `150ba5d3b4ddfac119fa0345b7c4e612d86957010d191627dbd167406b31d358`
- preserved manifest monster image RUID: `1356c7ad27254459aaf789b51a75875c`
- preserved monster image status: `확보`
- preserved ids: `m_chronos` / `s_mon_chronos`
- preserved WHAT: `크로노스의 시간편린` / `액티브` / `INT 계수 3.7로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.12초; 지속 0.8초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
