# Monster Reference — 마스터 로보

- 작업 순번: 003
- level: 115
- Area: `area_12` / 루디브리엄
- monster_id: `m_master_robo`
- model_id: `masterrobo`
- image RUID: `f5d65e28cb0e4990bf5727015f22e0f1`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_master_robo`
- skill name/type: 정밀 태엽회로 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
