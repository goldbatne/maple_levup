# Source provenance — 마스터 로보 / 정밀 태엽회로

- rebuild run: `20260913_153134`
- base package: `AREA_12_IMAGES_INPUT.zip`
- base package SHA-256: `150ba5d3b4ddfac119fa0345b7c4e612d86957010d191627dbd167406b31d358`
- preserved manifest monster image RUID: `f5d65e28cb0e4990bf5727015f22e0f1`
- preserved monster image status: `확보`
- preserved ids: `m_master_robo` / `s_mon_master_robo`
- preserved WHAT: `정밀 태엽회로` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
