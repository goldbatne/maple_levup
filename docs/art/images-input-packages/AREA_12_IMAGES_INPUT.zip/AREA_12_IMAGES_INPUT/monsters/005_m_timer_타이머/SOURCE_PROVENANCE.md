# Source provenance — 타이머 / 시간 정지 충격

- rebuild run: `20260913_153134`
- base package: `AREA_12_IMAGES_INPUT.zip`
- base package SHA-256: `150ba5d3b4ddfac119fa0345b7c4e612d86957010d191627dbd167406b31d358`
- preserved manifest monster image RUID: `cbdd230e5cd34b7b9eeb1cd206d19f34`
- preserved monster image status: `확보`
- preserved ids: `m_timer` / `s_mon_timer`
- preserved WHAT: `시간 정지 충격` / `액티브` / `INT 계수 4로 반경 6.2 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.78/0.88초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
