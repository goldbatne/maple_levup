# Monster Reference — 타이머

- 작업 순번: 005
- level: 120
- Area: `area_12` / 루디브리엄
- monster_id: `m_timer`
- model_id: `timer`
- image RUID: `cbdd230e5cd34b7b9eeb1cd206d19f34`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_timer`
- skill name/type: 시간 정지 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
