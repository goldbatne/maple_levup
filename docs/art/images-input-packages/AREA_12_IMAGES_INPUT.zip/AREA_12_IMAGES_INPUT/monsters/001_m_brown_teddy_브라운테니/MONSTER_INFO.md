# Monster Reference — 브라운테니

- 작업 순번: 001
- level: 111
- Area: `area_12` / 루디브리엄
- monster_id: `m_brown_teddy`
- model_id: `brownteddy`
- image RUID: `46fd51a318b64738a36beeb3db02a970`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_brown_teddy`
- skill name/type: 솜인형 완충 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
