# Monster Reference — 장난감 목마

- 작업 순번: 002
- level: 113
- Area: `area_12` / 루디브리엄
- monster_id: `m_toy_trojan`
- model_id: `toytrojan`
- image RUID: `f9a2d6e8feaf4c90a3e00d022932fdaa`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_toy_trojan`
- skill name/type: 태엽 목마 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
