# Source provenance — 장난감 목마 / 태엽 목마 돌진

- rebuild run: `20260913_153134`
- base package: `AREA_12_IMAGES_INPUT.zip`
- base package SHA-256: `150ba5d3b4ddfac119fa0345b7c4e612d86957010d191627dbd167406b31d358`
- preserved manifest monster image RUID: `f9a2d6e8feaf4c90a3e00d022932fdaa`
- preserved monster image status: `확보`
- preserved ids: `m_toy_trojan` / `s_mon_toy_trojan`
- preserved WHAT: `태엽 목마 돌진` / `액티브` / `ATK 계수 3.55로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8; 6.8 거리 돌진` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.7초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
