# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 브라운테니 / 솜인형 완충: [monsters/001_m_brown_teddy_브라운테니/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_brown_teddy_브라운테니/DESIGN_REFERENCE_BRIEF.md) — water_shield, metal
- 장난감 목마 / 태엽 목마 돌진: [monsters/002_m_toy_trojan_장난감_목마/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_toy_trojan_장난감_목마/DESIGN_REFERENCE_BRIEF.md) — punch, metal
- 마스터 로보 / 정밀 태엽회로: [monsters/003_m_master_robo_마스터_로보/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_master_robo_마스터_로보/DESIGN_REFERENCE_BRIEF.md) — clock, metal
- 크로노스 / 크로노스의 시간편린: [monsters/004_m_chronos_크로노스/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_chronos_크로노스/DESIGN_REFERENCE_BRIEF.md) — clock, dark_magic
- 타이머 / 시간 정지 충격: [monsters/005_m_timer_타이머/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_timer_타이머/DESIGN_REFERENCE_BRIEF.md) — clock, punch