# area_10 아쿠아로드 Manifest

- 처리 순서: 10
- 레벨 범위: Lv91~100
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 91 | area_10 | 아쿠아로드 | m_bubble_fish | 버블피쉬 | c968133e75534a1b933d28da29c4e584 | 확보 | s_mon_bubble_fish | 기포막 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_bubble_fish_버블피쉬 |
| 2 | 93 | area_10 | 아쿠아로드 | m_mask_fish | 마스크피쉬 | fb9037f43fcd442a971ee007b9f7cc26 | 확보 | s_mon_mask_fish | 가면 아래의 감각 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_mask_fish_마스크피쉬 |
| 3 | 95 | area_10 | 아쿠아로드 | m_squid | 스퀴드 | 013b3e6ba18249269e4a1b85c536a0d9 | 확보 | s_mon_squid | 심해 먹물 폭발 | 액티브 | INT 계수 3로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.12초; 지속 0.82초 | N | monsters/003_m_squid_스퀴드 |
| 4 | 98 | area_10 | 아쿠아로드 | m_shark | 샤크 | b95f05df46124b3485d0a15bb79b10fb | 확보 | s_mon_shark | 포식자의 수류탄 | 액티브 | ATK 계수 3.15로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.22초; 지속 0.72초; 투사체 209c4567073b424e8d445cea7efb80e3가 목표 방향으로 이동 | N | monsters/004_m_shark_샤크 |
| 5 | 100 | area_10 | 아쿠아로드 | m_pianus | 피아누스 | 207c5d6dcee243ad9a141397244ba9a9 | 확보 | s_mon_pianus | 심해왕의 광선 | 액티브 | INT 계수 3.45로 반경 6.8 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.25초; 지속 0.82/0.95초 | Y | monsters/005_m_pianus_피아누스 |
