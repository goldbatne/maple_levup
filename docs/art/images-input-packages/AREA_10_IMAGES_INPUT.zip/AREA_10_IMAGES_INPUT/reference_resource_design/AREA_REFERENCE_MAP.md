# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 버블피쉬 / 기포막: [monsters/001_m_bubble_fish_버블피쉬/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_bubble_fish_버블피쉬/DESIGN_REFERENCE_BRIEF.md) — water_shield, water
- 마스크피쉬 / 가면 아래의 감각: [monsters/002_m_mask_fish_마스크피쉬/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_mask_fish_마스크피쉬/DESIGN_REFERENCE_BRIEF.md) — sound, water_shield
- 스퀴드 / 심해 먹물 폭발: [monsters/003_m_squid_스퀴드/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_squid_스퀴드/DESIGN_REFERENCE_BRIEF.md) — mist, water
- 샤크 / 포식자의 수류탄: [monsters/004_m_shark_샤크/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_shark_샤크/DESIGN_REFERENCE_BRIEF.md) — bubble, water
- 피아누스 / 심해왕의 광선: [monsters/005_m_pianus_피아누스/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_pianus_피아누스/DESIGN_REFERENCE_BRIEF.md) — earth_breath, water