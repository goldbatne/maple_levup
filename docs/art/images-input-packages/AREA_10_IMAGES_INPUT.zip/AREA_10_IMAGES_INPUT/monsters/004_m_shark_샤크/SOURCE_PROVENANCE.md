# Source provenance — 샤크 / 포식자의 수류탄

- rebuild run: `20260913_153134`
- base package: `AREA_10_IMAGES_INPUT.zip`
- base package SHA-256: `b7ee67d63cc035be0e22b61daf558822a438de513b5ff50a8fb266b2a498d673`
- preserved manifest monster image RUID: `b95f05df46124b3485d0a15bb79b10fb`
- preserved monster image status: `확보`
- preserved ids: `m_shark` / `s_mon_shark`
- preserved WHAT: `포식자의 수류탄` / `액티브` / `ATK 계수 3.15로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.22초; 지속 0.72초; 투사체 209c4567073b424e8d445cea7efb80e3가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
