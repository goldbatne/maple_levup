# Monster Reference — 샤크

- 작업 순번: 004
- level: 98
- Area: `area_10` / 아쿠아로드
- monster_id: `m_shark`
- model_id: `shark`
- image RUID: `b95f05df46124b3485d0a15bb79b10fb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_shark`
- skill name/type: 포식자의 수류탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
