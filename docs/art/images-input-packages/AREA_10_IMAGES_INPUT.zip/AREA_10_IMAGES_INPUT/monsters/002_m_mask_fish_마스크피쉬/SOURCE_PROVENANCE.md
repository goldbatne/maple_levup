# Source provenance — 마스크피쉬 / 가면 아래의 감각

- rebuild run: `20260913_153134`
- base package: `AREA_10_IMAGES_INPUT.zip`
- base package SHA-256: `b7ee67d63cc035be0e22b61daf558822a438de513b5ff50a8fb266b2a498d673`
- preserved manifest monster image RUID: `fb9037f43fcd442a971ee007b9f7cc26`
- preserved monster image status: `확보`
- preserved ids: `m_mask_fish` / `s_mon_mask_fish`
- preserved WHAT: `가면 아래의 감각` / `패시브` / `보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
