# Monster Reference — 마스크피쉬

- 작업 순번: 002
- level: 93
- Area: `area_10` / 아쿠아로드
- monster_id: `m_mask_fish`
- model_id: `maskfish`
- image RUID: `fb9037f43fcd442a971ee007b9f7cc26`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mask_fish`
- skill name/type: 가면 아래의 감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
