# Source provenance — 버블피쉬 / 기포막

- rebuild run: `20260913_153134`
- base package: `AREA_10_IMAGES_INPUT.zip`
- base package SHA-256: `b7ee67d63cc035be0e22b61daf558822a438de513b5ff50a8fb266b2a498d673`
- preserved manifest monster image RUID: `c968133e75534a1b933d28da29c4e584`
- preserved monster image status: `확보`
- preserved ids: `m_bubble_fish` / `s_mon_bubble_fish`
- preserved WHAT: `기포막` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
