# Monster Reference — 버블피쉬

- 작업 순번: 001
- level: 91
- Area: `area_10` / 아쿠아로드
- monster_id: `m_bubble_fish`
- model_id: `bubblefish`
- image RUID: `c968133e75534a1b933d28da29c4e584`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_bubble_fish`
- skill name/type: 기포막 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
