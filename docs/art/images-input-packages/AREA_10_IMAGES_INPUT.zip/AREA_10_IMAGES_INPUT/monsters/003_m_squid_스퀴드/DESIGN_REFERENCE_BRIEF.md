# 스퀴드 — 심해 먹물 폭발: 실제 디자인 참조

monster_id: `m_squid` / skill_id: `s_mon_squid` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 농도 높은 먹물핵이 물속에서 둥글게 폭발하는 검은 구름. ‘스퀴드 / 심해 먹물 폭발’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 먹물 흑남 #202A42; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 심해 자주 #625079; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘먹물핵’, 보조 효과 1개는 ‘둥근 심해 폭발’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/003_m_squid_스퀴드/MONSTER_IMAGE.png`

RUID: `013b3e6ba18249269e4a1b85c536a0d9` / SHA-256: `cb5bcd900206f14e38c207d3a057e6fd8f550991aa9a66697d4ff8e3709d9465`

## 이 스킬에 적용할 구체적인 디자인
농밀한 먹물 코어가 수중 검은 구름으로 터진다. 부드러운 외곽과 응집한 중앙을 나누며 하얀 포자나 불꽃으로 바꾸지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 포이즌 미스트 / `skill/214.img/skill/2141004`
- 관찰한 표현: 흐릿한 외곽 안쪽에 덩어리별 농도와 중간톤이 남는 기체 층
- 가져오지 않을 요소: 초록 독 색상과 독의 의미를 포자·먹물로 옮기지 않는다
- special: `reference_resource_design/mist/source/876042858c574e829697ce796ea71f99.gif` / SHA-256 `cea2acc7650f23f690a2b31f6e98ecb0dcbfc91267e515071f17cfddeb5b29f7`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/mist/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F000.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F002.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F004.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F006.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F007.png`
- tile: `reference_resource_design/mist/source/ae5eacd6c09c48a1b0cbaf88dc7edb50.gif` / SHA-256 `8e932ef2c8522668c97e19eea1e728db33cc7b78a977a120e085a1ad420a6142`
  전체 연속 PNG 24장과 GIF 타이밍은 `reference_resource_design/mist/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F000.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F006.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F012.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F018.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F023.png`
- icon: `reference_resource_design/mist/source/c6a8f199cd68461c9f0373565e857bee.png` / SHA-256 `aba0bf9069b562ed9d96d479261dfa88467832a762f76c916314f08badbcaf00`

### 분출 : 너울이는 강 VI / `skill/16214.img/skill/162141004`
- 관찰한 표현: 얇은 물 테두리와 밝은 물방울이 터진 뒤 분리되어 사라지는 단계
- 가져오지 않을 요소: 원형 타격 모양을 모든 물 스킬의 기본 모양으로 강제하지 않는다
- hit/0: `reference_resource_design/water/source/53b30bb5fef2424ea460109e8304aa25.gif` / SHA-256 `17482870118412680d6663b03a18385c5a0fbc8818107ac28c55ff5eb9581769`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/water/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/water/frames/53b30bb5fef2424ea460109e8304aa25_F000.png`
  - `reference_resource_design/water/frames/53b30bb5fef2424ea460109e8304aa25_F002.png`
  - `reference_resource_design/water/frames/53b30bb5fef2424ea460109e8304aa25_F004.png`
  - `reference_resource_design/water/frames/53b30bb5fef2424ea460109e8304aa25_F006.png`
  - `reference_resource_design/water/frames/53b30bb5fef2424ea460109e8304aa25_F007.png`
- icon: `reference_resource_design/water/source/a3ce227041af431a9a81911c1764ff47.png` / SHA-256 `53c8e203fcab63b6e0da582f17804bb5be29f2c88dbad900e7e061cd05ad8373`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/003_m_squid_스퀴드/MONSTER_IMAGE.png` / SHA-256 `cb5bcd900206f14e38c207d3a057e6fd8f550991aa9a66697d4ff8e3709d9465`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_squid_OFFICIAL_VFX_BOARD.png` / SHA-256 `65a4c55fe05ea34b4cecd01b25d0252fdc161ee05ba13dbba5bf8c39c3fa9fe1`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_squid_AREA00_FINISH_BOARD.png` / SHA-256 `481a48b081cecdf1bc416c4ed6b486c6e07a348ca1cb627bed3a1b5ba20c2cc9`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_squid_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
