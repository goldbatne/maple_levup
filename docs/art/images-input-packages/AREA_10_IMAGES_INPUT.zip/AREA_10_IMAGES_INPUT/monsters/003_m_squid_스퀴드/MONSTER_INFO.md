# Monster Reference — 스퀴드

- 작업 순번: 003
- level: 95
- Area: `area_10` / 아쿠아로드
- monster_id: `m_squid`
- model_id: `squid`
- image RUID: `013b3e6ba18249269e4a1b85c536a0d9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_squid`
- skill name/type: 심해 먹물 폭발 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
