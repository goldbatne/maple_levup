# Source provenance — 스퀴드 / 심해 먹물 폭발

- rebuild run: `20260913_153134`
- base package: `AREA_10_IMAGES_INPUT.zip`
- base package SHA-256: `b7ee67d63cc035be0e22b61daf558822a438de513b5ff50a8fb266b2a498d673`
- preserved manifest monster image RUID: `013b3e6ba18249269e4a1b85c536a0d9`
- preserved monster image status: `확보`
- preserved ids: `m_squid` / `s_mon_squid`
- preserved WHAT: `심해 먹물 폭발` / `액티브` / `INT 계수 3로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.12초; 지속 0.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
