# Monster Reference — 피아누스

- 작업 순번: 005
- level: 100
- Area: `area_10` / 아쿠아로드
- monster_id: `m_pianus`
- model_id: `pianus`
- image RUID: `207c5d6dcee243ad9a141397244ba9a9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_pianus`
- skill name/type: 심해왕의 광선 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
