# Source provenance — 피아누스 / 심해왕의 광선

- rebuild run: `20260913_153134`
- base package: `AREA_10_IMAGES_INPUT.zip`
- base package SHA-256: `b7ee67d63cc035be0e22b61daf558822a438de513b5ff50a8fb266b2a498d673`
- preserved manifest monster image RUID: `207c5d6dcee243ad9a141397244ba9a9`
- preserved monster image status: `확보`
- preserved ids: `m_pianus` / `s_mon_pianus`
- preserved WHAT: `심해왕의 광선` / `액티브` / `INT 계수 3.45로 반경 6.8 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.25초; 지속 0.82/0.95초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
