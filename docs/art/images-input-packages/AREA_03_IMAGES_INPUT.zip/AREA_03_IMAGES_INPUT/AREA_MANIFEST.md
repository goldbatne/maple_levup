# area_03 엘리니아 Manifest

- 처리 순서: 3
- 레벨 범위: Lv11~20
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 11 | area_03 | 엘리니아 | m_slime | 슬라임 | 50faf654ee5d479cb2958edce9feaef0 | 확보 | s_mon_slime | 끈적한 몸통 | 액티브 | ATK 계수 1.15로 단일 대상 피해; 4초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.62/0.52초 | N | monsters/001_m_slime_슬라임 |
| 2 | 13 | area_03 | 엘리니아 | m_dark_stump | 다크 스텀프 | ed3908e24d694bb786023fc1ed073489 | 확보 | s_mon_dark_stump | 단단한 밑동 | 버프 | 자신에게 5초 동안 피해 45% 감소 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.75/0.75초 | N | monsters/002_m_dark_stump_다크_스텀프 |
| 3 | 15 | area_03 | 엘리니아 | m_bubbling | 버블링 | e24531def0ec4687b2c5de2cfb32b02e | 확보 | s_mon_bubbling | 물방울 마력 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_bubbling_버블링 |
| 4 | 18 | area_03 | 엘리니아 | m_fairy | 페어리 | 1ed0265245594bf0904ceb88ecaf16ba | 확보 | s_mon_fairy | 요정의 마법가루 | 액티브 | INT 계수 1.4로 반경 3 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.9초 | N | monsters/004_m_fairy_페어리 |
| 5 | 20 | area_03 | 엘리니아 | m_faust | 파우스트 | 9922e94142f9413aa5359297f852a5a2 | 확보 | s_mon_faust | 저주의 인형 | 액티브 | INT 계수 1.55로 반경 4 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.9/0.75초; 투사체 49b21aaa1d574ba787149841a31bf1a5가 목표 방향으로 이동 | Y | monsters/005_m_faust_파우스트 |
