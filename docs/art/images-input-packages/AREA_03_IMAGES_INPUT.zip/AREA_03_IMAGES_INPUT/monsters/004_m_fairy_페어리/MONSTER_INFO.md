# Monster Reference — 페어리

- 작업 순번: 004
- level: 18
- Area: `area_03` / 엘리니아
- monster_id: `m_fairy`
- model_id: `fairy`
- image RUID: `1ed0265245594bf0904ceb88ecaf16ba`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_fairy`
- skill name/type: 요정의 마법가루 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
