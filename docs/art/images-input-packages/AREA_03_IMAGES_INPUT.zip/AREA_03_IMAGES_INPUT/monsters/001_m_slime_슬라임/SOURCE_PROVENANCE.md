# Source provenance — 슬라임 / 끈적한 몸통

- rebuild run: `20260913_153134`
- base package: `AREA_03_IMAGES_INPUT.zip`
- base package SHA-256: `fba164cb69510ea5f4be6853dc7b7d0746b10f37715e2adfb2aba61c9497afaf`
- preserved manifest monster image RUID: `50faf654ee5d479cb2958edce9feaef0`
- preserved monster image status: `확보`
- preserved ids: `m_slime` / `s_mon_slime`
- preserved WHAT: `끈적한 몸통` / `액티브` / `ATK 계수 1.15로 단일 대상 피해; 4초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.62/0.52초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
