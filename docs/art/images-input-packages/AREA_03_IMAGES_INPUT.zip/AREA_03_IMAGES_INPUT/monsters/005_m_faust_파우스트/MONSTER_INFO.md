# Monster Reference — 파우스트

- 작업 순번: 005
- level: 20
- Area: `area_03` / 엘리니아
- monster_id: `m_faust`
- model_id: `faust`
- image RUID: `9922e94142f9413aa5359297f852a5a2`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_faust`
- skill name/type: 저주의 인형 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
