# Source provenance — 파우스트 / 저주의 인형

- rebuild run: `20260913_153134`
- base package: `AREA_03_IMAGES_INPUT.zip`
- base package SHA-256: `fba164cb69510ea5f4be6853dc7b7d0746b10f37715e2adfb2aba61c9497afaf`
- preserved manifest monster image RUID: `9922e94142f9413aa5359297f852a5a2`
- preserved monster image status: `확보`
- preserved ids: `m_faust` / `s_mon_faust`
- preserved WHAT: `저주의 인형` / `액티브` / `INT 계수 1.55로 반경 4 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.9/0.75초; 투사체 49b21aaa1d574ba787149841a31bf1a5가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
