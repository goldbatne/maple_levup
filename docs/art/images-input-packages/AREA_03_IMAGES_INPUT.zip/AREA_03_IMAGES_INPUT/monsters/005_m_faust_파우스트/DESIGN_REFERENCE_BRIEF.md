# 파우스트 — 저주의 인형: 실제 디자인 참조

monster_id: `m_faust` / skill_id: `s_mon_faust` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 실로 묶인 인형 표식과 아래로 떨어지는 자주색 저주 침. ‘파우스트 / 저주의 인형’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 저주 자주 #734B91; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 인형 적갈 #A85A61; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘실 묶인 인형 표식’, 보조 효과 1개는 ‘저주 침’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/005_m_faust_파우스트/MONSTER_IMAGE.png`

RUID: `9922e94142f9413aa5359297f852a5a2` / SHA-256: `f63eb17a6ef230009335f5595e5373b700ce82831274c8273307aea0cef835d4`

## 이 스킬에 적용할 구체적인 디자인
실에 묶인 인형 표식과 떨어지는 가느다란 저주 침이 구분되어야 한다. 숫자 표식·공식 삼각 칼날·실제 인형 캐릭터는 넣지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 커스 마크 / `skill/15200.img/skill/152000010`
- 관찰한 표현: 짙은 보라 외곽 안에서 날카로운 밝은 타격면이 갈라지는 처리
- 가져오지 않을 요소: 숫자 1이 있는 mob/1 표식을 참조 입력에서 제외한다
- hit/0: `reference_resource_design/curse/source/48eb1b87aece406f9d864f50612b162a.gif` / SHA-256 `08a139e0290f0260c9ac0d83840594398954f7bc4a923dea860bc490cc09d6c8`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/curse/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/curse/frames/48eb1b87aece406f9d864f50612b162a_F000.png`
  - `reference_resource_design/curse/frames/48eb1b87aece406f9d864f50612b162a_F002.png`
  - `reference_resource_design/curse/frames/48eb1b87aece406f9d864f50612b162a_F004.png`
  - `reference_resource_design/curse/frames/48eb1b87aece406f9d864f50612b162a_F006.png`
  - `reference_resource_design/curse/frames/48eb1b87aece406f9d864f50612b162a_F007.png`
- icon: `reference_resource_design/curse/source/f7042e499bbc40acb9e2bf58c57fa86f.png` / SHA-256 `90554da2f32896b8cf10aa66223b14cd03ab18bbe3c62122741f884550ad17a0`

### [처형] 포이즌 니들 / `skill/6312.img/skill/63121006`
- 관찰한 표현: 날카로운 유색 면과 어두운 잔상이 분리되는 짧은 절단광
- 가져오지 않을 요소: 삼각 베기 덩어리를 침·가시 자체로 복제하지 않는다
- effect/0: `reference_resource_design/needle/source/c0743765873d43bf965f0fb21af31073.png` / SHA-256 `5df66e15e87f369baadeaba752189cee1c0d9d6e7e961536acca28ed23adcac1`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/c0743765873d43bf965f0fb21af31073_F000.png`
- effect/1: `reference_resource_design/needle/source/328ab7becdbe429dbf30664eeead7f32.png` / SHA-256 `40aca4ec90ea229d84912ec1112a38e61eb7053706c76956ce16f9490808bdc8`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/328ab7becdbe429dbf30664eeead7f32_F000.png`
- effect/2: `reference_resource_design/needle/source/65dc52b274e64a4d9eb5b46398cbed2e.png` / SHA-256 `066a9b72547d6f2ef9f1e06bfe7eafad130ba9d2ef6da2f9208cb1aa39ace329`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/65dc52b274e64a4d9eb5b46398cbed2e_F000.png`
- icon: `reference_resource_design/needle/source/c835fd4d1ab44279bc697053162911ee.png` / SHA-256 `3b93bd39a3629fb851828803e0f6078306bdb4b1c12a1f194bed5247ca789580`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/005_m_faust_파우스트/MONSTER_IMAGE.png` / SHA-256 `f63eb17a6ef230009335f5595e5373b700ce82831274c8273307aea0cef835d4`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_faust_OFFICIAL_VFX_BOARD.png` / SHA-256 `3d4d32d8d4f1189d873f0ff17137263879c56dbd202f49bd63a35ca9d9ca55a0`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_faust_AREA00_FINISH_BOARD.png` / SHA-256 `760d471a703c693184683569931f0a7bf0559aabcb26807b4a3a5eee8fe09f81`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_faust_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
