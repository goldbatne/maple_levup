# Source provenance — 버블링 / 물방울 마력

- rebuild run: `20260913_153134`
- base package: `AREA_03_IMAGES_INPUT.zip`
- base package SHA-256: `fba164cb69510ea5f4be6853dc7b7d0746b10f37715e2adfb2aba61c9497afaf`
- preserved manifest monster image RUID: `e24531def0ec4687b2c5de2cfb32b02e`
- preserved monster image status: `확보`
- preserved ids: `m_bubbling` / `s_mon_bubbling`
- preserved WHAT: `물방울 마력` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
