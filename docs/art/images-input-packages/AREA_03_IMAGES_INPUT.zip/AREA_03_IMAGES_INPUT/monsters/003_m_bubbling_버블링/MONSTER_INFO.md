# Monster Reference — 버블링

- 작업 순번: 003
- level: 15
- Area: `area_03` / 엘리니아
- monster_id: `m_bubbling`
- model_id: `bubbling`
- image RUID: `e24531def0ec4687b2c5de2cfb32b02e`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_bubbling`
- skill name/type: 물방울 마력 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
