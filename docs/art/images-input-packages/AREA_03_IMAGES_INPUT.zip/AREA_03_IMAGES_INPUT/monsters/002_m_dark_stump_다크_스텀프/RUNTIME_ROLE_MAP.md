# Runtime role map — 다크 스텀프 / 단단한 밑동

- monster_id: `m_dark_stump`
- skill_id: `s_mon_dark_stump`
- skill_type: `버프`
- required NEW_ART roles: **ICON | VFX**
- declared current motion: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.75/0.75초
- role decision: GENERATION_SPEC의 frame-separated VFX와 기본 ICON이 필수 NEW_ART다.
- base ICON is 256x256 RGBA. disabled/mouseover variants are not required by this INPUT.
- game scale, offset, RUID, AnimationClip settings are outside this image-production package and must not be changed.
