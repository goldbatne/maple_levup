# Source provenance — 다크 스텀프 / 단단한 밑동

- rebuild run: `20260913_153134`
- base package: `AREA_03_IMAGES_INPUT.zip`
- base package SHA-256: `fba164cb69510ea5f4be6853dc7b7d0746b10f37715e2adfb2aba61c9497afaf`
- preserved manifest monster image RUID: `ed3908e24d694bb786023fc1ed073489`
- preserved monster image status: `확보`
- preserved ids: `m_dark_stump` / `s_mon_dark_stump`
- preserved WHAT: `단단한 밑동` / `버프` / `자신에게 5초 동안 피해 45% 감소` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.75/0.75초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
