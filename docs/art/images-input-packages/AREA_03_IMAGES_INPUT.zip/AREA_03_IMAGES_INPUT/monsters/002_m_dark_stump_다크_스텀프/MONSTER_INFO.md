# Monster Reference — 다크 스텀프

- 작업 순번: 002
- level: 13
- Area: `area_03` / 엘리니아
- monster_id: `m_dark_stump`
- model_id: `darkstump`
- image RUID: `ed3908e24d694bb786023fc1ed073489`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_stump`
- skill name/type: 단단한 밑동 / 버프

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
