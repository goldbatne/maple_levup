# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 슬라임 / 끈적한 몸통: [monsters/001_m_slime_슬라임/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_slime_슬라임/DESIGN_REFERENCE_BRIEF.md) — water, water_shield
- 다크 스텀프 / 단단한 밑동: [monsters/002_m_dark_stump_다크_스텀프/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_dark_stump_다크_스텀프/DESIGN_REFERENCE_BRIEF.md) — metal, dark_barrier
- 버블링 / 물방울 마력: [monsters/003_m_bubbling_버블링/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_bubbling_버블링/DESIGN_REFERENCE_BRIEF.md) — water_shield, bubble
- 페어리 / 요정의 마법가루: [monsters/004_m_fairy_페어리/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_fairy_페어리/DESIGN_REFERENCE_BRIEF.md) — nature, garden
- 파우스트 / 저주의 인형: [monsters/005_m_faust_파우스트/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_faust_파우스트/DESIGN_REFERENCE_BRIEF.md) — curse, needle