# area_02 페리온 Manifest

- 처리 순서: 4
- 레벨 범위: Lv10~42
- 포획 가능 몬스터: 8종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 10 | area_02 | 페리온 | m_stone_golem | 스톤골렘 | 23761b84fca14bbfa671436791e4e0bb | 확보 | s_mon_stone | 암석 피부 | 버프 | 자신에게 5초 동안 피해 50% 감소 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.72초 | N | monsters/001_m_stone_golem_스톤골렘 |
| 2 | 18 | area_02 | 페리온 | m_axe_stump | 엑스텀프 | 9d4f9e8f572548f692438ffa817eb52d | 확보 | s_mon_axe_stump | 도끼 휘두르기 | 액티브 | ATK 계수 1.3로 반경 3 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.14초; 지속 0.55/0.48초 | N | monsters/002_m_axe_stump_엑스텀프 |
| 3 | 22 | area_02 | 페리온 | m_dark_axe_stump | 다크 엑스텀프 | fd35894dd92c4e3b8885e59b0f4d3394 | 확보 | s_mon_dark_axe_stump | 어둠의 뿌리 | 액티브 | INT 계수 1.5로 반경 4 범위 대상 제한 없음 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.82/0.82초 | N | monsters/003_m_dark_axe_stump_다크_엑스텀프 |
| 4 | 26 | area_02 | 페리온 | m_wild_boar | 와일드보어 | af64c62c1dcf427998c3c52f0a060fec | 확보 | s_mon_wild_boar | 저돌 맹진 | 액티브 | ATK 계수 1.5로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5 거리 돌진 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.55/0.65초; 시전자가 목표 방향으로 돌진 | N | monsters/004_m_wild_boar_와일드보어 |
| 5 | 28 | area_02 | 페리온 | m_iron_hog | 아이언 호그 | eadfe08070d343a9afafe0fd6290f1c6 | 확보 | s_mon_iron_hog | 강철 발굽 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/005_m_iron_hog_아이언_호그 |
| 6 | 30 | area_02 | 페리온 | m_skeleton_commander | 스켈레톤 지휘관 | ed882269a5d543318ad73e7032632960 | 확보 | s_mon_skeleton_commander | 뼈 무덤 | 액티브 | ATK 계수 2로 반경 5 범위 최대 2대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.18초; 지속 0.58/0.62/0.5초 | N | monsters/006_m_skeleton_commander_스켈레톤_지휘관 |
| 7 | 32 | area_02 | 페리온 | m_fire_boar | 파이어보어 | 67523b05f66f470cb86b2c6cc46af861 | 확보 | s_mon_fire_boar | 화염 돌풍 | 액티브 | ATK 계수 1.7로 반경 4.5 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.52/0.7초 | N | monsters/007_m_fire_boar_파이어보어 |
| 8 | 42 | area_02 | 페리온 | m_stumpy | 스텀피 | 0b6c2f6faccc44da980ce832ab636bf6 | 확보 | s_mon_stumpy | 고목의 생기탄 | 액티브 | INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | 투사체 c6b3f052e977479ea5ad5329ce0981ca가 목표 방향으로 이동 | Y | monsters/008_m_stumpy_스텀피 |
