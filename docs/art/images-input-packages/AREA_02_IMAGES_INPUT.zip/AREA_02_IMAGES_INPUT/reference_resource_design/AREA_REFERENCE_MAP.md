# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 스톤골렘 / 암석 피부: [monsters/001_m_stone_golem_스톤골렘/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_stone_golem_스톤골렘/DESIGN_REFERENCE_BRIEF.md) — earth, metal
- 엑스텀프 / 도끼 휘두르기: [monsters/002_m_axe_stump_엑스텀프/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_axe_stump_엑스텀프/DESIGN_REFERENCE_BRIEF.md) — punch, needle
- 다크 엑스텀프 / 어둠의 뿌리: [monsters/003_m_dark_axe_stump_다크_엑스텀프/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_dark_axe_stump_다크_엑스텀프/DESIGN_REFERENCE_BRIEF.md) — earth, dark_magic
- 와일드보어 / 저돌 맹진: [monsters/004_m_wild_boar_와일드보어/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_wild_boar_와일드보어/DESIGN_REFERENCE_BRIEF.md) — punch, sand
- 아이언 호그 / 강철 발굽: [monsters/005_m_iron_hog_아이언_호그/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_iron_hog_아이언_호그/DESIGN_REFERENCE_BRIEF.md) — punch, metal
- 스켈레톤 지휘관 / 뼈 무덤: [monsters/006_m_skeleton_commander_스켈레톤_지휘관/DESIGN_REFERENCE_BRIEF.md](../monsters/006_m_skeleton_commander_스켈레톤_지휘관/DESIGN_REFERENCE_BRIEF.md) — earth, quake
- 파이어보어 / 화염 돌풍: [monsters/007_m_fire_boar_파이어보어/DESIGN_REFERENCE_BRIEF.md](../monsters/007_m_fire_boar_파이어보어/DESIGN_REFERENCE_BRIEF.md) — fire, punch
- 스텀피 / 고목의 생기탄: [monsters/008_m_stumpy_스텀피/DESIGN_REFERENCE_BRIEF.md](../monsters/008_m_stumpy_스텀피/DESIGN_REFERENCE_BRIEF.md) — nature, bubble