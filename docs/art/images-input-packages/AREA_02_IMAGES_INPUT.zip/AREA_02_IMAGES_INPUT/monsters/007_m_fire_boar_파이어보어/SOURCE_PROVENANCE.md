# Source provenance — 파이어보어 / 화염 돌풍

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `67523b05f66f470cb86b2c6cc46af861`
- preserved monster image status: `확보`
- preserved ids: `m_fire_boar` / `s_mon_fire_boar`
- preserved WHAT: `화염 돌풍` / `액티브` / `ATK 계수 1.7로 반경 4.5 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.52/0.7초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
