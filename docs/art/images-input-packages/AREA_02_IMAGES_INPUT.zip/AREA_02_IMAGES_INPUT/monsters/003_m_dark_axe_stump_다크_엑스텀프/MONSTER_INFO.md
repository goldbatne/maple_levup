# Monster Reference — 다크 엑스텀프

- 작업 순번: 003
- level: 22
- Area: `area_02` / 페리온
- monster_id: `m_dark_axe_stump`
- model_id: `darkaxestump`
- image RUID: `fd35894dd92c4e3b8885e59b0f4d3394`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_axe_stump`
- skill name/type: 어둠의 뿌리 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
