# Source provenance — 다크 엑스텀프 / 어둠의 뿌리

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `fd35894dd92c4e3b8885e59b0f4d3394`
- preserved monster image status: `확보`
- preserved ids: `m_dark_axe_stump` / `s_mon_dark_axe_stump`
- preserved WHAT: `어둠의 뿌리` / `액티브` / `INT 계수 1.5로 반경 4 범위 대상 제한 없음 피해; 5초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.82/0.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
