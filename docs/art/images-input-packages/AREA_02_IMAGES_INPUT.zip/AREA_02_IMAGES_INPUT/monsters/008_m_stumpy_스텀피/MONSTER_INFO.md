# Monster Reference — 스텀피

- 작업 순번: 008
- level: 42
- Area: `area_02` / 페리온
- monster_id: `m_stumpy`
- model_id: `stumpy`
- image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_stumpy`
- skill name/type: 고목의 생기탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
