# Source provenance — 스텀피 / 고목의 생기탄

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- preserved monster image status: `확보`
- preserved ids: `m_stumpy` / `s_mon_stumpy`
- preserved WHAT: `고목의 생기탄` / `액티브` / `INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `투사체 c6b3f052e977479ea5ad5329ce0981ca가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
