# Monster Reference — 엑스텀프

- 작업 순번: 002
- level: 18
- Area: `area_02` / 페리온
- monster_id: `m_axe_stump`
- model_id: `axestump`
- image RUID: `9d4f9e8f572548f692438ffa817eb52d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_axe_stump`
- skill name/type: 도끼 휘두르기 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
