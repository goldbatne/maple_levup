# Source provenance — 엑스텀프 / 도끼 휘두르기

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `9d4f9e8f572548f692438ffa817eb52d`
- preserved monster image status: `확보`
- preserved ids: `m_axe_stump` / `s_mon_axe_stump`
- preserved WHAT: `도끼 휘두르기` / `액티브` / `ATK 계수 1.3로 반경 3 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.14초; 지속 0.55/0.48초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
