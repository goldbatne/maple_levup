# Source provenance — 아이언 호그 / 강철 발굽

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `eadfe08070d343a9afafe0fd6290f1c6`
- preserved monster image status: `확보`
- preserved ids: `m_iron_hog` / `s_mon_iron_hog`
- preserved WHAT: `강철 발굽` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
