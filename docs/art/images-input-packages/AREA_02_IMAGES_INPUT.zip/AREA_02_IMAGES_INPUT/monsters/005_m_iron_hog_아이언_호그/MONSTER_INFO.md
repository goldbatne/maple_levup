# Monster Reference — 아이언 호그

- 작업 순번: 005
- level: 28
- Area: `area_02` / 페리온
- monster_id: `m_iron_hog`
- model_id: `ironhog`
- image RUID: `eadfe08070d343a9afafe0fd6290f1c6`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_iron_hog`
- skill name/type: 강철 발굽 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
