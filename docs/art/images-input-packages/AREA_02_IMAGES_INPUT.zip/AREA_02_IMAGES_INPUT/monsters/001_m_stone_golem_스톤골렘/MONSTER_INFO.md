# Monster Reference — 스톤골렘

- 작업 순번: 001
- level: 10
- Area: `area_02` / 페리온
- monster_id: `m_stone_golem`
- model_id: `stone_golem`
- image RUID: `23761b84fca14bbfa671436791e4e0bb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_stone`
- skill name/type: 암석 피부 / 버프

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
