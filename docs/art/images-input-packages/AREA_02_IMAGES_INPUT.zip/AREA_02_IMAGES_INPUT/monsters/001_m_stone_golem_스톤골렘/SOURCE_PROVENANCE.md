# Source provenance — 스톤골렘 / 암석 피부

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `23761b84fca14bbfa671436791e4e0bb`
- preserved monster image status: `확보`
- preserved ids: `m_stone_golem` / `s_mon_stone`
- preserved WHAT: `암석 피부` / `버프` / `자신에게 5초 동안 피해 50% 감소` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.72초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
