# Monster Reference — 스켈레톤 지휘관

- 작업 순번: 006
- level: 30
- Area: `area_02` / 페리온
- monster_id: `m_skeleton_commander`
- model_id: `skeletoncommander`
- image RUID: `ed882269a5d543318ad73e7032632960`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_skeleton_commander`
- skill name/type: 뼈 무덤 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
