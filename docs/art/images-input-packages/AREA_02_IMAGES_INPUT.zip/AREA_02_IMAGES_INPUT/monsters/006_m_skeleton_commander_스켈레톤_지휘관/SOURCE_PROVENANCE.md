# Source provenance — 스켈레톤 지휘관 / 뼈 무덤

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `ed882269a5d543318ad73e7032632960`
- preserved monster image status: `확보`
- preserved ids: `m_skeleton_commander` / `s_mon_skeleton_commander`
- preserved WHAT: `뼈 무덤` / `액티브` / `ATK 계수 2로 반경 5 범위 최대 2대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.18초; 지속 0.58/0.62/0.5초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
