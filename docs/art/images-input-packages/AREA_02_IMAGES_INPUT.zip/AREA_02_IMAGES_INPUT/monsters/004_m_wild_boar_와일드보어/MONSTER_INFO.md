# Monster Reference — 와일드보어

- 작업 순번: 004
- level: 26
- Area: `area_02` / 페리온
- monster_id: `m_wild_boar`
- model_id: `wildboar`
- image RUID: `af64c62c1dcf427998c3c52f0a060fec`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wild_boar`
- skill name/type: 저돌 맹진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
