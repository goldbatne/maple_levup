# Source provenance — 와일드보어 / 저돌 맹진

- rebuild run: `20260913_153134`
- base package: `AREA_02_IMAGES_INPUT.zip`
- base package SHA-256: `c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee`
- preserved manifest monster image RUID: `af64c62c1dcf427998c3c52f0a060fec`
- preserved monster image status: `확보`
- preserved ids: `m_wild_boar` / `s_mon_wild_boar`
- preserved WHAT: `저돌 맹진` / `액티브` / `ATK 계수 1.5로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5 거리 돌진` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.55/0.65초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
