# 와일드보어 — 저돌 맹진: 실제 디자인 참조

monster_id: `m_wild_boar` / skill_id: `s_mon_wild_boar` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 멧돼지 어금니를 닮은 두 갈래 전방 압축선과 흙먼지. ‘와일드보어 / 저돌 맹진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 황토 갈색 #9B633D; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 먼지 금갈 #D6A65D; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘쌍 어금니’, 보조 효과 1개는 ‘돌진 흙먼지’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_wild_boar_와일드보어/MONSTER_IMAGE.png`

RUID: `af64c62c1dcf427998c3c52f0a060fec` / SHA-256: `f620027b677baa72da586d2a6b6447fdb2ad2ea055a9f2e062bba4e0588ff7da`

## 이 스킬에 적용할 구체적인 디자인
두 엄니 방향이 전방으로 모이며 압축 충격을 만든다. 갈색 먼지는 뒤에만 남기고 회오리나 주먹을 넣지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 스크류 펀치 / 스크류 펀치 강화 / `skill/40000.img/skill/400004139`
- 관찰한 표현: 작은 압축 코어가 전진해 충격면으로 퍼지고 조각으로 풀리는 운동
- 가져오지 않을 요소: 공식 주먹·원형 추진체를 목표의 발굽·리본·엄니로 대체 복사하지 않는다
- effect: `reference_resource_design/punch/source/4f97bf6aecbc4687aa83e60e763aaf89.gif` / SHA-256 `d0334c271d254be51ba450d7cde7e1fc1518338a90a07345ff95ccf4c12df2bb`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/punch/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F000.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F002.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F005.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F007.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F009.png`
- hit: `reference_resource_design/punch/source/108745e2c8bb476a9855f716fd9adadd.gif` / SHA-256 `d5342557d83f7f61d8b05826655954abc0f22d178b59aeb5cde2a367331f1fe4`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/punch/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F000.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F001.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F002.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F003.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F004.png`
- icon: `reference_resource_design/punch/source/c06426910ef343ee99dcc0d6ccf61e07.png` / SHA-256 `45151dd3badb831d2236389d9e10618f2ebafc6d03ba0aaec9e44acb82e3cddf`

### 헥스 : 샌드스톰 / `skill/15414.img/skill/154141500`
- 관찰한 표현: 모래의 겹친 띠와 농도 차, 큰 흐름 뒤에 남는 가벼운 먼지
- 가져오지 않을 요소: 모든 모래 스킬을 원통형 회오리로 바꾸지 않는다
- keydown: `reference_resource_design/sand/source/28c33a05afb04953a8b3527b9a374382.gif` / SHA-256 `3484d74f501ee8a131836b0220cd82034393fe4d3300a3cbdeace21e6ca68bcb`
  전체 연속 PNG 14장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F000.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F003.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F007.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F010.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F013.png`
- keydownend: `reference_resource_design/sand/source/b97b5eda839440c3921f38656ef77649.gif` / SHA-256 `e403595b5a984595cbe0b31bdd7c654ba8d86ddf295534863f52243b27b92cf6`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F000.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F001.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F002.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F003.png`
- icon: `reference_resource_design/sand/source/7e6eda520af54b87bc552712f3804ea6.png` / SHA-256 `b9d5c6b9e4f3da2aee959eb87c464998986d8dc03f78e1b6432b098902cd5de4`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/003_m_red_snail_s_mon_red_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/003_m_red_snail_빨간_달팽이/003_m_red_snail_s_mon_red_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_wild_boar_와일드보어/MONSTER_IMAGE.png` / SHA-256 `f620027b677baa72da586d2a6b6447fdb2ad2ea055a9f2e062bba4e0588ff7da`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_wild_boar_OFFICIAL_VFX_BOARD.png` / SHA-256 `7208ec5d084d3dffa318da6036eac432657c96c712ed8a659cecf2ff243b48c1`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_wild_boar_AREA00_FINISH_BOARD.png` / SHA-256 `9896de7d37151ac9c1b00bf3bc0b372826374ad67564f81e341e53e54b61c544`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_wild_boar_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
