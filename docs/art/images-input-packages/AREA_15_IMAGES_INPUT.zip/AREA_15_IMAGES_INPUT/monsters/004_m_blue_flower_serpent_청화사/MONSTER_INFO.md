# Monster Reference — 청화사

- 작업 순번: 004
- level: 148
- Area: `area_15` / 무릉도원
- monster_id: `m_blue_flower_serpent`
- model_id: `blueflowerserpent`
- image RUID: `75dc3d98cc1243298dca02fd708bcb34`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_flower_serpent`
- skill name/type: 청화 비늘 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
