# Source provenance — 수련용 나무인형 / 목인 회전타

- rebuild run: `20260913_153134`
- base package: `AREA_15_IMAGES_INPUT.zip`
- base package SHA-256: `8a72447e05aaff2031299d3cc409d1a3c9326ef837ee07032dd43673ea037486`
- preserved manifest monster image RUID: `91ff481190624f0fa850c86c8d3bdbde`
- preserved monster image status: `확보`
- preserved ids: `m_wooden_dummy` / `s_mon_wooden_dummy`
- preserved WHAT: `목인 회전타` / `액티브` / `STR 계수 4.45로 반경 4.8 범위 최대 3대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.22초; 지속 0.7/0.55초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
