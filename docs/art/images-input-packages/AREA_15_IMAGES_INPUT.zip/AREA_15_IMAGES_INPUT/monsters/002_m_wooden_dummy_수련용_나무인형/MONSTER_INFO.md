# Monster Reference — 수련용 나무인형

- 작업 순번: 002
- level: 143
- Area: `area_15` / 무릉도원
- monster_id: `m_wooden_dummy`
- model_id: `woodendummy`
- image RUID: `91ff481190624f0fa850c86c8d3bdbde`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wooden_dummy`
- skill name/type: 목인 회전타 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
