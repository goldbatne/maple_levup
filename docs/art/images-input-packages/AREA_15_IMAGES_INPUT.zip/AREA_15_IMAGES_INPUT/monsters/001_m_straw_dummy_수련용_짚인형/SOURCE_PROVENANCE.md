# Source provenance — 수련용 짚인형 / 짚단 균형감각

- rebuild run: `20260913_153134`
- base package: `AREA_15_IMAGES_INPUT.zip`
- base package SHA-256: `8a72447e05aaff2031299d3cc409d1a3c9326ef837ee07032dd43673ea037486`
- preserved manifest monster image RUID: `4b1d55e35ae9462b944297691025429a`
- preserved monster image status: `확보`
- preserved ids: `m_straw_dummy` / `s_mon_straw_dummy`
- preserved WHAT: `짚단 균형감각` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
