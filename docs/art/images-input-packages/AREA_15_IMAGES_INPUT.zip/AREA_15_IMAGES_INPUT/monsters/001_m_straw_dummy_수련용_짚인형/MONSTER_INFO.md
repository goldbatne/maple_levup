# Monster Reference — 수련용 짚인형

- 작업 순번: 001
- level: 141
- Area: `area_15` / 무릉도원
- monster_id: `m_straw_dummy`
- model_id: `strawdummy`
- image RUID: `4b1d55e35ae9462b944297691025429a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_straw_dummy`
- skill name/type: 짚단 균형감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
