# 원공 — 천도 투척: 실제 디자인 참조

monster_id: `m_peach_monkey` / skill_id: `s_mon_peach_monkey` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 천도 복숭아가 잎사귀 꼬리를 달고 포물선으로 날아가는 탄. ‘원공 / 천도 투척’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 천도 분홍 #F09691; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 복숭아잎 녹색 #6FA45A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘복숭아’, 보조 효과 1개는 ‘잎사귀 포물선’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/003_m_peach_monkey_원공/MONSTER_IMAGE.png`

RUID: `15e255981ed54cf092a136b1526aa055` / SHA-256: `672ac19e33efb0adef8638e7c9520e033a7c6e30f4c10078d185914229bbaca3`

## 이 스킬에 적용할 구체적인 디자인
복숭아와 잎 꼬리가 포물선을 그린다. 과육·껍질의 명암을 유지하고 보라 에너지 구체나 꽃 문양으로 바꾸지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 버블 스타 / 버블 스타 강화 / `skill/40000.img/skill/400004429`
- 관찰한 표현: 밝은 내부 코어와 반투명 외피, 진행 방향 쪽의 압축과 후방 잔상
- 가져오지 않을 요소: 보라 구체와 후프를 모든 투사체의 모양으로 사용하지 않는다
- ball: `reference_resource_design/bubble/source/e4912b933bbc48a483451dae347bf6f3.gif` / SHA-256 `ef279982003fd473729c6516a8ea1a89fdddbdbefd90a9230b4fd3d3980497f1`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F000.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F001.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F002.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F003.png`
- effect: `reference_resource_design/bubble/source/bcfebd118b0f4cb2b86971fe681b1081.gif` / SHA-256 `f197c7c9d60663bf5521183f5cb984b49c85251dd44f29627ce7462b7c7bbf5d`
  전체 연속 PNG 13장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F000.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F003.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F006.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F009.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F012.png`
- icon: `reference_resource_design/bubble/source/0b85676a40c74bc288d997270378bb12.png` / SHA-256 `6a6a6818cce417faa65da3e26a5732a11964f9550af30ebac3a115be60758656`

### 정기 뿌리기 / 정기 뿌리기 강화 / `skill/16212.img/skill/162121021`
- 관찰한 표현: 작은 입자군이 코어 주위에서 퍼져 농도와 광량을 함께 잃는 전개
- 가져오지 않을 요소: 꽃별 문양과 연두 팔레트를 강제하지 않는다
- effect: `reference_resource_design/nature/source/15fb0e791d5843108b230b3216ff0764.gif` / SHA-256 `1bf89cbd617c689cb874dd98241eb5d7734293758efd7ddadd3680a5255000f2`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F000.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F002.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F005.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F007.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F009.png`
- hit/0: `reference_resource_design/nature/source/04c96fc0062c418682c8075beb003a0c.gif` / SHA-256 `2d769417bd428c55eedb33fd8f565fadcd185bbc2a11b0eb32a3e93d211ef4ac`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F000.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F002.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F005.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F007.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F009.png`
- icon: `reference_resource_design/nature/source/c9fac8505f8c4efc9b9864dc540d038f.png` / SHA-256 `ce30ebdc7957924300b5798b16992e9816a96d8769b13bac9b439a056a68d0ae`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/003_m_peach_monkey_원공/MONSTER_IMAGE.png` / SHA-256 `672ac19e33efb0adef8638e7c9520e033a7c6e30f4c10078d185914229bbaca3`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_peach_monkey_OFFICIAL_VFX_BOARD.png` / SHA-256 `6248b98d1d1d6274b93cff8cc048d60db020d6906f35831d72641b9aa4a7c2aa`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_peach_monkey_AREA00_FINISH_BOARD.png` / SHA-256 `143d0b94d063f1734a15b0e1ffbd2f87fe4cda86163614999d800f3095814671`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_peach_monkey_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
