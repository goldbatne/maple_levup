# Monster Reference — 원공

- 작업 순번: 003
- level: 145
- Area: `area_15` / 무릉도원
- monster_id: `m_peach_monkey`
- model_id: `peachmonkey`
- image RUID: `15e255981ed54cf092a136b1526aa055`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_peach_monkey`
- skill name/type: 천도 투척 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
