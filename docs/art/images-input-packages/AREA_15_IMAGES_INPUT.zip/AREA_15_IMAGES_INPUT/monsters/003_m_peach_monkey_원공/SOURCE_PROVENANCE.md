# Source provenance — 원공 / 천도 투척

- rebuild run: `20260913_153134`
- base package: `AREA_15_IMAGES_INPUT.zip`
- base package SHA-256: `8a72447e05aaff2031299d3cc409d1a3c9326ef837ee07032dd43673ea037486`
- preserved manifest monster image RUID: `15e255981ed54cf092a136b1526aa055`
- preserved monster image status: `확보`
- preserved ids: `m_peach_monkey` / `s_mon_peach_monkey`
- preserved WHAT: `천도 투척` / `액티브` / `DEX 계수 4.6로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.65초; 투사체 9ca14ee512b1489cbb54b2b9833388cd가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
