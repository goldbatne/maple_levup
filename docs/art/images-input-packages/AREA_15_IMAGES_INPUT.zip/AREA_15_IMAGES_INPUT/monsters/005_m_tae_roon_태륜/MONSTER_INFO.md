# Monster Reference — 태륜

- 작업 순번: 005
- level: 150
- Area: `area_15` / 무릉도원
- monster_id: `m_tae_roon`
- model_id: `taeroon`
- image RUID: `0e1e782401624d7693959777c0b16ebe`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_tae_roon`
- skill name/type: 태륜의 쌍권풍 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
