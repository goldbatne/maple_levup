# Source provenance — 태륜 / 태륜의 쌍권풍

- rebuild run: `20260913_153134`
- base package: `AREA_15_IMAGES_INPUT.zip`
- base package SHA-256: `8a72447e05aaff2031299d3cc409d1a3c9326ef837ee07032dd43673ea037486`
- preserved manifest monster image RUID: `0e1e782401624d7693959777c0b16ebe`
- preserved monster image status: `확보`
- preserved ids: `m_tae_roon` / `s_mon_tae_roon`
- preserved WHAT: `태륜의 쌍권풍` / `액티브` / `STR 계수 4.9로 반경 6.6 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.75/0.85초; 투사체 5328a3875a32437784c949579f259a00가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
