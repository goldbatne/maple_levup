# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t67/mulung`
- 합성 대상: 00_peach_earth.png, 01_dojo_stone.png, 02_bamboo_walk.png, 03_cloud_cliff.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
