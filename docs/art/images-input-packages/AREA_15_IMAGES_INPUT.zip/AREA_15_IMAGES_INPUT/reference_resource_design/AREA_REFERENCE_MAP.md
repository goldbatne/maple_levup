# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 수련용 짚인형 / 짚단 균형감각: [monsters/001_m_straw_dummy_수련용_짚인형/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_straw_dummy_수련용_짚인형/DESIGN_REFERENCE_BRIEF.md) — nature, metal
- 수련용 나무인형 / 목인 회전타: [monsters/002_m_wooden_dummy_수련용_나무인형/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_wooden_dummy_수련용_나무인형/DESIGN_REFERENCE_BRIEF.md) — punch, needle
- 원공 / 천도 투척: [monsters/003_m_peach_monkey_원공/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_peach_monkey_원공/DESIGN_REFERENCE_BRIEF.md) — bubble, nature
- 청화사 / 청화 비늘: [monsters/004_m_blue_flower_serpent_청화사/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_blue_flower_serpent_청화사/DESIGN_REFERENCE_BRIEF.md) — metal, garden
- 태륜 / 태륜의 쌍권풍: [monsters/005_m_tae_roon_태륜/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_tae_roon_태륜/DESIGN_REFERENCE_BRIEF.md) — punch, gale