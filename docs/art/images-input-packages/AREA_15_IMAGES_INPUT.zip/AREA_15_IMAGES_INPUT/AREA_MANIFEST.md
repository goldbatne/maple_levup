# area_15 무릉도원 Manifest

- 처리 순서: 15
- 레벨 범위: Lv141~150
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 141 | area_15 | 무릉도원 | m_straw_dummy | 수련용 짚인형 | 4b1d55e35ae9462b944297691025429a | 확보 | s_mon_straw_dummy | 짚단 균형감각 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_straw_dummy_수련용_짚인형 |
| 2 | 143 | area_15 | 무릉도원 | m_wooden_dummy | 수련용 나무인형 | 91ff481190624f0fa850c86c8d3bdbde | 확보 | s_mon_wooden_dummy | 목인 회전타 | 액티브 | STR 계수 4.45로 반경 4.8 범위 최대 3대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.22초; 지속 0.7/0.55초 | N | monsters/002_m_wooden_dummy_수련용_나무인형 |
| 3 | 145 | area_15 | 무릉도원 | m_peach_monkey | 원공 | 15e255981ed54cf092a136b1526aa055 | 확보 | s_mon_peach_monkey | 천도 투척 | 액티브 | DEX 계수 4.6로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.65초; 투사체 9ca14ee512b1489cbb54b2b9833388cd가 목표 방향으로 이동 | N | monsters/003_m_peach_monkey_원공 |
| 4 | 148 | area_15 | 무릉도원 | m_blue_flower_serpent | 청화사 | 75dc3d98cc1243298dca02fd708bcb34 | 확보 | s_mon_blue_flower_serpent | 청화 비늘 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_blue_flower_serpent_청화사 |
| 5 | 150 | area_15 | 무릉도원 | m_tae_roon | 태륜 | 0e1e782401624d7693959777c0b16ebe | 확보 | s_mon_tae_roon | 태륜의 쌍권풍 | 액티브 | STR 계수 4.9로 반경 6.6 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.75/0.85초; 투사체 5328a3875a32437784c949579f259a00가 목표 방향으로 이동 | Y | monsters/005_m_tae_roon_태륜 |
