# area_09 엘나스 산맥 Manifest

- 처리 순서: 9
- 레벨 범위: Lv81~90
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 81 | area_09 | 엘나스 산맥 | m_jr_yeti | 주니어 예티 | 1975dd704eec461ab49bdeb0c11c54d9 | 확보 | s_mon_jr_yeti | 설인의 체온 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_jr_yeti_주니어_예티 |
| 2 | 83 | area_09 | 엘나스 산맥 | m_dark_jr_yeti | 다크 주니어 예티 | ce56cf9613174f80976dab5b61f7b604 | 확보 | s_mon_dark_jr_yeti | 검은 설원의 은폐 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_dark_jr_yeti_다크_주니어_예티 |
| 3 | 85 | area_09 | 엘나스 산맥 | m_hector | 헥터 | 7dcc64a4725b4777b8f86a5404b4d4cc | 확보 | s_mon_hector | 설원 늑대 발톱 | 액티브 | ATK 계수 2.75로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8; 6.5 거리 돌진 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.58/0.62초; 시전자가 목표 방향으로 돌진 | N | monsters/003_m_hector_헥터 |
| 4 | 88 | area_09 | 엘나스 산맥 | m_white_fang | 화이트팽 | aaa3b506804d4418b025da47dbb65b3f | 확보 | s_mon_white_fang | 화이트팽의 빙설 송곳니 | 액티브 | ATK 계수 2.9로 반경 4.8 범위 최대 3대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.15초; 지속 0.65/0.72초 | N | monsters/004_m_white_fang_화이트팽 |
| 5 | 90 | area_09 | 엘나스 산맥 | m_snow_witch | 설산의 마녀 | 4b50438f59154f41aba918b2d28bb8d2 | 확보 | s_mon_snow_witch | 추방자의 눈보라 | 액티브 | INT 계수 3.15로 반경 6 범위 대상 제한 없음 피해; 9초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.16/0.3초; 지속 0.72/0.8/0.92초 | Y | monsters/005_m_snow_witch_설산의_마녀 |
