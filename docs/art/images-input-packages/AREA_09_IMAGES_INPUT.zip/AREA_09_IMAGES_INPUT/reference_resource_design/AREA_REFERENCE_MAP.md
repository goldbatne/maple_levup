# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 주니어 예티 / 설인의 체온: [monsters/001_m_jr_yeti_주니어_예티/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_jr_yeti_주니어_예티/DESIGN_REFERENCE_BRIEF.md) — nature, ice
- 다크 주니어 예티 / 검은 설원의 은폐: [monsters/002_m_dark_jr_yeti_다크_주니어_예티/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_dark_jr_yeti_다크_주니어_예티/DESIGN_REFERENCE_BRIEF.md) — sand, dark_magic
- 헥터 / 설원 늑대 발톱: [monsters/003_m_hector_헥터/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_hector_헥터/DESIGN_REFERENCE_BRIEF.md) — needle, ice
- 화이트팽 / 화이트팽의 빙설 송곳니: [monsters/004_m_white_fang_화이트팽/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_white_fang_화이트팽/DESIGN_REFERENCE_BRIEF.md) — ice, punch
- 설산의 마녀 / 추방자의 눈보라: [monsters/005_m_snow_witch_설산의_마녀/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_snow_witch_설산의_마녀/DESIGN_REFERENCE_BRIEF.md) — gale, ice