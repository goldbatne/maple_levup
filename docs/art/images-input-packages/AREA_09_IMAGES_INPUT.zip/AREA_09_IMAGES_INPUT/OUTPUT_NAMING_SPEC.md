# Output Naming Spec — AREA 09

출력 루트: `AREA_09_IMAGES_OUTPUT/`

- VFX: `NNN_[monster_id]_[skill_id]_F00.png`, `F01.png` ...
- ICON: `NNN_[monster_id]_[skill_id]_ICON.png`
- Preview: `NNN_[monster_id]_[skill_id]_CONTACT_PREVIEW.png` 및 `labeled_preview.png`
- NNN은 AREA_MANIFEST의 작업 순번 3자리다.
- monster_id와 skill_id는 축약·번역하지 않는다.
- `F00`부터 마지막 프레임까지 번호를 건너뛰지 않는다.

```text
AREA_09_IMAGES_OUTPUT/
├─ AREA_OVERVIEW_PREVIEW.png
├─ AREA_OVERVIEW_LABELED_PREVIEW.png
├─ OUTPUT_MANIFEST.md
├─ OUTPUT_MANIFEST.csv
├─ VALIDATION_REPORT.md
└─ monsters/
   └─ NNN_[monster_id]_[name]/
      ├─ VFX/*.png
      ├─ ICON/*_ICON.png
      ├─ PREVIEW/*_CONTACT_PREVIEW.png
      ├─ PREVIEW/labeled_preview.png
      └─ RESULT_INFO.md
```
