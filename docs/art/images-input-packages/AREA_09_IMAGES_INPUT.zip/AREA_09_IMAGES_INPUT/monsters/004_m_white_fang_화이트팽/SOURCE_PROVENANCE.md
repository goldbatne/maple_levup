# Source provenance — 화이트팽 / 화이트팽의 빙설 송곳니

- rebuild run: `20260913_153134`
- base package: `AREA_09_IMAGES_INPUT.zip`
- base package SHA-256: `510ba82652c58e3f60704c02891607dd41d460d46f87e8866d6a402844fb9ae1`
- preserved manifest monster image RUID: `aaa3b506804d4418b025da47dbb65b3f`
- preserved monster image status: `확보`
- preserved ids: `m_white_fang` / `s_mon_white_fang`
- preserved WHAT: `화이트팽의 빙설 송곳니` / `액티브` / `ATK 계수 2.9로 반경 4.8 범위 최대 3대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.15초; 지속 0.65/0.72초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
