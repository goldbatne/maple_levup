# Monster Reference — 화이트팽

- 작업 순번: 004
- level: 88
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_white_fang`
- model_id: `whitefang`
- image RUID: `aaa3b506804d4418b025da47dbb65b3f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_white_fang`
- skill name/type: 화이트팽의 빙설 송곳니 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
