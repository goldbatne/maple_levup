# 화이트팽 — 화이트팽의 빙설 송곳니: 실제 디자인 참조

monster_id: `m_white_fang` / skill_id: `s_mon_white_fang` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 송곳니 두 개가 얼음 능선처럼 교차하는 빙설 타격. ‘화이트팽 / 화이트팽의 빙설 송곳니’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 빙설 백청 #C9F2FF; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 심빙 청색 #4E9CC8; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘교차 송곳니’, 보조 효과 1개는 ‘얼음 조각’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_white_fang_화이트팽/MONSTER_IMAGE.png`

RUID: `aaa3b506804d4418b025da47dbb65b3f` / SHA-256: `71f7a01b9f3f910afceabad1784f8b8b9f2f4a78f0f9e49dc3ec4428ce3e57c4`

## 이 스킬에 적용할 구체적인 디자인
두 송곳니가 교차한 얼음 능선의 순간 충격을 만든다. 두 방향을 읽히게 하고 단순 원형 타격으로 바꾸지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 블리자드 VI / `skill/224.img/skill/2241003`
- 관찰한 표현: 얼음의 어두운 면·중간 청색 면·흰 모서리와 각진 파쇄
- 가져오지 않을 요소: 빙주 낙하를 목표의 다른 동작으로 대체하지 않는다
- effect: `reference_resource_design/ice/source/85919f65afd340aca9f601c2d090f67c.gif` / SHA-256 `e701c48214add5ed438f681a61ed64471cd5733fd8cc7ff5ac6570eb2c2e3824`
  전체 연속 PNG 31장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F000.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F007.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F015.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F023.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F030.png`
- hit/0: `reference_resource_design/ice/source/8edaaf07b78742adad6e4036a21bec76.gif` / SHA-256 `57ccfa365fc06e70d66f8202b3c4c407553d20b128eec8290769159631296030`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F000.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F002.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F004.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F006.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F007.png`
- icon: `reference_resource_design/ice/source/dd93587d98c44bf1a2698a14f273c662.png` / SHA-256 `1993c7929877b25b12609ce410048ed58267baca6df4ef4b095496238024d0f6`

### 스크류 펀치 / 스크류 펀치 강화 / `skill/40000.img/skill/400004139`
- 관찰한 표현: 작은 압축 코어가 전진해 충격면으로 퍼지고 조각으로 풀리는 운동
- 가져오지 않을 요소: 공식 주먹·원형 추진체를 목표의 발굽·리본·엄니로 대체 복사하지 않는다
- effect: `reference_resource_design/punch/source/4f97bf6aecbc4687aa83e60e763aaf89.gif` / SHA-256 `d0334c271d254be51ba450d7cde7e1fc1518338a90a07345ff95ccf4c12df2bb`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/punch/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F000.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F002.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F005.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F007.png`
  - `reference_resource_design/punch/frames/4f97bf6aecbc4687aa83e60e763aaf89_F009.png`
- hit: `reference_resource_design/punch/source/108745e2c8bb476a9855f716fd9adadd.gif` / SHA-256 `d5342557d83f7f61d8b05826655954abc0f22d178b59aeb5cde2a367331f1fe4`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/punch/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F000.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F001.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F002.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F003.png`
  - `reference_resource_design/punch/frames/108745e2c8bb476a9855f716fd9adadd_F004.png`
- icon: `reference_resource_design/punch/source/c06426910ef343ee99dcc0d6ccf61e07.png` / SHA-256 `45151dd3badb831d2236389d9e10618f2ebafc6d03ba0aaec9e44acb82e3cddf`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_white_fang_화이트팽/MONSTER_IMAGE.png` / SHA-256 `71f7a01b9f3f910afceabad1784f8b8b9f2f4a78f0f9e49dc3ec4428ce3e57c4`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_white_fang_OFFICIAL_VFX_BOARD.png` / SHA-256 `ca59b7b65dcaf4d9ba3cd98ce74538168ec043e1380cb82f73d28a3a8413a914`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_white_fang_AREA00_FINISH_BOARD.png` / SHA-256 `f5199300311d2aa35a68811bc3e71617aa2f8f6da76146db33cf1dca00ed07b5`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_white_fang_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
