# Source provenance — 헥터 / 설원 늑대 발톱

- rebuild run: `20260913_153134`
- base package: `AREA_09_IMAGES_INPUT.zip`
- base package SHA-256: `510ba82652c58e3f60704c02891607dd41d460d46f87e8866d6a402844fb9ae1`
- preserved manifest monster image RUID: `7dcc64a4725b4777b8f86a5404b4d4cc`
- preserved monster image status: `확보`
- preserved ids: `m_hector` / `s_mon_hector`
- preserved WHAT: `설원 늑대 발톱` / `액티브` / `ATK 계수 2.75로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8; 6.5 거리 돌진` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.58/0.62초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
