# 설산의 마녀 — 추방자의 눈보라: 실제 디자인 참조

monster_id: `m_snow_witch` / skill_id: `s_mon_snow_witch` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 마녀의 굽은 설풍 고리가 눈결정을 끌어당기는 폭풍. ‘설산의 마녀 / 추방자의 눈보라’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 눈보라 백청 #E2F8FF; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 마녀 보라 #77638D; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘굽은 설풍 고리’, 보조 효과 1개는 ‘눈결정’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/005_m_snow_witch_설산의_마녀/MONSTER_IMAGE.png`

RUID: `4b50438f59154f41aba918b2d28bb8d2` / SHA-256: `8488c15a9728d346caf34ffeec8a4c1d2971ae8a90d865c36f9fb206fe3dfe4f`

## 이 스킬에 적용할 구체적인 디자인
갈고리처럼 휘는 바람이 얼음 결정을 끌어들인다. 회오리 빈 공간과 결정의 단단한 면을 분리하고 마녀 본체를 넣지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 하울링 게일 / 하울링 게일 강화 / `skill/40003.img/skill/400031068`
- 관찰한 표현: 굵기 다른 회전 바람띠와 띠 사이 빈 공간, 분리된 작은 입자
- 가져오지 않을 요소: 수직 회오리와 연두색을 그대로 복제하지 않는다
- ball: `reference_resource_design/gale/source/a1ccfefaa1f545ca99d0a71af81f7532.gif` / SHA-256 `ce1828497f3b79ed77afc34e4781c62e470ce3c5f071fb5eab450a1ae18cbd35`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/gale/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F000.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F001.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F003.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F004.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F005.png`
- icon: `reference_resource_design/gale/source/bee2fed28830476da192fd3f67bf4a4a.png` / SHA-256 `6be7e7d34a66cb13061664fc2f704909e523c9aa797b7124459eb2230ba5448b`

### 블리자드 VI / `skill/224.img/skill/2241003`
- 관찰한 표현: 얼음의 어두운 면·중간 청색 면·흰 모서리와 각진 파쇄
- 가져오지 않을 요소: 빙주 낙하를 목표의 다른 동작으로 대체하지 않는다
- effect: `reference_resource_design/ice/source/85919f65afd340aca9f601c2d090f67c.gif` / SHA-256 `e701c48214add5ed438f681a61ed64471cd5733fd8cc7ff5ac6570eb2c2e3824`
  전체 연속 PNG 31장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F000.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F007.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F015.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F023.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F030.png`
- hit/0: `reference_resource_design/ice/source/8edaaf07b78742adad6e4036a21bec76.gif` / SHA-256 `57ccfa365fc06e70d66f8202b3c4c407553d20b128eec8290769159631296030`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F000.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F002.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F004.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F006.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F007.png`
- icon: `reference_resource_design/ice/source/dd93587d98c44bf1a2698a14f273c662.png` / SHA-256 `1993c7929877b25b12609ce410048ed58267baca6df4ef4b095496238024d0f6`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`
- `global_skill_style_library/area00_finish_baseline/icons/004_m_mano_s_mon_mano_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F07.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F08.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F09.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F10.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/005_m_snow_witch_설산의_마녀/MONSTER_IMAGE.png` / SHA-256 `8488c15a9728d346caf34ffeec8a4c1d2971ae8a90d865c36f9fb206fe3dfe4f`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_snow_witch_OFFICIAL_VFX_BOARD.png` / SHA-256 `8d5873769243de4f24c2aea8a6f5e16e2e6563c8d5fad4aca0b38116a29ef8d5`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_snow_witch_AREA00_FINISH_BOARD.png` / SHA-256 `b2ab57d9ff88883e0ccab6709c8aadfe0a365b0c452828391447297c2904d485`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_snow_witch_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
