# Monster Reference — 설산의 마녀

- 작업 순번: 005
- level: 90
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_snow_witch`
- model_id: `snowwitch`
- image RUID: `4b50438f59154f41aba918b2d28bb8d2`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_snow_witch`
- skill name/type: 추방자의 눈보라 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
