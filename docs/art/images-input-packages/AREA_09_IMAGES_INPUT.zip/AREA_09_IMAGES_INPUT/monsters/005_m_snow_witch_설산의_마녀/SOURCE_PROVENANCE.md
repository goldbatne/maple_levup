# Source provenance — 설산의 마녀 / 추방자의 눈보라

- rebuild run: `20260913_153134`
- base package: `AREA_09_IMAGES_INPUT.zip`
- base package SHA-256: `510ba82652c58e3f60704c02891607dd41d460d46f87e8866d6a402844fb9ae1`
- preserved manifest monster image RUID: `4b50438f59154f41aba918b2d28bb8d2`
- preserved monster image status: `확보`
- preserved ids: `m_snow_witch` / `s_mon_snow_witch`
- preserved WHAT: `추방자의 눈보라` / `액티브` / `INT 계수 3.15로 반경 6 범위 대상 제한 없음 피해; 9초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.16/0.3초; 지속 0.72/0.8/0.92초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
