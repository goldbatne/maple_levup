# Monster Reference — 주니어 예티

- 작업 순번: 001
- level: 81
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_jr_yeti`
- model_id: `jryeti`
- image RUID: `1975dd704eec461ab49bdeb0c11c54d9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_yeti`
- skill name/type: 설인의 체온 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
