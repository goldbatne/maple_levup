# Source provenance — 주니어 예티 / 설인의 체온

- rebuild run: `20260913_153134`
- base package: `AREA_09_IMAGES_INPUT.zip`
- base package SHA-256: `510ba82652c58e3f60704c02891607dd41d460d46f87e8866d6a402844fb9ae1`
- preserved manifest monster image RUID: `1975dd704eec461ab49bdeb0c11c54d9`
- preserved monster image status: `확보`
- preserved ids: `m_jr_yeti` / `s_mon_jr_yeti`
- preserved WHAT: `설인의 체온` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
