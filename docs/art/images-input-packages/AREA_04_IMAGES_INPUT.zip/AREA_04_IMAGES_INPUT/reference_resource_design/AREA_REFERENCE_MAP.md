# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 옥토퍼스 / 먹물 폭발: [monsters/001_m_octopus_옥토퍼스/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_octopus_옥토퍼스/DESIGN_REFERENCE_BRIEF.md) — mist, water
- 스티지 / 밤의 감각: [monsters/002_m_stirge_스티지/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_stirge_스티지/DESIGN_REFERENCE_BRIEF.md) — sound, dark_magic
- 주니어 레이스 / 망령 충격: [monsters/003_m_jr_wraith_주니어_레이스/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_jr_wraith_주니어_레이스/DESIGN_REFERENCE_BRIEF.md) — water_shield, curse
- 레이스 / 원혼의 기운: [monsters/004_m_wraith_레이스/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_wraith_레이스/DESIGN_REFERENCE_BRIEF.md) — dark_magic, water_shield
- 셰이드 / 심연의 장막: [monsters/005_m_shade_셰이드/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_shade_셰이드/DESIGN_REFERENCE_BRIEF.md) — dark_barrier, dark_magic