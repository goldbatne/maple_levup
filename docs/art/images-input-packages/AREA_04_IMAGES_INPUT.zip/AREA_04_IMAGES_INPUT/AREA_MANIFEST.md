# area_04 커닝시티 Manifest

- 처리 순서: 5
- 레벨 범위: Lv31~40
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 31 | area_04 | 커닝시티 | m_octopus | 옥토퍼스 | d8f014043ce8418f96700c2b6c9ebf6c | 확보 | s_mon_octopus | 먹물 폭발 | 액티브 | INT 계수 1.65로 반경 3.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.6/0.75초 | N | monsters/001_m_octopus_옥토퍼스 |
| 2 | 33 | area_04 | 커닝시티 | m_stirge | 스티지 | 25152ef859744489b7e34a993b3a3c6d | 확보 | s_mon_stirge | 밤의 감각 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_stirge_스티지 |
| 3 | 35 | area_04 | 커닝시티 | m_jr_wraith | 주니어 레이스 | ca9fd4116b62417caebde864c675e026 | 확보 | s_mon_jr_wraith | 망령 충격 | 액티브 | INT 계수 1.8로 반경 4 범위 최대 2대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.62/0.75초 | N | monsters/003_m_jr_wraith_주니어_레이스 |
| 4 | 38 | area_04 | 커닝시티 | m_wraith | 레이스 | 15e7b98cec434b269c09e97f550921c3 | 확보 | s_mon_wraith | 원혼의 기운 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_wraith_레이스 |
| 5 | 40 | area_04 | 커닝시티 | m_shade | 셰이드 | 4f763744e0ac49469d2305e3c73254b7 | 확보 | s_mon_shade | 심연의 장막 | 액티브 | INT 계수 2.1로 반경 4.8 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.8초 | Y | monsters/005_m_shade_셰이드 |
