# Source provenance — 옥토퍼스 / 먹물 폭발

- rebuild run: `20260913_153134`
- base package: `AREA_04_IMAGES_INPUT.zip`
- base package SHA-256: `3e3120239c42c5e5ba1044f3cf785889cec195d5f2e61a83c9e831d42a8e1597`
- preserved manifest monster image RUID: `d8f014043ce8418f96700c2b6c9ebf6c`
- preserved monster image status: `확보`
- preserved ids: `m_octopus` / `s_mon_octopus`
- preserved WHAT: `먹물 폭발` / `액티브` / `INT 계수 1.65로 반경 3.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.1초; 지속 0.6/0.75초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
