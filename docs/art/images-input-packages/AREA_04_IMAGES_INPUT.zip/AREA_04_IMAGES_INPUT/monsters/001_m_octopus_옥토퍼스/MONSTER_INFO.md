# Monster Reference — 옥토퍼스

- 작업 순번: 001
- level: 31
- Area: `area_04` / 커닝시티
- monster_id: `m_octopus`
- model_id: `octopus`
- image RUID: `d8f014043ce8418f96700c2b6c9ebf6c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_octopus`
- skill name/type: 먹물 폭발 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
