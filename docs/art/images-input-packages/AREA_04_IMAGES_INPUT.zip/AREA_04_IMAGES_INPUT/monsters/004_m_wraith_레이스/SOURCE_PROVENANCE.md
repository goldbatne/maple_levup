# Source provenance — 레이스 / 원혼의 기운

- rebuild run: `20260913_153134`
- base package: `AREA_04_IMAGES_INPUT.zip`
- base package SHA-256: `3e3120239c42c5e5ba1044f3cf785889cec195d5f2e61a83c9e831d42a8e1597`
- preserved manifest monster image RUID: `15e7b98cec434b269c09e97f550921c3`
- preserved monster image status: `확보`
- preserved ids: `m_wraith` / `s_mon_wraith`
- preserved WHAT: `원혼의 기운` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
