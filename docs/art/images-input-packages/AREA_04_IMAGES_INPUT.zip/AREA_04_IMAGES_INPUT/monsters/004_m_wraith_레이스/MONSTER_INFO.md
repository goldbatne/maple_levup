# Monster Reference — 레이스

- 작업 순번: 004
- level: 38
- Area: `area_04` / 커닝시티
- monster_id: `m_wraith`
- model_id: `wraith`
- image RUID: `15e7b98cec434b269c09e97f550921c3`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wraith`
- skill name/type: 원혼의 기운 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
