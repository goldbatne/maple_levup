# Monster Reference — 주니어 레이스

- 작업 순번: 003
- level: 35
- Area: `area_04` / 커닝시티
- monster_id: `m_jr_wraith`
- model_id: `jrwraith`
- image RUID: `ca9fd4116b62417caebde864c675e026`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_wraith`
- skill name/type: 망령 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
