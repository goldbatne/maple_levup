# Source provenance — 주니어 레이스 / 망령 충격

- rebuild run: `20260913_153134`
- base package: `AREA_04_IMAGES_INPUT.zip`
- base package SHA-256: `3e3120239c42c5e5ba1044f3cf785889cec195d5f2e61a83c9e831d42a8e1597`
- preserved manifest monster image RUID: `ca9fd4116b62417caebde864c675e026`
- preserved monster image status: `확보`
- preserved ids: `m_jr_wraith` / `s_mon_jr_wraith`
- preserved WHAT: `망령 충격` / `액티브` / `INT 계수 1.8로 반경 4 범위 최대 2대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.62/0.75초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
