# Monster Reference — 셰이드

- 작업 순번: 005
- level: 40
- Area: `area_04` / 커닝시티
- monster_id: `m_shade`
- model_id: `shade`
- image RUID: `4f763744e0ac49469d2305e3c73254b7`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_shade`
- skill name/type: 심연의 장막 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
