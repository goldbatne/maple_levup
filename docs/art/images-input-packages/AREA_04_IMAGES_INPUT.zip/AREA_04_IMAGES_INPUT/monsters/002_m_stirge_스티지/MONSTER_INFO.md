# Monster Reference — 스티지

- 작업 순번: 002
- level: 33
- Area: `area_04` / 커닝시티
- monster_id: `m_stirge`
- model_id: `stirge`
- image RUID: `25152ef859744489b7e34a993b3a3c6d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_stirge`
- skill name/type: 밤의 감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
