# 스티지 — 밤의 감각: 실제 디자인 참조

monster_id: `m_stirge` / skill_id: `s_mon_stirge` / 타입: 패시브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 박쥐 초음파 같은 얇은 야간 파문과 붉은 감지점. ‘스티지 / 밤의 감각’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 야간 남보라 #3C355F; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 감지 적색 #D85B66; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘초음파 파문’, 보조 효과 1개는 ‘붉은 감지점’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/002_m_stirge_스티지/MONSTER_IMAGE.png`

RUID: `25152ef859744489b7e34a993b3a3c6d` / SHA-256: `dea397b69173b1e5d9369f7fe7869789c63a36154e37ec1cd32914087312c14b`

## 이 스킬에 적용할 구체적인 디자인
박쥐의 몸 대신 얇은 야간 음파와 작은 붉은 감지점을 ICON에 담는다. 음표·큰 회오리·검 모양은 제외한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 소울 레조넌스 / 소울 레조넌스 강화 / `skill/40000.img/skill/400004438`
- 관찰한 표현: 얇은 진동띠가 겹치고 마지막 잔광이 단계적으로 빠지는 흐름
- 가져오지 않을 요소: 음표와 주변 돌 조각을 목표에 추가하지 않는다
- end: `reference_resource_design/sound/source/3516dd54a83647ce9669e5b55fdf3c0c.gif` / SHA-256 `3aab8da968c7f3cb5118b68c384812c7c7905ab65427e355d0bff9e3b8c6efc1`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/sound/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F000.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F001.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F002.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F003.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F004.png`
- keydown: `reference_resource_design/sound/source/39e950d9e0384f4984a20e06409fa0de.gif` / SHA-256 `7bcf7eec39f38a97ca32ccf22bdd9fce025c867bb89176b097e306ef2b61c9ac`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/sound/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F000.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F001.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F003.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F004.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F005.png`
- icon: `reference_resource_design/sound/source/5597d70b59a74de5947c9d9591cd3f23.png` / SHA-256 `266f4be28b1792c7132422cb6edd3a22f982e8aea07a03129ffd348c837a591e`

### 엔드리스 다크니스 / `skill/2714.img/skill/27140002`
- 관찰한 표현: 길게 당겨진 어두운 물질과 얇은 보랏빛 코어가 분리되어 소실
- 가져오지 않을 요소: 공식 검이나 날 형상을 그대로 복제하지 않는다
- effect: `reference_resource_design/dark_magic/source/194e46bbd5214672b1a6610e48fec7e0.gif` / SHA-256 `d1776e21b2b35e2344440ca42b6c77dfb94cd4cad93d56ce96086728e634354a`
  전체 연속 PNG 12장과 GIF 타이밍은 `reference_resource_design/dark_magic/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F000.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F003.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F006.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F009.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F011.png`
- icon: `reference_resource_design/dark_magic/source/0a58c21f9b7741df95a535ceea23f12e.png` / SHA-256 `9863c1da8d1b965f853d034e39b22d195d1b124fd50f53e84fa65e2ed5905192`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/002_m_stirge_스티지/MONSTER_IMAGE.png` / SHA-256 `dea397b69173b1e5d9369f7fe7869789c63a36154e37ec1cd32914087312c14b`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_stirge_OFFICIAL_VFX_BOARD.png` / SHA-256 `aa8db2d0899af5856fe7d3f14b450b409617f8420c89768f121c7f23ae27c838`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_stirge_AREA00_FINISH_BOARD.png` / SHA-256 `d39ae5077aed4388a8e9b6bc4d7c021317244d7f3e3ea4e76a4eac5f0c0ae699`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_stirge_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
