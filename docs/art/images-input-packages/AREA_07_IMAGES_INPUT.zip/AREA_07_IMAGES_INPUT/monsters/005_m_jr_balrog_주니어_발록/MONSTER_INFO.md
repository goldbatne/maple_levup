# Monster Reference — 주니어 발록

- 작업 순번: 005
- level: 70
- Area: `area_07` / 슬리피우드
- monster_id: `m_jr_balrog`
- model_id: `jrbalrog`
- image RUID: `4b3ad414c1184c02b5eb459b29ee8ece`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_balrog`
- skill name/type: 발록의 화염 파동 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
