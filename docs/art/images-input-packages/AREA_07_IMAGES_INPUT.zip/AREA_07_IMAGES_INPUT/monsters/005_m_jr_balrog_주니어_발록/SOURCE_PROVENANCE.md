# Source provenance — 주니어 발록 / 발록의 화염 파동

- rebuild run: `20260913_153134`
- base package: `AREA_07_IMAGES_INPUT.zip`
- base package SHA-256: `3a692b5113a32eca6a0702021274dec44026bd3c67807ee4a5cedc52b572da6a`
- preserved manifest monster image RUID: `4b3ad414c1184c02b5eb459b29ee8ece`
- preserved monster image status: `확보`
- preserved ids: `m_jr_balrog` / `s_mon_jr_balrog`
- preserved WHAT: `발록의 화염 파동` / `액티브` / `INT 계수 2.35로 반경 5.2 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.15초; 지속 0.85/0.7초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
