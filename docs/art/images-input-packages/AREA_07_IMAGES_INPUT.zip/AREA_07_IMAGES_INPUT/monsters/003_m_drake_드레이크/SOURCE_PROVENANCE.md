# Source provenance — 드레이크 / 동굴 용염

- rebuild run: `20260913_153134`
- base package: `AREA_07_IMAGES_INPUT.zip`
- base package SHA-256: `3a692b5113a32eca6a0702021274dec44026bd3c67807ee4a5cedc52b572da6a`
- preserved manifest monster image RUID: `f8cfac4e30394735861603f6bfcb1932`
- preserved monster image status: `확보`
- preserved ids: `m_drake` / `s_mon_drake`
- preserved WHAT: `동굴 용염` / `액티브` / `INT 계수 2.45로 반경 4.6 범위 최대 3대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.78초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
