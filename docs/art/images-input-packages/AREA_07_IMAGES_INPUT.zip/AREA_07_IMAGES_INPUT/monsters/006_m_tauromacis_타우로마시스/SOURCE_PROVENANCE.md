# Source provenance — 타우로마시스 / 수문장의 낙뢰

- rebuild run: `20260913_153134`
- base package: `AREA_07_IMAGES_INPUT.zip`
- base package SHA-256: `3a692b5113a32eca6a0702021274dec44026bd3c67807ee4a5cedc52b572da6a`
- preserved manifest monster image RUID: `5ef751fd743e41609bf98e03de4df51c`
- preserved monster image status: `확보`
- preserved ids: `m_tauromacis` / `s_mon_tauromacis`
- preserved WHAT: `수문장의 낙뢰` / `액티브` / `INT 계수 2.8로 반경 5.4 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.08초; 지속 0.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
