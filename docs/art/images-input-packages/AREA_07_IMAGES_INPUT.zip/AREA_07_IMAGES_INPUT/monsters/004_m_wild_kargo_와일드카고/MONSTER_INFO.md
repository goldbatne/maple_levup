# Monster Reference — 와일드카고

- 작업 순번: 004
- level: 68
- Area: `area_07` / 슬리피우드
- monster_id: `m_wild_kargo`
- model_id: `wildkargo`
- image RUID: `7d1c1d17eff44687b35ca0d5108084dc`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wild_kargo`
- skill name/type: 야수의 그림자 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
