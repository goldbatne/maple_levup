# Source provenance — 와일드카고 / 야수의 그림자 돌진

- rebuild run: `20260913_153134`
- base package: `AREA_07_IMAGES_INPUT.zip`
- base package SHA-256: `3a692b5113a32eca6a0702021274dec44026bd3c67807ee4a5cedc52b572da6a`
- preserved manifest monster image RUID: `7d1c1d17eff44687b35ca0d5108084dc`
- preserved monster image status: `확보`
- preserved ids: `m_wild_kargo` / `s_mon_wild_kargo`
- preserved WHAT: `야수의 그림자 돌진` / `액티브` / `ATK 계수 2.55로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8; 6.2 거리 돌진` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.04초; 지속 0.52/0.65초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
