# Source provenance — 좀비버섯 / 죽은 포자의 끈기

- rebuild run: `20260913_153134`
- base package: `AREA_07_IMAGES_INPUT.zip`
- base package SHA-256: `3a692b5113a32eca6a0702021274dec44026bd3c67807ee4a5cedc52b572da6a`
- preserved manifest monster image RUID: `3ee3fc0f4d2e443cbb9ec424dd2c012f`
- preserved monster image status: `확보`
- preserved ids: `m_zombie_mushroom` / `s_mon_zombie_mushroom`
- preserved WHAT: `죽은 포자의 끈기` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
