# Monster Reference — 좀비버섯

- 작업 순번: 001
- level: 61
- Area: `area_07` / 슬리피우드
- monster_id: `m_zombie_mushroom`
- model_id: `zombiemushroom`
- image RUID: `3ee3fc0f4d2e443cbb9ec424dd2c012f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_zombie_mushroom`
- skill name/type: 죽은 포자의 끈기 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
