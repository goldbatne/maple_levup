# Monster Reference — 카파 드레이크

- 작업 순번: 002
- level: 63
- Area: `area_07` / 슬리피우드
- monster_id: `m_copper_drake`
- model_id: `copperdrake`
- image RUID: `da160cd4b78c479ab8dfaa225b2dcd47`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_copper_drake`
- skill name/type: 청동 비늘 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
