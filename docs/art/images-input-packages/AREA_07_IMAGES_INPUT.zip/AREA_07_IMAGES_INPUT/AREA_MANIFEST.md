# area_07 슬리피우드 Manifest

- 처리 순서: 7
- 레벨 범위: Lv61~70
- 포획 가능 몬스터: 6종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 61 | area_07 | 슬리피우드 | m_zombie_mushroom | 좀비버섯 | 3ee3fc0f4d2e443cbb9ec424dd2c012f | 확보 | s_mon_zombie_mushroom | 죽은 포자의 끈기 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_zombie_mushroom_좀비버섯 |
| 2 | 63 | area_07 | 슬리피우드 | m_copper_drake | 카파 드레이크 | da160cd4b78c479ab8dfaa225b2dcd47 | 확보 | s_mon_copper_drake | 청동 비늘 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_copper_drake_카파_드레이크 |
| 3 | 65 | area_07 | 슬리피우드 | m_drake | 드레이크 | f8cfac4e30394735861603f6bfcb1932 | 확보 | s_mon_drake | 동굴 용염 | 액티브 | INT 계수 2.45로 반경 4.6 범위 최대 3대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.78초 | N | monsters/003_m_drake_드레이크 |
| 4 | 68 | area_07 | 슬리피우드 | m_wild_kargo | 와일드카고 | 7d1c1d17eff44687b35ca0d5108084dc | 확보 | s_mon_wild_kargo | 야수의 그림자 돌진 | 액티브 | ATK 계수 2.55로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8; 6.2 거리 돌진 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.04초; 지속 0.52/0.65초; 시전자가 목표 방향으로 돌진 | N | monsters/004_m_wild_kargo_와일드카고 |
| 5 | 70 | area_07 | 슬리피우드 | m_jr_balrog | 주니어 발록 | 4b3ad414c1184c02b5eb459b29ee8ece | 확보 | s_mon_jr_balrog | 발록의 화염 파동 | 액티브 | INT 계수 2.35로 반경 5.2 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.15초; 지속 0.85/0.7초 | Y | monsters/005_m_jr_balrog_주니어_발록 |
| 6 | 70 | area_07 | 슬리피우드 | m_tauromacis | 타우로마시스 | 5ef751fd743e41609bf98e03de4df51c | 확보 | s_mon_tauromacis | 수문장의 낙뢰 | 액티브 | INT 계수 2.8로 반경 5.4 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.08초; 지속 0.82초 | N | monsters/006_m_tauromacis_타우로마시스 |
