# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 좀비버섯 / 죽은 포자의 끈기: [monsters/001_m_zombie_mushroom_좀비버섯/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_zombie_mushroom_좀비버섯/DESIGN_REFERENCE_BRIEF.md) — mist, nature
- 카파 드레이크 / 청동 비늘: [monsters/002_m_copper_drake_카파_드레이크/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_copper_drake_카파_드레이크/DESIGN_REFERENCE_BRIEF.md) — metal, earth
- 드레이크 / 동굴 용염: [monsters/003_m_drake_드레이크/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_drake_드레이크/DESIGN_REFERENCE_BRIEF.md) — fire, dragon_fire
- 와일드카고 / 야수의 그림자 돌진: [monsters/004_m_wild_kargo_와일드카고/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_wild_kargo_와일드카고/DESIGN_REFERENCE_BRIEF.md) — needle, dark_magic
- 주니어 발록 / 발록의 화염 파동: [monsters/005_m_jr_balrog_주니어_발록/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_jr_balrog_주니어_발록/DESIGN_REFERENCE_BRIEF.md) — fire, dragon_fire
- 타우로마시스 / 수문장의 낙뢰: [monsters/006_m_tauromacis_타우로마시스/DESIGN_REFERENCE_BRIEF.md](../monsters/006_m_tauromacis_타우로마시스/DESIGN_REFERENCE_BRIEF.md) — lightning, metal