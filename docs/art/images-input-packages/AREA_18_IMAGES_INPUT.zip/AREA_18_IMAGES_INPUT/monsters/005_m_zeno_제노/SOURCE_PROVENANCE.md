# Source provenance — 제노 / 제노의 중력장

- rebuild run: `20260913_153134`
- base package: `AREA_18_IMAGES_INPUT.zip`
- base package SHA-256: `8401b4d95df01190356fc38689786ec2271c1d6b04de26925ec34e604cf411b9`
- preserved manifest monster image RUID: `689bc520bc2544abb62ec505ca91aab4`
- preserved monster image status: `확보`
- preserved ids: `m_zeno` / `s_mon_zeno`
- preserved WHAT: `제노의 중력장` / `액티브` / `INT 계수 5.7로 반경 7.2 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.24초; 지속 .82/.96초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
