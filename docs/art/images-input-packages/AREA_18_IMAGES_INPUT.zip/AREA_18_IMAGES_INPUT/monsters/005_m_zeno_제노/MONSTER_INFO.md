# Monster Reference — 제노

- 작업 순번: 005
- level: 180
- Area: `area_18` / 지구방위본부
- monster_id: `m_zeno`
- model_id: `zeno`
- image RUID: `689bc520bc2544abb62ec505ca91aab4`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_zeno`
- skill name/type: 제노의 중력장 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
