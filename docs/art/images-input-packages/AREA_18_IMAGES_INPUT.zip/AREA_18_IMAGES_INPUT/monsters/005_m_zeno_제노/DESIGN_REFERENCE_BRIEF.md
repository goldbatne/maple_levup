# 제노 — 제노의 중력장: 실제 디자인 참조

monster_id: `m_zeno` / skill_id: `s_mon_zeno` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 외계 코어 주위 공간이 오목하게 접히는 다중 중력륜. ‘제노 / 제노의 중력장’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 중력 자주 #62458E; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 외계 청록 #58C4B8; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘외계 코어’, 보조 효과 1개는 ‘오목한 중력륜’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/005_m_zeno_제노/MONSTER_IMAGE.png`

RUID: `689bc520bc2544abb62ec505ca91aab4` / SHA-256: `23403efbfe798399ecbc1e0d387af9c6f35f8155cb66d5b9b4553171dd55fb36`

## 이 스킬에 적용할 구체적인 디자인
여러 중력 고리가 오목하게 공간을 누르고 되풀린다. 돔 하나나 시계 숫자로 축약하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 옵시디언 배리어 / 옵시디언 배리어 강화 / `skill/40003.img/skill/400031037`
- 관찰한 표현: 어두운 반투명 면과 밝은 가장자리의 대비, 막이 약해지는 단계
- 가져오지 않을 요소: 노랑 돔과 원본 문양을 커튼·비늘·나무로 복제하지 않는다
- effect/0: `reference_resource_design/dark_barrier/source/41c77c14719a466f8540df2c4bd96cd6.gif` / SHA-256 `2ccf58661c2f7d0bce6f30e0e9f8cdfc8caf8cbaa040cc7f8eeba40da54d5c69`
  전체 연속 PNG 12장과 GIF 타이밍은 `reference_resource_design/dark_barrier/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/dark_barrier/frames/41c77c14719a466f8540df2c4bd96cd6_F000.png`
  - `reference_resource_design/dark_barrier/frames/41c77c14719a466f8540df2c4bd96cd6_F003.png`
  - `reference_resource_design/dark_barrier/frames/41c77c14719a466f8540df2c4bd96cd6_F006.png`
  - `reference_resource_design/dark_barrier/frames/41c77c14719a466f8540df2c4bd96cd6_F009.png`
  - `reference_resource_design/dark_barrier/frames/41c77c14719a466f8540df2c4bd96cd6_F011.png`
- finish/0: `reference_resource_design/dark_barrier/source/86ca451518fa48c1a0d9dd8283025b7b.gif` / SHA-256 `a122c76997a86222d66d1399baa77dfa9d86b7eb3adf071a5ad43c63412aede8`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/dark_barrier/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/dark_barrier/frames/86ca451518fa48c1a0d9dd8283025b7b_F000.png`
  - `reference_resource_design/dark_barrier/frames/86ca451518fa48c1a0d9dd8283025b7b_F001.png`
  - `reference_resource_design/dark_barrier/frames/86ca451518fa48c1a0d9dd8283025b7b_F002.png`
  - `reference_resource_design/dark_barrier/frames/86ca451518fa48c1a0d9dd8283025b7b_F003.png`
  - `reference_resource_design/dark_barrier/frames/86ca451518fa48c1a0d9dd8283025b7b_F004.png`
- icon: `reference_resource_design/dark_barrier/source/81ce8e5fbe0e46f1b0826ddc583bd54f.png` / SHA-256 `260509bd1d990f3ae345832d34c68d9e64689d374b96b7caf06c1debdaae7921`

### 타임 피스 / `skill/10114.img/skill/101141012`
- 관찰한 표현: 시계 고리의 얇은 중간층과 밝은 순간 코어, 갈라진 시간 잔상
- 가져오지 않을 요소: 시계 숫자·원본 문양을 에셋에 넣지 않는다. 시계 아닌 기계에 시계판을 추가하지 않는다
- effect: `reference_resource_design/clock/source/d39a27be8b5f4d4795ae8df9a675ed74.gif` / SHA-256 `4750a40c7254ceeece6e16ea073d485632c98d0376285ec997a01673803a5f20`
  전체 연속 PNG 20장과 GIF 타이밍은 `reference_resource_design/clock/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F000.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F005.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F010.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F015.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F019.png`
- hit/0: `reference_resource_design/clock/source/f7824277a0e140ecb1bd3a19df6f2fc5.gif` / SHA-256 `a1213533521db521d83e5051b51b86bea7c8dc494a6fb4bfb2df91527e30a8c3`
  전체 연속 PNG 7장과 GIF 타이밍은 `reference_resource_design/clock/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F000.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F001.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F003.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F005.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F006.png`
- icon: `reference_resource_design/clock/source/f92545bd29cf4ad98d02c19dba55ea3b.png` / SHA-256 `18c4344fb0889d8b2b0af9a449661fdd1fe6f0f0e4d1d58267c0f05bb173ee5b`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/005_m_zeno_제노/MONSTER_IMAGE.png` / SHA-256 `23403efbfe798399ecbc1e0d387af9c6f35f8155cb66d5b9b4553171dd55fb36`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_zeno_OFFICIAL_VFX_BOARD.png` / SHA-256 `1f22b091b4c28fd811984b0ae568a9449d2f6889f9e3bd1b39c8d90ed7712008`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_zeno_AREA00_FINISH_BOARD.png` / SHA-256 `152bbfb12f12fd053f8f39dad64e75219105f4dd388d2f32759f533c60293a7a`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_zeno_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
