# Monster Reference — 원로 그레이

- 작업 순번: 004
- level: 178
- Area: `area_18` / 지구방위본부
- monster_id: `m_chief_gray`
- model_id: `chiefgray`
- image RUID: `48027185a78d470da83199b478bed48b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_chief_gray`
- skill name/type: 원로의 정신연산 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
