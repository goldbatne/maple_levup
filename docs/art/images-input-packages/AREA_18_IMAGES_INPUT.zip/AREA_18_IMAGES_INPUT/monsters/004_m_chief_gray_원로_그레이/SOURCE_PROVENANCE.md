# Source provenance — 원로 그레이 / 원로의 정신연산

- rebuild run: `20260913_153134`
- base package: `AREA_18_IMAGES_INPUT.zip`
- base package SHA-256: `8401b4d95df01190356fc38689786ec2271c1d6b04de26925ec34e604cf411b9`
- preserved manifest monster image RUID: `48027185a78d470da83199b478bed48b`
- preserved monster image status: `확보`
- preserved ids: `m_chief_gray` / `s_mon_chief_gray`
- preserved WHAT: `원로의 정신연산` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
