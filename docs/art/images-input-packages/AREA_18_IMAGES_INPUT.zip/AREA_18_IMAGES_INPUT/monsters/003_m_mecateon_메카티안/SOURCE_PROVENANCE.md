# Source provenance — 메카티안 / 기계화 레이저

- rebuild run: `20260913_153134`
- base package: `AREA_18_IMAGES_INPUT.zip`
- base package SHA-256: `8401b4d95df01190356fc38689786ec2271c1d6b04de26925ec34e604cf411b9`
- preserved manifest monster image RUID: `1509ce195a5c49a0aea5f9b189ce7edb`
- preserved monster image status: `확보`
- preserved ids: `m_mecateon` / `s_mon_mecateon`
- preserved WHAT: `기계화 레이저` / `액티브` / `INT 계수 5.45로 반경 6 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .72/.84초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
