# Monster Reference — 메카티안

- 작업 순번: 003
- level: 175
- Area: `area_18` / 지구방위본부
- monster_id: `m_mecateon`
- model_id: `mecateon`
- image RUID: `1509ce195a5c49a0aea5f9b189ce7edb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mecateon`
- skill name/type: 기계화 레이저 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
