# Monster Reference — 플라티안

- 작업 순번: 002
- level: 173
- Area: `area_18` / 지구방위본부
- monster_id: `m_plateon`
- model_id: `plateon`
- image RUID: `e03cf5ce06784947b45ce95afb70927c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_plateon`
- skill name/type: 외계 장갑 조종 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
