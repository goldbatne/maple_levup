# Source provenance — 마티안 / 마티안 광선탄

- rebuild run: `20260913_153134`
- base package: `AREA_18_IMAGES_INPUT.zip`
- base package SHA-256: `8401b4d95df01190356fc38689786ec2271c1d6b04de26925ec34e604cf411b9`
- preserved manifest monster image RUID: `53043af9433844258a090f3b231ce39f`
- preserved monster image status: `확보`
- preserved ids: `m_mateon` / `s_mon_mateon`
- preserved WHAT: `마티안 광선탄` / `액티브` / `INT 계수 5.3로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .65/.78초; 투사체 22db356cc60940089b7f5d592c7d5813가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
