# Monster Reference — 마티안

- 작업 순번: 001
- level: 171
- Area: `area_18` / 지구방위본부
- monster_id: `m_mateon`
- model_id: `mateon`
- image RUID: `53043af9433844258a090f3b231ce39f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mateon`
- skill name/type: 마티안 광선탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
