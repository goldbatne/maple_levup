# 마티안 — 마티안 광선탄: 실제 디자인 참조

monster_id: `m_mateon` / skill_id: `s_mon_mateon` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 외계 수정핵에서 발사되는 둥근 황록 광선탄. ‘마티안 / 마티안 광선탄’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 외계 황록 #C8DD59; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 우주 청록 #55B9B0; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘외계 수정핵’, 보조 효과 1개는 ‘광선 꼬리’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/001_m_mateon_마티안/MONSTER_IMAGE.png`

RUID: `53043af9433844258a090f3b231ce39f` / SHA-256: `55c6e74e37221b644ae5e408f3676035eef92e46689a896d4b1cc899dae1a3fa`

## 이 스킬에 적용할 구체적인 디자인
외계 수정 코어의 둥근 황록 광탄과 꼬리를 분리한다. 푸른 전기탄·마법 후프를 그대로 사용하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 버블 스타 / 버블 스타 강화 / `skill/40000.img/skill/400004429`
- 관찰한 표현: 밝은 내부 코어와 반투명 외피, 진행 방향 쪽의 압축과 후방 잔상
- 가져오지 않을 요소: 보라 구체와 후프를 모든 투사체의 모양으로 사용하지 않는다
- ball: `reference_resource_design/bubble/source/e4912b933bbc48a483451dae347bf6f3.gif` / SHA-256 `ef279982003fd473729c6516a8ea1a89fdddbdbefd90a9230b4fd3d3980497f1`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F000.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F001.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F002.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F003.png`
- effect: `reference_resource_design/bubble/source/bcfebd118b0f4cb2b86971fe681b1081.gif` / SHA-256 `f197c7c9d60663bf5521183f5cb984b49c85251dd44f29627ce7462b7c7bbf5d`
  전체 연속 PNG 13장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F000.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F003.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F006.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F009.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F012.png`
- icon: `reference_resource_design/bubble/source/0b85676a40c74bc288d997270378bb12.png` / SHA-256 `6a6a6818cce417faa65da3e26a5732a11964f9550af30ebac3a115be60758656`

### 체인 라이트닝 VI / `skill/224.img/skill/2241000`
- 관찰한 표현: 진한 청색 면·청록 중간층·흰 코어와 짧은 전기 가지
- 가져오지 않을 요소: 구형 탄환·마법진 형태를 발차기나 낙뢰에 복제하지 않는다
- effect: `reference_resource_design/lightning/source/48b5cd234e65421a95dc18d157fa5d5d.gif` / SHA-256 `2e353622b49fa81b14a7d38f707b7ea5233e1c9ba2f5028afaaf175710b6308c`
  전체 연속 PNG 16장과 GIF 타이밍은 `reference_resource_design/lightning/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/lightning/frames/48b5cd234e65421a95dc18d157fa5d5d_F000.png`
  - `reference_resource_design/lightning/frames/48b5cd234e65421a95dc18d157fa5d5d_F004.png`
  - `reference_resource_design/lightning/frames/48b5cd234e65421a95dc18d157fa5d5d_F008.png`
  - `reference_resource_design/lightning/frames/48b5cd234e65421a95dc18d157fa5d5d_F012.png`
  - `reference_resource_design/lightning/frames/48b5cd234e65421a95dc18d157fa5d5d_F015.png`
- hit/0: `reference_resource_design/lightning/source/f69c3147a5f04dd8a32e5845f813644d.gif` / SHA-256 `6b0f60b6bf4e32e80ccafac32f2ae4ecee17a4c742d4554799ffb6a02c0f0c1e`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/lightning/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/lightning/frames/f69c3147a5f04dd8a32e5845f813644d_F000.png`
  - `reference_resource_design/lightning/frames/f69c3147a5f04dd8a32e5845f813644d_F002.png`
  - `reference_resource_design/lightning/frames/f69c3147a5f04dd8a32e5845f813644d_F004.png`
  - `reference_resource_design/lightning/frames/f69c3147a5f04dd8a32e5845f813644d_F006.png`
  - `reference_resource_design/lightning/frames/f69c3147a5f04dd8a32e5845f813644d_F007.png`
- icon: `reference_resource_design/lightning/source/3fdbaaaad1b7478b8109aac180465e82.png` / SHA-256 `ffb9250651e087e2592fc391d868928fc8cee5d288a146b47c3a68ea8a56b585`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/001_m_mateon_마티안/MONSTER_IMAGE.png` / SHA-256 `55c6e74e37221b644ae5e408f3676035eef92e46689a896d4b1cc899dae1a3fa`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_mateon_OFFICIAL_VFX_BOARD.png` / SHA-256 `606766ac2e09b4a221635abd0d3f5d8608640bc6ac54584db56020e50fcc6f4e`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_mateon_AREA00_FINISH_BOARD.png` / SHA-256 `af7877a4e0cebc075b120d499cc71f10439ab8a41aadcaad37cebfdd9ec49e20`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_mateon_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
