# area_18 지구방위본부 Manifest

- 처리 순서: 18
- 레벨 범위: Lv171~180
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 171 | area_18 | 지구방위본부 | m_mateon | 마티안 | 53043af9433844258a090f3b231ce39f | 확보 | s_mon_mateon | 마티안 광선탄 | 액티브 | INT 계수 5.3로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .65/.78초; 투사체 22db356cc60940089b7f5d592c7d5813가 목표 방향으로 이동 | N | monsters/001_m_mateon_마티안 |
| 2 | 173 | area_18 | 지구방위본부 | m_plateon | 플라티안 | e03cf5ce06784947b45ce95afb70927c | 확보 | s_mon_plateon | 외계 장갑 조종 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_plateon_플라티안 |
| 3 | 175 | area_18 | 지구방위본부 | m_mecateon | 메카티안 | 1509ce195a5c49a0aea5f9b189ce7edb | 확보 | s_mon_mecateon | 기계화 레이저 | 액티브 | INT 계수 5.45로 반경 6 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .72/.84초 | N | monsters/003_m_mecateon_메카티안 |
| 4 | 178 | area_18 | 지구방위본부 | m_chief_gray | 원로 그레이 | 48027185a78d470da83199b478bed48b | 확보 | s_mon_chief_gray | 원로의 정신연산 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_chief_gray_원로_그레이 |
| 5 | 180 | area_18 | 지구방위본부 | m_zeno | 제노 | 689bc520bc2544abb62ec505ca91aab4 | 확보 | s_mon_zeno | 제노의 중력장 | 액티브 | INT 계수 5.7로 반경 7.2 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.24초; 지속 .82/.96초 | Y | monsters/005_m_zeno_제노 |
