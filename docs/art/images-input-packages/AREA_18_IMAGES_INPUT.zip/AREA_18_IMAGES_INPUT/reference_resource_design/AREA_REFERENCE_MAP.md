# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 마티안 / 마티안 광선탄: [monsters/001_m_mateon_마티안/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_mateon_마티안/DESIGN_REFERENCE_BRIEF.md) — bubble, lightning
- 플라티안 / 외계 장갑 조종: [monsters/002_m_plateon_플라티안/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_plateon_플라티안/DESIGN_REFERENCE_BRIEF.md) — metal, clock
- 메카티안 / 기계화 레이저: [monsters/003_m_mecateon_메카티안/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_mecateon_메카티안/DESIGN_REFERENCE_BRIEF.md) — earth_breath, lightning
- 원로 그레이 / 원로의 정신연산: [monsters/004_m_chief_gray_원로_그레이/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_chief_gray_원로_그레이/DESIGN_REFERENCE_BRIEF.md) — bubble, clock
- 제노 / 제노의 중력장: [monsters/005_m_zeno_제노/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_zeno_제노/DESIGN_REFERENCE_BRIEF.md) — dark_barrier, clock