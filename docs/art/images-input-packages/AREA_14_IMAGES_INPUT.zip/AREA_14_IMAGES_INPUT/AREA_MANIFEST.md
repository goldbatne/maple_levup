# area_14 마가티아 Manifest

- 처리 순서: 14
- 레벨 범위: Lv131~140
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 131 | area_14 | 마가티아 | m_cube_slime | 큐브슬라임 | e93e27480f1043ef8e51fa3b0906a4d9 | 확보 | s_mon_cube_slime | 연금 큐브막 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_cube_slime_큐브슬라임 |
| 2 | 133 | area_14 | 마가티아 | m_mithril_mutae | 미스릴 뮤테 | b06abb18fb52476d8bc7bdd5e46abe19 | 확보 | s_mon_mithril_mutae | 미스릴 외피 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_mithril_mutae_미스릴_뮤테 |
| 3 | 135 | area_14 | 마가티아 | m_homun | 호문 | 8f0fb531779d41738664009091d7b017 | 확보 | s_mon_homun | 플라스크 독무 | 액티브 | INT 계수 4.1로 반경 5.4 범위 최대 4대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.82초 | N | monsters/003_m_homun_호문 |
| 4 | 138 | area_14 | 마가티아 | m_roid | 로이드 | 364bc76e0cc3429ea8ca758319ec7678 | 확보 | s_mon_roid | 알카드노 에너지탄 | 액티브 | ATK 계수 4.2로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.2초; 지속 0.72초; 투사체 e51545cbf94349f59f4431e2e76d2cdc가 목표 방향으로 이동 | N | monsters/004_m_roid_로이드 |
| 5 | 140 | area_14 | 마가티아 | m_chimera | 키메라 | 3f5236d28b1f409797fe7c4b48743b8a | 확보 | s_mon_chimera | 융합체의 산성 포격 | 액티브 | INT 계수 4.55로 반경 6.8 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0.2/0초; 지속 0.8/0.9초; 투사체 ab113d9a5ca5402d85ecc2ab7a4f51a1가 목표 방향으로 이동 | Y | monsters/005_m_chimera_키메라 |
