# Source provenance — 로이드 / 알카드노 에너지탄

- rebuild run: `20260913_153134`
- base package: `AREA_14_IMAGES_INPUT.zip`
- base package SHA-256: `1abddb4096d5af4ded14ba0f36b339334ed23beb7dfd674e2a6ef3ce349e355c`
- preserved manifest monster image RUID: `364bc76e0cc3429ea8ca758319ec7678`
- preserved monster image status: `확보`
- preserved ids: `m_roid` / `s_mon_roid`
- preserved WHAT: `알카드노 에너지탄` / `액티브` / `ATK 계수 4.2로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.2초; 지속 0.72초; 투사체 e51545cbf94349f59f4431e2e76d2cdc가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
