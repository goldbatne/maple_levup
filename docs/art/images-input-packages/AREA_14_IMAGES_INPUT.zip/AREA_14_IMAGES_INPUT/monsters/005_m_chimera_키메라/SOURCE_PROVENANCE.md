# Source provenance — 키메라 / 융합체의 산성 포격

- rebuild run: `20260913_153134`
- base package: `AREA_14_IMAGES_INPUT.zip`
- base package SHA-256: `1abddb4096d5af4ded14ba0f36b339334ed23beb7dfd674e2a6ef3ce349e355c`
- preserved manifest monster image RUID: `3f5236d28b1f409797fe7c4b48743b8a`
- preserved monster image status: `확보`
- preserved ids: `m_chimera` / `s_mon_chimera`
- preserved WHAT: `융합체의 산성 포격` / `액티브` / `INT 계수 4.55로 반경 6.8 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0.2/0초; 지속 0.8/0.9초; 투사체 ab113d9a5ca5402d85ecc2ab7a4f51a1가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
