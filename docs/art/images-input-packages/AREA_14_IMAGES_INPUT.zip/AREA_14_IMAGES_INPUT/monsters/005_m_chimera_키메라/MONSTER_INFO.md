# Monster Reference — 키메라

- 작업 순번: 005
- level: 140
- Area: `area_14` / 마가티아
- monster_id: `m_chimera`
- model_id: `chimera`
- image RUID: `3f5236d28b1f409797fe7c4b48743b8a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_chimera`
- skill name/type: 융합체의 산성 포격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
