# Monster Reference — 호문

- 작업 순번: 003
- level: 135
- Area: `area_14` / 마가티아
- monster_id: `m_homun`
- model_id: `homun`
- image RUID: `8f0fb531779d41738664009091d7b017`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_homun`
- skill name/type: 플라스크 독무 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
