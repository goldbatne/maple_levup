# Source provenance — 호문 / 플라스크 독무

- rebuild run: `20260913_153134`
- base package: `AREA_14_IMAGES_INPUT.zip`
- base package SHA-256: `1abddb4096d5af4ded14ba0f36b339334ed23beb7dfd674e2a6ef3ce349e355c`
- preserved manifest monster image RUID: `8f0fb531779d41738664009091d7b017`
- preserved monster image status: `확보`
- preserved ids: `m_homun` / `s_mon_homun`
- preserved WHAT: `플라스크 독무` / `액티브` / `INT 계수 4.1로 반경 5.4 범위 최대 4대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
