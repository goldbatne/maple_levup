# Monster Reference — 미스릴 뮤테

- 작업 순번: 002
- level: 133
- Area: `area_14` / 마가티아
- monster_id: `m_mithril_mutae`
- model_id: `mithrilmutae`
- image RUID: `b06abb18fb52476d8bc7bdd5e46abe19`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mithril_mutae`
- skill name/type: 미스릴 외피 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
