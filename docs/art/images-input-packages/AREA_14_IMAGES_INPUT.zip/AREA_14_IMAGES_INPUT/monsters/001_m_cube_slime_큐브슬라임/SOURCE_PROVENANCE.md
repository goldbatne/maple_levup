# Source provenance — 큐브슬라임 / 연금 큐브막

- rebuild run: `20260913_153134`
- base package: `AREA_14_IMAGES_INPUT.zip`
- base package SHA-256: `1abddb4096d5af4ded14ba0f36b339334ed23beb7dfd674e2a6ef3ce349e355c`
- preserved manifest monster image RUID: `e93e27480f1043ef8e51fa3b0906a4d9`
- preserved monster image status: `확보`
- preserved ids: `m_cube_slime` / `s_mon_cube_slime`
- preserved WHAT: `연금 큐브막` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
