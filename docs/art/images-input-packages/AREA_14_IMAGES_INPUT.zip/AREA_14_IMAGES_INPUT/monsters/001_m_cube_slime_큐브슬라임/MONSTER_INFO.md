# Monster Reference — 큐브슬라임

- 작업 순번: 001
- level: 131
- Area: `area_14` / 마가티아
- monster_id: `m_cube_slime`
- model_id: `cubeslime`
- image RUID: `e93e27480f1043ef8e51fa3b0906a4d9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_cube_slime`
- skill name/type: 연금 큐브막 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
