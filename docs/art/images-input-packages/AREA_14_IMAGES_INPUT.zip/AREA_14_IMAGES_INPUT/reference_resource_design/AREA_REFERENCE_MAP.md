# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 큐브슬라임 / 연금 큐브막: [monsters/001_m_cube_slime_큐브슬라임/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_cube_slime_큐브슬라임/DESIGN_REFERENCE_BRIEF.md) — water_shield, metal
- 미스릴 뮤테 / 미스릴 외피: [monsters/002_m_mithril_mutae_미스릴_뮤테/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_mithril_mutae_미스릴_뮤테/DESIGN_REFERENCE_BRIEF.md) — metal, ice
- 호문 / 플라스크 독무: [monsters/003_m_homun_호문/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_homun_호문/DESIGN_REFERENCE_BRIEF.md) — mist, water
- 로이드 / 알카드노 에너지탄: [monsters/004_m_roid_로이드/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_roid_로이드/DESIGN_REFERENCE_BRIEF.md) — bubble, earth_breath
- 키메라 / 융합체의 산성 포격: [monsters/005_m_chimera_키메라/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_chimera_키메라/DESIGN_REFERENCE_BRIEF.md) — water, mist