# Source provenance — 정식기사 C / 기사단 뇌전 연각

- rebuild run: `20260913_153134`
- base package: `AREA_19_IMAGES_INPUT.zip`
- base package SHA-256: `3efc27df63567cff3f2a66baa15e685fe1907af16beba9da0ec9f4a693535404`
- preserved manifest monster image RUID: `da57403b50694b12bf0e19aa3a64112d`
- preserved monster image status: `확보`
- preserved ids: `m_official_knight_c` / `s_mon_official_knight_c`
- preserved WHAT: `기사단 뇌전 연각` / `액티브` / `ATK 계수 5.85로 반경 5.9 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.17초; 지속 .7/.78초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
