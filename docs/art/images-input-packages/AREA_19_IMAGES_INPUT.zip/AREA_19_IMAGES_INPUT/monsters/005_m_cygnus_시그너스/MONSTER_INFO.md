# Monster Reference — 시그너스

- 작업 순번: 005
- level: 190
- Area: `area_19` / 미래의 문
- monster_id: `m_cygnus`
- model_id: `cygnus`
- image RUID: `397136593bdb4e37b17d0d9e40ce0006`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_cygnus`
- skill name/type: 타락한 여제의 정원 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
