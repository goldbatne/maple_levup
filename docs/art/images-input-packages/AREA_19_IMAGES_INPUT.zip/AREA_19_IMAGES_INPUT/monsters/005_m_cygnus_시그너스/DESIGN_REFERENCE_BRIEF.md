# 시그너스 — 타락한 여제의 정원: 실제 디자인 참조

monster_id: `m_cygnus` / skill_id: `s_mon_cygnus` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 검게 시든 정원 꽃잎이 왕관형 소용돌이를 이루는 장막. ‘시그너스 / 타락한 여제의 정원’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 타락 자주 #68456E; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 시든 장미 적색 #9E4555; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘검은 꽃왕관’, 보조 효과 1개는 ‘시든 꽃잎 소용돌이’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/005_m_cygnus_시그너스/MONSTER_IMAGE.png`

RUID: `397136593bdb4e37b17d0d9e40ce0006` / SHA-256: `1c3d1637bbfa21c51fd9ce3d5a4996e93968267ff48bcaa3d17c7c8386ea47bd`

## 이 스킬에 적용할 구체적인 디자인
시든 검은 정원의 꽃잎이 왕관 같은 와류 장막을 만든다. 거대 검이나 연두 회오리보다 꽃잎과 커튼 층을 유지한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 하울링 게일 / 하울링 게일 강화 / `skill/40003.img/skill/400031068`
- 관찰한 표현: 굵기 다른 회전 바람띠와 띠 사이 빈 공간, 분리된 작은 입자
- 가져오지 않을 요소: 수직 회오리와 연두색을 그대로 복제하지 않는다
- ball: `reference_resource_design/gale/source/a1ccfefaa1f545ca99d0a71af81f7532.gif` / SHA-256 `ce1828497f3b79ed77afc34e4781c62e470ce3c5f071fb5eab450a1ae18cbd35`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/gale/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F000.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F001.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F003.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F004.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F005.png`
- icon: `reference_resource_design/gale/source/bee2fed28830476da192fd3f67bf4a4a.png` / SHA-256 `6be7e7d34a66cb13061664fc2f704909e523c9aa797b7124459eb2230ba5448b`

### 엔드리스 다크니스 / `skill/2714.img/skill/27140002`
- 관찰한 표현: 길게 당겨진 어두운 물질과 얇은 보랏빛 코어가 분리되어 소실
- 가져오지 않을 요소: 공식 검이나 날 형상을 그대로 복제하지 않는다
- effect: `reference_resource_design/dark_magic/source/194e46bbd5214672b1a6610e48fec7e0.gif` / SHA-256 `d1776e21b2b35e2344440ca42b6c77dfb94cd4cad93d56ce96086728e634354a`
  전체 연속 PNG 12장과 GIF 타이밍은 `reference_resource_design/dark_magic/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F000.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F003.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F006.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F009.png`
  - `reference_resource_design/dark_magic/frames/194e46bbd5214672b1a6610e48fec7e0_F011.png`
- icon: `reference_resource_design/dark_magic/source/0a58c21f9b7741df95a535ceea23f12e.png` / SHA-256 `9863c1da8d1b965f853d034e39b22d195d1b124fd50f53e84fa65e2ed5905192`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`
- `global_skill_style_library/area00_finish_baseline/icons/004_m_mano_s_mon_mano_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F07.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F08.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F09.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F10.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/005_m_cygnus_시그너스/MONSTER_IMAGE.png` / SHA-256 `1c3d1637bbfa21c51fd9ce3d5a4996e93968267ff48bcaa3d17c7c8386ea47bd`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_cygnus_OFFICIAL_VFX_BOARD.png` / SHA-256 `311145c350f199b5b9368aebaa0b778396dae74f914ff97dcf3d1dd834dd6c58`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_cygnus_AREA00_FINISH_BOARD.png` / SHA-256 `bc5f312c89cdb934476a4a93f15cf2f9cb742b546f782d4bd21e0ac1e2d5665f`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_cygnus_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
