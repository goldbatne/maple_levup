# Source provenance — 시그너스 / 타락한 여제의 정원

- rebuild run: `20260913_153134`
- base package: `AREA_19_IMAGES_INPUT.zip`
- base package SHA-256: `3efc27df63567cff3f2a66baa15e685fe1907af16beba9da0ec9f4a693535404`
- preserved manifest monster image RUID: `397136593bdb4e37b17d0d9e40ce0006`
- preserved monster image status: `확보`
- preserved ids: `m_cygnus` / `s_mon_cygnus`
- preserved WHAT: `타락한 여제의 정원` / `액티브` / `INT 계수 6.35로 반경 7.4 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.28초; 지속 .9/1.02초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
