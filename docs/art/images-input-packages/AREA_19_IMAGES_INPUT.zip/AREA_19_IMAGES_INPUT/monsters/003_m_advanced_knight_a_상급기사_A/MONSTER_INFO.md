# Monster Reference — 상급기사 A

- 작업 순번: 003
- level: 185
- Area: `area_19` / 미래의 문
- monster_id: `m_advanced_knight_a`
- model_id: `advancedknighta`
- image RUID: `b2ab0d2ec4d346079c5738c79c8b909b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_advanced_knight_a`
- skill name/type: 그림자 기사의 민첩 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
