# Source provenance — 상급기사 A / 그림자 기사의 민첩

- rebuild run: `20260913_153134`
- base package: `AREA_19_IMAGES_INPUT.zip`
- base package SHA-256: `3efc27df63567cff3f2a66baa15e685fe1907af16beba9da0ec9f4a693535404`
- preserved manifest monster image RUID: `b2ab0d2ec4d346079c5738c79c8b909b`
- preserved monster image status: `확보`
- preserved ids: `m_advanced_knight_a` / `s_mon_advanced_knight_a`
- preserved WHAT: `그림자 기사의 민첩` / `패시브` / `보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
