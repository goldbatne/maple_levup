# Monster Reference — 정식기사 D

- 작업 순번: 002
- level: 183
- Area: `area_19` / 미래의 문
- monster_id: `m_official_knight_d`
- model_id: `officialknightd`
- image RUID: `1b11119e13474135882191d052342552`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_official_knight_d`
- skill name/type: 기사단의 바람 조준 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
