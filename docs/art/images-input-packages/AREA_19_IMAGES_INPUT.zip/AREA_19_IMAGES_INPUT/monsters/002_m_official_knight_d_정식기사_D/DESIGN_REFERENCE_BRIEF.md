# 정식기사 D — 기사단의 바람 조준: 실제 디자인 참조

monster_id: `m_official_knight_d` / skill_id: `s_mon_official_knight_d` / 타입: 패시브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 바람 깃이 한 점으로 모이는 조준선과 화살표형 압축광. ‘정식기사 D / 기사단의 바람 조준’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 바람 청록 #64C7B3; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 기사 은백 #D7E4E2; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘바람 깃’, 보조 효과 1개는 ‘조준 십자’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/002_m_official_knight_d_정식기사_D/MONSTER_IMAGE.png`

RUID: `1b11119e13474135882191d052342552` / SHA-256: `ea75c5807194bf4b90906c6a0c1217e2f320b03c620456d29ab96e2a4ae286a1`

## 이 스킬에 적용할 구체적인 디자인
바람 깃이 초점으로 모이고 조준선이 압축되는 ICON이다. 수직 회오리나 화염탄을 복제하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 하울링 게일 / 하울링 게일 강화 / `skill/40003.img/skill/400031068`
- 관찰한 표현: 굵기 다른 회전 바람띠와 띠 사이 빈 공간, 분리된 작은 입자
- 가져오지 않을 요소: 수직 회오리와 연두색을 그대로 복제하지 않는다
- ball: `reference_resource_design/gale/source/a1ccfefaa1f545ca99d0a71af81f7532.gif` / SHA-256 `ce1828497f3b79ed77afc34e4781c62e470ce3c5f071fb5eab450a1ae18cbd35`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/gale/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F000.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F001.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F003.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F004.png`
  - `reference_resource_design/gale/frames/a1ccfefaa1f545ca99d0a71af81f7532_F005.png`
- icon: `reference_resource_design/gale/source/bee2fed28830476da192fd3f67bf4a4a.png` / SHA-256 `6be7e7d34a66cb13061664fc2f704909e523c9aa797b7124459eb2230ba5448b`

### 브레스 오브 어스 / `skill/2217.img/skill/22170065`
- 관찰한 표현: 가늘고 긴 전방 코어와 색이 분리된 짧은 후방 잔상
- 가져오지 않을 요소: 원본 불색·두 갈래 날을 광선의 고유 모양으로 복제하지 않는다
- ball/0: `reference_resource_design/earth_breath/source/4e4243b431484bfd9efeed82722a6dab.gif` / SHA-256 `323e429d4e9652bef33d3eb1b8c4dde745cb0b3266842829d0b847877d91ecf4`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/earth_breath/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/earth_breath/frames/4e4243b431484bfd9efeed82722a6dab_F000.png`
  - `reference_resource_design/earth_breath/frames/4e4243b431484bfd9efeed82722a6dab_F002.png`
  - `reference_resource_design/earth_breath/frames/4e4243b431484bfd9efeed82722a6dab_F004.png`
  - `reference_resource_design/earth_breath/frames/4e4243b431484bfd9efeed82722a6dab_F006.png`
  - `reference_resource_design/earth_breath/frames/4e4243b431484bfd9efeed82722a6dab_F007.png`
- icon: `reference_resource_design/earth_breath/source/29695aea498a44ca9771edf758e6a98a.png` / SHA-256 `0f5be20dd68e2a45d6df143126438a120456ce3ea7667d0aa32841006d4db5fb`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/002_m_official_knight_d_정식기사_D/MONSTER_IMAGE.png` / SHA-256 `ea75c5807194bf4b90906c6a0c1217e2f320b03c620456d29ab96e2a4ae286a1`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_official_knight_d_OFFICIAL_VFX_BOARD.png` / SHA-256 `faf6898d69d5b01bfa345e1bb997024f5d80cf78d430a288a8cc55ab304d8fbb`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_official_knight_d_AREA00_FINISH_BOARD.png` / SHA-256 `7363349147294ff90b67db9d5b843b3e8e5d11b999078d67f93b3f9616dd1593`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_official_knight_d_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
