# Monster Reference — 상급기사 B

- 작업 순번: 004
- level: 188
- Area: `area_19` / 미래의 문
- monster_id: `m_advanced_knight_b`
- model_id: `advancedknightb`
- image RUID: `3a107a08957f442d8b3e191258198056`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_advanced_knight_b`
- skill name/type: 상급기사의 이프리트 화염 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
