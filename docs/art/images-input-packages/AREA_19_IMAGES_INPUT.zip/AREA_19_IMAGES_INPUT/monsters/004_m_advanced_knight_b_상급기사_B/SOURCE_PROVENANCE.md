# Source provenance — 상급기사 B / 상급기사의 이프리트 화염

- rebuild run: `20260913_153134`
- base package: `AREA_19_IMAGES_INPUT.zip`
- base package SHA-256: `3efc27df63567cff3f2a66baa15e685fe1907af16beba9da0ec9f4a693535404`
- preserved manifest monster image RUID: `3a107a08957f442d8b3e191258198056`
- preserved monster image status: `확보`
- preserved ids: `m_advanced_knight_b` / `s_mon_advanced_knight_b`
- preserved WHAT: `상급기사의 이프리트 화염` / `액티브` / `INT 계수 6.05로 반경 6.2 범위 최대 4대상 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .78/.88초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
