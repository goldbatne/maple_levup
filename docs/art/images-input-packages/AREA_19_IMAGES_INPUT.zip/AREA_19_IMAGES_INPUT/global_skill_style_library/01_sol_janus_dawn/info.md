# 솔 야누스 : 새벽

- 공식 MSW resource pack: `skill/50000.img/skill/500001003`
- 분류: `CURRENT_NAMED_REFERENCE`
- 시기 근거: 2023-12-21 공용 6차 코어 추가
- 시기 근거 URL: https://maplestory.nexon.com/news/update/731
- 적용 계열: `persistent|summon|field|aura`
- 대표 animationclip RUID: `42556f51b9a542678b98d225e665b836`
- 대표 icon RUID: `c0af00f1a35b496582932d23471a6403`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| animationclip | `42556f51b9a542678b98d225e665b836` | `effect` |
| sprite | `c0af00f1a35b496582932d23471a6403` | `icon` |
| sprite | `df8a7d5269784e849c92d15ee5188a9d` | `iconDisabled` |
| sprite | `05f893097ff74e1d8debb7c836af6f88` | `iconMouseOver` |
| animationclip | `306345a6c275492b95777d482e2ca393` | `special` |
| animationclip | `dfe9750daa914bc7a32536b58433ca62` | `hit/0` |
| animationclip | `5a279d3b2dc4401cba005ce00f20fb3a` | `summon/die` |
| animationclip | `15778a3982df41ae9a73d05ee779edf0` | `summon/stand` |
| animationclip | `4956b1cf7e2e465ebaa4a036de57300d` | `summon/summoned` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
