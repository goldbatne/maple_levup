# AREA 00 finish baseline

이 폴더는 실제 AREA 00 수정 후보의 최종 PNG에서 추출한 마감 기준이다.

- 참고: 명암 구조, 재질의 층, 밝은 코어, 반투명 가장자리, 프레임 간 형태 변화, ICON/VFX 연결
- 복제 금지: AREA 00의 저레벨 크기, 색상, 방울·껍질·무지개 형상, 프레임 수, 스킬 구성
- `selected_vfx_frames`는 각 스킬의 시작/중간/끝 대표 프레임이며 전체 애니메이션을 대체하지 않는다.
- 원본: `docs/art/area00_refinement/20260912_203404/AREA_00_IMAGES_OUTPUT_REFINED_CANDIDATE.zip`

## 전체 연속 원본

full_vfx_frames에는 위 원본 ZIP과 해시로 연결된 VFX 44프레임 전체가 있다. selected_vfx_frames는 빠른 비교용이며 실제 연속 형상 확인은 full_vfx_frames를 사용한다. 원본 경로/해시는 FULL_SEQUENCE_SOURCE.json에 기록했다. 기존 OUTPUT을 바꾸거나 새 후보를 승인한 것이 아니다.
