# 암살 VI

- 공식 MSW resource pack: `skill/424.img/skill/4241001`
- 분류: `NAMED_STRUCTURE_REFERENCE`
- 시기 근거: 6차 스킬 계열; 공식 리소스 팩 이름 일치
- 시기 근거 URL: https://maplestory.nexon.com/news/update/712
- 적용 계열: `melee|dash|sharp|impact|multi-stage`
- 대표 animationclip RUID: `5be8668a22e34a84bc218ee96c40ab19`
- 대표 icon RUID: `a8ef90fb53da4ab0b30ee662a96198b8`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| animationclip | `5be8668a22e34a84bc218ee96c40ab19` | `effect` |
| animationclip | `83891a6b78fb4861a3d6e53a51306ec9` | `effect2` |
| sprite | `a8ef90fb53da4ab0b30ee662a96198b8` | `icon` |
| sprite | `19cf34fbd64e4c4c8692896556e0e850` | `iconDisabled` |
| sprite | `6e6d38b06da1451893e31e04ed3971e8` | `iconMouseOver` |
| animationclip | `888e0446d74b40728451e5edc1c6714d` | `hit/0` |
| animationclip | `ce5b90adf98241ca86e6bb48b7c41a42` | `hit2/0` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
