# 다크 신서시스 VI

- 공식 MSW resource pack: `skill/134.img/skill/1341003`
- 분류: `NAMED_STRUCTURE_REFERENCE`
- 시기 근거: 2023-12-28 6차 마스터리 코어 추가
- 시기 근거 URL: https://maplestory.nexon.com/testworld/news/update/17
- 적용 계열: `dark|area|wave|explosion`
- 대표 animationclip RUID: `dc04344c2a814f188b0795ba5e445319`
- 대표 icon RUID: `ca7e6cfa37464ab8bb780817e479ca6a`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| animationclip | `dc04344c2a814f188b0795ba5e445319` | `effect` |
| sprite | `ca7e6cfa37464ab8bb780817e479ca6a` | `icon` |
| sprite | `14bb706327454c83bc5c4e291ae15a27` | `iconDisabled` |
| sprite | `e3a2adfd36d0446e9ef76b81ba634a05` | `iconMouseOver` |
| animationclip | `5a3b6db42a3e4e2e8b1428de9a3de764` | `hit/0` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
