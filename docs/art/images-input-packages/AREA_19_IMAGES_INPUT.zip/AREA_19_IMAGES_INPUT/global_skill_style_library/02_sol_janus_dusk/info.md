# 솔 야누스 : 황혼

- 공식 MSW resource pack: `skill/50000.img/skill/500001001`
- 분류: `CURRENT_NAMED_REFERENCE`
- 시기 근거: 2023-12-21 공용 6차 코어 추가
- 시기 근거 URL: https://maplestory.nexon.com/news/update/731
- 적용 계열: `persistent|multi-hit|falling|field`
- 대표 animationclip RUID: `569dae6ccfea4a558fb5d2d0b7cf263d`
- 대표 icon RUID: `44dcf8431e9d485a99f4127ae51a3703`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| animationclip | `569dae6ccfea4a558fb5d2d0b7cf263d` | `effect` |
| sprite | `44dcf8431e9d485a99f4127ae51a3703` | `icon` |
| sprite | `6e837adb6d4b42c29660de4d431b96a0` | `iconDisabled` |
| sprite | `53bce7bb86fe4fc2b3c7d3d08e43819d` | `iconMouseOver` |
| animationclip | `bc2fc9ebec4c488197142217d0d2d549` | `hit/0` |
| animationclip | `369c93d774524b8db32d6c9f4fb814be` | `hit/1` |
| animationclip | `0f0f0028769b44f3b7d0e9a79eeb6048` | `hit/2` |
| animationclip | `8f47f30b605740b3aadccb599b403f1f` | `hit/3` |
| animationclip | `91215cc2e6c249149ced257df2a3006c` | `hit/4` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
