# Currentness exclusions

검색 결과에는 남아 있지만 현행 제작의 positive visual reference에서 제외한 항목이다. 이미지 파일은 패키지에 넣지 않는다.

- **얼티메이트-싸이킥 샷 VI** `skill/14214.img/skill/142140004`: 2025-12-18 키네시스 리마스터에서 삭제 확인. 팩 구조는 조회되지만 현행 positive visual reference에서 제외. 근거: https://maplestory.nexon.com/news/update/792
