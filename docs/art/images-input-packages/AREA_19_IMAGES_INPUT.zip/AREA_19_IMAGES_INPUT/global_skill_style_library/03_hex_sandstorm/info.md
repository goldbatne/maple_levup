# 헥스 : 샌드스톰

- 공식 MSW resource pack: `skill/15414.img/skill/154141500`
- 분류: `NAMED_STRUCTURE_REFERENCE`
- 시기 근거: 6차 스킬 계열; 공식 리소스 팩 이름 일치
- 시기 근거 URL: https://maplestory.nexon.com/news/update/712
- 적용 계열: `charge|area|earth|wind|impact`
- 대표 animationclip RUID: `28c33a05afb04953a8b3527b9a374382`
- 대표 icon RUID: `7e6eda520af54b87bc552712f3804ea6`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| sprite | `7e6eda520af54b87bc552712f3804ea6` | `icon` |
| sprite | `2122b97884be470d9258690bf6a49a1d` | `iconDisabled` |
| sprite | `21220e46c6454fc5be71ce5b6025448d` | `iconMouseOver` |
| animationclip | `28c33a05afb04953a8b3527b9a374382` | `keydown` |
| animationclip | `b97b5eda839440c3921f38656ef77649` | `keydownend` |
| animationclip | `68f99c9a1c9844908757d29d8b84ec9f` | `prepare` |
| animationclip | `6b28eb427ab9412fbe23e321b71dd64a` | `prepare0` |
| animationclip | `8d621cb939c34cfb97d2f73a8e0f4e5c` | `hit/0` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
