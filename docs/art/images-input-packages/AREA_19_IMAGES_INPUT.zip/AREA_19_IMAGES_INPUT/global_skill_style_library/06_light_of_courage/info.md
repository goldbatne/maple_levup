# 라이트 오브 커리지

- 공식 MSW resource pack: `skill/40001.img/skill/400011127`
- 분류: `SUPPLEMENTARY_STRUCTURE_REFERENCE`
- 시기 근거: 공식 리소스 팩 이름 일치; 자산 개정일 미제공
- 시기 근거 URL: https://maplestoryworlds-resourcesearch-new.nexon.com/search?category=skill&selected=skill/40001.img/skill/400011127
- 적용 계열: `buff|shield|aura|loop|end`
- 대표 animationclip RUID: `47d02b9a7fd54d418e76cd633f8b5768`
- 대표 icon RUID: `ab8d8a7b108a4df185353df5d992a828`
- 조회 방식: MSW 공식 리소스 검색기와 `/api/v3/search/resources` 결과에서 첫 한국어 이름이 질의와 일치함을 확인

## 팩 역할 구조

| type | RUID | rel_path |
|---|---|---|
| animationclip | `d0c52ee3fd464c8fa94edfd6fa7bde42` | `affected` |
| animationclip | `0029ad5c787e4302894c687ee9fda8dd` | `affected0` |
| animationclip | `47d02b9a7fd54d418e76cd633f8b5768` | `effect` |
| animationclip | `778b52a102f14c168b5097544e3fc011` | `end` |
| sprite | `ab8d8a7b108a4df185353df5d992a828` | `icon` |
| animationclip | `b5c8dfbb5e114d29bfebddb1735ac385` | `repeat` |
| animationclip | `06e57cc1f3144b41a51ccf90480a6d14` | `special` |

## 사용 제한

이 자료는 레이어 분리, 프레임 리듬, 외곽-중간톤-코어의 렌더링 문법, ICON/VFX 연결을 관찰하는 참고다. 캐릭터, 무기, 고유 문양, 고유 실루엣, 공격 메커니즘은 복제하지 않는다.
