# AREA 00 + MSW resource pack 관찰 기준

## 우선순위

1. 각 몬스터의 WHAT은 `AREA_MANIFEST`, `MONSTER_INFO`, `GENERATION_SPEC`, `RUNTIME_ROLE_MAP`으로 고정한다.
2. 마감 품질은 `area00_finish_baseline`의 실제 최종 PNG에서 읽는다.
3. 역할 분리와 시간 구조는 `CURRENT_NAMED_REFERENCE`와 `NAMED_STRUCTURE_REFERENCE`의 실제 팩 구성에서 읽는다.
4. `SUPPLEMENTARY_STRUCTURE_REFERENCE`는 해당 역할이 필요할 때만 쓴다.
5. `CURRENTNESS_EXCLUSIONS.md`에 있는 팩은 시각 자료를 포함하지 않으며 positive reference로 사용하지 않는다.

## 관찰할 렌더링 문법

- 어두운 유색 외곽 또는 밀도 높은 그림자가 전체 실루엣을 잡는다.
- 고유 재질을 설명하는 중간톤 면이 있고, 밝은 코어와 하이라이트가 그 위에 제한적으로 올라간다.
- bloom은 코어를 삼키지 않으며, 가장자리 알파가 갑자기 끊기거나 흰 테두리로 굳지 않는다.
- 파편은 크기와 방향에 위계가 있고, 절정 뒤에는 감속·분해·fade로 사라진다.
- 모든 프레임을 같은 광량으로 채우지 않는다. 준비→성장→절정→해체→fade가 형태 변화로 읽혀야 한다.
- 포스터 배경, 캐릭터 전신, 장면 조명, UI 프레임 없이 단독 게임 VFX 자산으로 읽혀야 한다.

## ICON

- 기본 납품은 256x256 RGBA 1장이다. 런타임 명세가 요구하지 않는 disabled/mouseover 상태는 만들지 않는다.
- VFX의 핵심 명사 하나와 보조 움직임 하나를 같은 색·재질 언어로 압축한다.
- 64px 축소에서도 외곽과 코어가 분리되어야 한다.
