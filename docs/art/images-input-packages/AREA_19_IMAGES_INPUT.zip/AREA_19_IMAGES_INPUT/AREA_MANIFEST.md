# area_19 미래의 문 Manifest

- 처리 순서: 19
- 레벨 범위: Lv181~190
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 181 | area_19 | 미래의 문 | m_official_knight_c | 정식기사 C | da57403b50694b12bf0e19aa3a64112d | 확보 | s_mon_official_knight_c | 기사단 뇌전 연각 | 액티브 | ATK 계수 5.85로 반경 5.9 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.17초; 지속 .7/.78초 | N | monsters/001_m_official_knight_c_정식기사_C |
| 2 | 183 | area_19 | 미래의 문 | m_official_knight_d | 정식기사 D | 1b11119e13474135882191d052342552 | 확보 | s_mon_official_knight_d | 기사단의 바람 조준 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_official_knight_d_정식기사_D |
| 3 | 185 | area_19 | 미래의 문 | m_advanced_knight_a | 상급기사 A | b2ab0d2ec4d346079c5738c79c8b909b | 확보 | s_mon_advanced_knight_a | 그림자 기사의 민첩 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_advanced_knight_a_상급기사_A |
| 4 | 188 | area_19 | 미래의 문 | m_advanced_knight_b | 상급기사 B | 3a107a08957f442d8b3e191258198056 | 확보 | s_mon_advanced_knight_b | 상급기사의 이프리트 화염 | 액티브 | INT 계수 6.05로 반경 6.2 범위 최대 4대상 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.2초; 지속 .78/.88초 | N | monsters/004_m_advanced_knight_b_상급기사_B |
| 5 | 190 | area_19 | 미래의 문 | m_cygnus | 시그너스 | 397136593bdb4e37b17d0d9e40ce0006 | 확보 | s_mon_cygnus | 타락한 여제의 정원 | 액티브 | INT 계수 6.35로 반경 7.4 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.28초; 지속 .9/1.02초 | Y | monsters/005_m_cygnus_시그너스 |
