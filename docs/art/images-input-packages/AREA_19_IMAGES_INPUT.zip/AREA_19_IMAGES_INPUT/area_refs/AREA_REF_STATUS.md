# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t68/future`
- 합성 대상: 00_fallen_stone.png, 01_knight_court.png, 02_dark_ereve_sigil.png, 03_dream_void.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
