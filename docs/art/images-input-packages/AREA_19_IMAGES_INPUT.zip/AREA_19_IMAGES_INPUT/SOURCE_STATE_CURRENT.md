# Input source state

- rebuild run: `20260913_153134`
- base canonical package: `docs/art/images-input-packages/AREA_19_IMAGES_INPUT.zip`
- base package SHA-256: `3efc27df63567cff3f2a66baa15e685fe1907af16beba9da0ec9f4a693535404`
- manifest/monster documents and MONSTER_IMAGE files were preserved from that canonical package, except for the appended reference assignment in GENERATION_SPEC.
- game data was not modified.
- AREA 06 is intentionally retired in the current project design, so operational Area ids are 00~05 and 07~20.
- resource search capture and AREA 00 baseline provenance are inside `global_skill_style_library`.
