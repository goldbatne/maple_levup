# Output Format Spec

- VFX의 주 납품물은 frame-separated RGBA PNG다. contact sheet는 preview일 뿐 개별 프레임을 대체하지 않는다.
- 모든 VFX 프레임은 GENERATION_SPEC의 canvas, frame count, timing을 따른다.
- 같은 스킬의 모든 프레임은 동일 canvas/pivot/기준축/스케일을 유지한다.
- 실제 alpha 배경이어야 하며 흰색·검정색·체커보드 matte를 넣지 않는다.
- 주요 형상 70%, 외곽 파편/발광 85% 안전영역을 지킨다.
- ICON은 256x256 RGBA 기본 상태 1장이다.
- PNG 안에 텍스트, 번호, UI 프레임, 워터마크, 몬스터 본체를 넣지 않는다.
