# Prepared reference boards

각 스킬 생성 호출에 전달할 공식 VFX 보드와 승인 AREA00 마감 보드다. 보드는 실제 원본의 전달용 합성물이며 출력물이 아니다. BOARD_MANIFEST.json에 원본 경로·SHA-256·타일 위치가 있다.
