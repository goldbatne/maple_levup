# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 정식기사 C / 기사단 뇌전 연각: [monsters/001_m_official_knight_c_정식기사_C/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_official_knight_c_정식기사_C/DESIGN_REFERENCE_BRIEF.md) — lightning, punch
- 정식기사 D / 기사단의 바람 조준: [monsters/002_m_official_knight_d_정식기사_D/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_official_knight_d_정식기사_D/DESIGN_REFERENCE_BRIEF.md) — gale, earth_breath
- 상급기사 A / 그림자 기사의 민첩: [monsters/003_m_advanced_knight_a_상급기사_A/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_advanced_knight_a_상급기사_A/DESIGN_REFERENCE_BRIEF.md) — dark_magic, needle
- 상급기사 B / 상급기사의 이프리트 화염: [monsters/004_m_advanced_knight_b_상급기사_B/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_advanced_knight_b_상급기사_B/DESIGN_REFERENCE_BRIEF.md) — fire, dragon_fire
- 시그너스 / 타락한 여제의 정원: [monsters/005_m_cygnus_시그너스/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_cygnus_시그너스/DESIGN_REFERENCE_BRIEF.md) — gale, dark_magic