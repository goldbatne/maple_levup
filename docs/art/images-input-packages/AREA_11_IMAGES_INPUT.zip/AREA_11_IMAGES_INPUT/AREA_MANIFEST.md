# area_11 루더스 호수 Manifest

- 처리 순서: 11
- 레벨 범위: Lv101~110
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 101 | area_11 | 루더스 호수 | m_ratz | 라츠 | 383e34f2a8584a96a01b80a8fadbb813 | 확보 | s_mon_ratz | 태엽쥐의 민첩 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_ratz_라츠 |
| 2 | 103 | area_11 | 루더스 호수 | m_drumming_bunny | 북치는 토끼 | 20283346c1db42b593fdddb218ea769a | 확보 | s_mon_drumming_bunny | 태엽 북진동 | 액티브 | INT 계수 3.35로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.75초 | N | monsters/002_m_drumming_bunny_북치는_토끼 |
| 3 | 105 | area_11 | 루더스 호수 | m_bloctopus | 블록퍼스 | 826410e1bd4e4a12a612ab642c19c705 | 확보 | s_mon_bloctopus | 블록 위장 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_bloctopus_블록퍼스 |
| 4 | 108 | area_11 | 루더스 호수 | m_king_bloctopus | 킹 블록퍼스 | cb5eb9faaf68477292af0b710e383c9d | 확보 | s_mon_king_bloctopus | 왕관 블록탄 | 액티브 | INT 계수 3.5로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.22초; 지속 0.65초; 투사체 a2da67e687994755a8943c2bcf871902가 목표 방향으로 이동 | N | monsters/004_m_king_bloctopus_킹_블록퍼스 |
| 5 | 110 | area_11 | 루더스 호수 | m_rombot | 롬바드 | b41def4288404055b3b8850daa99cfbf | 확보 | s_mon_rombot | 에오스 중력파 | 액티브 | ATK 계수 3.8로 반경 6 범위 대상 제한 없음 피해; 9초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.72/0.8초 | Y | monsters/005_m_rombot_롬바드 |
