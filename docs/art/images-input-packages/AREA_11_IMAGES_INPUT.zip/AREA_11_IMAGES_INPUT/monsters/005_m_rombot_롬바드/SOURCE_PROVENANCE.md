# Source provenance — 롬바드 / 에오스 중력파

- rebuild run: `20260913_153134`
- base package: `AREA_11_IMAGES_INPUT.zip`
- base package SHA-256: `9affdbddfb68a754c3fc9254be8883869b4a722ff8eaf60cf1eeed40f7ea7a92`
- preserved manifest monster image RUID: `b41def4288404055b3b8850daa99cfbf`
- preserved monster image status: `확보`
- preserved ids: `m_rombot` / `s_mon_rombot`
- preserved WHAT: `에오스 중력파` / `액티브` / `ATK 계수 3.8로 반경 6 범위 대상 제한 없음 피해; 9초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.72/0.8초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
