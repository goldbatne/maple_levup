# Monster Reference — 롬바드

- 작업 순번: 005
- level: 110
- Area: `area_11` / 루더스 호수
- monster_id: `m_rombot`
- model_id: `rombot`
- image RUID: `b41def4288404055b3b8850daa99cfbf`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_rombot`
- skill name/type: 에오스 중력파 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
