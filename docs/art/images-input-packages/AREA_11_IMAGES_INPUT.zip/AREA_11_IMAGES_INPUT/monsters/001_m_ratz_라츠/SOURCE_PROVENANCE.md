# Source provenance — 라츠 / 태엽쥐의 민첩

- rebuild run: `20260913_153134`
- base package: `AREA_11_IMAGES_INPUT.zip`
- base package SHA-256: `9affdbddfb68a754c3fc9254be8883869b4a722ff8eaf60cf1eeed40f7ea7a92`
- preserved manifest monster image RUID: `383e34f2a8584a96a01b80a8fadbb813`
- preserved monster image status: `확보`
- preserved ids: `m_ratz` / `s_mon_ratz`
- preserved WHAT: `태엽쥐의 민첩` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
