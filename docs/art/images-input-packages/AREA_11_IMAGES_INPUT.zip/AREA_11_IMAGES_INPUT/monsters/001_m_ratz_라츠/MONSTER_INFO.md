# Monster Reference — 라츠

- 작업 순번: 001
- level: 101
- Area: `area_11` / 루더스 호수
- monster_id: `m_ratz`
- model_id: `ratz`
- image RUID: `383e34f2a8584a96a01b80a8fadbb813`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ratz`
- skill name/type: 태엽쥐의 민첩 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
