# Monster Reference — 킹 블록퍼스

- 작업 순번: 004
- level: 108
- Area: `area_11` / 루더스 호수
- monster_id: `m_king_bloctopus`
- model_id: `kingbloctopus`
- image RUID: `cb5eb9faaf68477292af0b710e383c9d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_king_bloctopus`
- skill name/type: 왕관 블록탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
