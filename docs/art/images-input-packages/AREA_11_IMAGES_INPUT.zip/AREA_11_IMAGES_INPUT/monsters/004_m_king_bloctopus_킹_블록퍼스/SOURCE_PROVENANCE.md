# Source provenance — 킹 블록퍼스 / 왕관 블록탄

- rebuild run: `20260913_153134`
- base package: `AREA_11_IMAGES_INPUT.zip`
- base package SHA-256: `9affdbddfb68a754c3fc9254be8883869b4a722ff8eaf60cf1eeed40f7ea7a92`
- preserved manifest monster image RUID: `cb5eb9faaf68477292af0b710e383c9d`
- preserved monster image status: `확보`
- preserved ids: `m_king_bloctopus` / `s_mon_king_bloctopus`
- preserved WHAT: `왕관 블록탄` / `액티브` / `INT 계수 3.5로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.22초; 지속 0.65초; 투사체 a2da67e687994755a8943c2bcf871902가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
