# Source provenance — 블록퍼스 / 블록 위장

- rebuild run: `20260913_153134`
- base package: `AREA_11_IMAGES_INPUT.zip`
- base package SHA-256: `9affdbddfb68a754c3fc9254be8883869b4a722ff8eaf60cf1eeed40f7ea7a92`
- preserved manifest monster image RUID: `826410e1bd4e4a12a612ab642c19c705`
- preserved monster image status: `확보`
- preserved ids: `m_bloctopus` / `s_mon_bloctopus`
- preserved WHAT: `블록 위장` / `패시브` / `보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
