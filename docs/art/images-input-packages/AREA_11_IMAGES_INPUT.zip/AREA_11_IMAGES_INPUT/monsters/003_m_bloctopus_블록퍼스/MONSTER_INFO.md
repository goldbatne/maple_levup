# Monster Reference — 블록퍼스

- 작업 순번: 003
- level: 105
- Area: `area_11` / 루더스 호수
- monster_id: `m_bloctopus`
- model_id: `bloctopus`
- image RUID: `826410e1bd4e4a12a612ab642c19c705`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_bloctopus`
- skill name/type: 블록 위장 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
