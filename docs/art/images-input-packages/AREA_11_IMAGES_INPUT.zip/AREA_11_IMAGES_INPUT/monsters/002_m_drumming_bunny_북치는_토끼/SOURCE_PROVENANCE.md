# Source provenance — 북치는 토끼 / 태엽 북진동

- rebuild run: `20260913_153134`
- base package: `AREA_11_IMAGES_INPUT.zip`
- base package SHA-256: `9affdbddfb68a754c3fc9254be8883869b4a722ff8eaf60cf1eeed40f7ea7a92`
- preserved manifest monster image RUID: `20283346c1db42b593fdddb218ea769a`
- preserved monster image status: `확보`
- preserved ids: `m_drumming_bunny` / `s_mon_drumming_bunny`
- preserved WHAT: `태엽 북진동` / `액티브` / `INT 계수 3.35로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.75초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
