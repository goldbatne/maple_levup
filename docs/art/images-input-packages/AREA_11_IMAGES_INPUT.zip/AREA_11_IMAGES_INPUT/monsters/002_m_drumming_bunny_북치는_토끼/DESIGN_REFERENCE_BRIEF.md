# 북치는 토끼 — 태엽 북진동: 실제 디자인 참조

monster_id: `m_drumming_bunny` / skill_id: `s_mon_drumming_bunny` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 장난감 북면에서 퍼지는 둥근 진동륜과 태엽 별조각. ‘북치는 토끼 / 태엽 북진동’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 북 적색 #C9574C; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 장난감 금색 #E9C75C; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘북면’, 보조 효과 1개는 ‘동심 진동륜’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/002_m_drumming_bunny_북치는_토끼/MONSTER_IMAGE.png`

RUID: `20283346c1db42b593fdddb218ea769a` / SHA-256: `8770bf2d36078acf9b76d232c65139424a5c5abfe52a4c953f1f5d7ff5afff00`

## 이 스킬에 적용할 구체적인 디자인
북판의 둥근 진동과 태엽 별이 순차적으로 퍼진다. 음표나 시계판 대신 북 진동의 두께와 간격을 읽히게 한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 소울 레조넌스 / 소울 레조넌스 강화 / `skill/40000.img/skill/400004438`
- 관찰한 표현: 얇은 진동띠가 겹치고 마지막 잔광이 단계적으로 빠지는 흐름
- 가져오지 않을 요소: 음표와 주변 돌 조각을 목표에 추가하지 않는다
- end: `reference_resource_design/sound/source/3516dd54a83647ce9669e5b55fdf3c0c.gif` / SHA-256 `3aab8da968c7f3cb5118b68c384812c7c7905ab65427e355d0bff9e3b8c6efc1`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/sound/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F000.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F001.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F002.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F003.png`
  - `reference_resource_design/sound/frames/3516dd54a83647ce9669e5b55fdf3c0c_F004.png`
- keydown: `reference_resource_design/sound/source/39e950d9e0384f4984a20e06409fa0de.gif` / SHA-256 `7bcf7eec39f38a97ca32ccf22bdd9fce025c867bb89176b097e306ef2b61c9ac`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/sound/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F000.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F001.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F003.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F004.png`
  - `reference_resource_design/sound/frames/39e950d9e0384f4984a20e06409fa0de_F005.png`
- icon: `reference_resource_design/sound/source/5597d70b59a74de5947c9d9591cd3f23.png` / SHA-256 `266f4be28b1792c7132422cb6edd3a22f982e8aea07a03129ffd348c837a591e`

### 타임 피스 / `skill/10114.img/skill/101141012`
- 관찰한 표현: 시계 고리의 얇은 중간층과 밝은 순간 코어, 갈라진 시간 잔상
- 가져오지 않을 요소: 시계 숫자·원본 문양을 에셋에 넣지 않는다. 시계 아닌 기계에 시계판을 추가하지 않는다
- effect: `reference_resource_design/clock/source/d39a27be8b5f4d4795ae8df9a675ed74.gif` / SHA-256 `4750a40c7254ceeece6e16ea073d485632c98d0376285ec997a01673803a5f20`
  전체 연속 PNG 20장과 GIF 타이밍은 `reference_resource_design/clock/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F000.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F005.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F010.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F015.png`
  - `reference_resource_design/clock/frames/d39a27be8b5f4d4795ae8df9a675ed74_F019.png`
- hit/0: `reference_resource_design/clock/source/f7824277a0e140ecb1bd3a19df6f2fc5.gif` / SHA-256 `a1213533521db521d83e5051b51b86bea7c8dc494a6fb4bfb2df91527e30a8c3`
  전체 연속 PNG 7장과 GIF 타이밍은 `reference_resource_design/clock/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F000.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F001.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F003.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F005.png`
  - `reference_resource_design/clock/frames/f7824277a0e140ecb1bd3a19df6f2fc5_F006.png`
- icon: `reference_resource_design/clock/source/f92545bd29cf4ad98d02c19dba55ea3b.png` / SHA-256 `18c4344fb0889d8b2b0af9a449661fdd1fe6f0f0e4d1d58267c0f05bb173ee5b`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/002_m_drumming_bunny_북치는_토끼/MONSTER_IMAGE.png` / SHA-256 `8770bf2d36078acf9b76d232c65139424a5c5abfe52a4c953f1f5d7ff5afff00`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_drumming_bunny_OFFICIAL_VFX_BOARD.png` / SHA-256 `4728e64301c6414fc1895c26f55e7f4a54912cbfffdb5e350a6dbf8aa9e72eee`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_drumming_bunny_AREA00_FINISH_BOARD.png` / SHA-256 `f791d053029f6dd88313bc1aaa3f2c3092fbb53e9ae62a89944c0f7d0954827d`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_drumming_bunny_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
