# Monster Reference — 북치는 토끼

- 작업 순번: 002
- level: 103
- Area: `area_11` / 루더스 호수
- monster_id: `m_drumming_bunny`
- model_id: `drummingbunny`
- image RUID: `20283346c1db42b593fdddb218ea769a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_drumming_bunny`
- skill name/type: 태엽 북진동 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
