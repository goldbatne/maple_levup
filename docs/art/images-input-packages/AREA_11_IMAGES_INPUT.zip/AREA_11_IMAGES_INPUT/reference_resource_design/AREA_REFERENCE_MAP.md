# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 라츠 / 태엽쥐의 민첩: [monsters/001_m_ratz_라츠/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_ratz_라츠/DESIGN_REFERENCE_BRIEF.md) — clock, metal
- 북치는 토끼 / 태엽 북진동: [monsters/002_m_drumming_bunny_북치는_토끼/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_drumming_bunny_북치는_토끼/DESIGN_REFERENCE_BRIEF.md) — sound, clock
- 블록퍼스 / 블록 위장: [monsters/003_m_bloctopus_블록퍼스/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_bloctopus_블록퍼스/DESIGN_REFERENCE_BRIEF.md) — metal, water_shield
- 킹 블록퍼스 / 왕관 블록탄: [monsters/004_m_king_bloctopus_킹_블록퍼스/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_king_bloctopus_킹_블록퍼스/DESIGN_REFERENCE_BRIEF.md) — bubble, metal
- 롬바드 / 에오스 중력파: [monsters/005_m_rombot_롬바드/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_rombot_롬바드/DESIGN_REFERENCE_BRIEF.md) — clock, dark_barrier