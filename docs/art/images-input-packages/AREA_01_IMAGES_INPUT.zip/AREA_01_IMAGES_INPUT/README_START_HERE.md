# AREA 01 헤네시스 근교 이미지 신규 제작 — 여기서 시작

사용자는 이 `AREA_01_IMAGES_INPUT.zip`과 `AREA_01_CHATGPT_PRODUCTION_PROMPT.txt`만 첨부하고 “첨부한 프롬프트대로 실행해줘”라고 요청한다.

`CHATGPT_IMAGES_MASTER_PROMPT.md`는 외부 TXT와 같은 최종 실행 절차다. `s_mon_snail_dew_trail` 하나로 참조 입력→VFX source→프레임 추출→알파/동작 검증→ICON 파이프라인을 먼저 통과시킨다. 그 뒤 manifest 순서대로 한 스킬씩 만든다. 여러 스킬을 한 이미지에 동시에 생성하지 않는다.

각 몬스터 폴더의 `DESIGN_REFERENCE_BRIEF.md`에는 소재와 원본 참조가 있고, `reference_resource_design/prepared_boards/`에는 생성 호출에 전달할 스킬별 공식 VFX 보드와 승인 AREA00 마감 보드가 있다. BOARD_MANIFEST.json에 보드 구성 원본·SHA-256·타일 위치를 기록했다.

RUNTIME_ROLE_MAP이 ICON-only로 정한 패시브는 ICON만 제작한다. 기존 OUTPUT은 덮어쓰지 않으며 결과는 REVIEW_CANDIDATE다. 게임 RUID·AnimationClip·scale·offset은 변경하지 않는다. 다른 Area는 자동 시작하지 않는다.
