# Source provenance — 달팽이 / 이슬 미끄럼길

- rebuild run: `20260913_153134`
- base package: `AREA_01_IMAGES_INPUT.zip`
- base package SHA-256: `d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343`
- preserved manifest monster image RUID: `2db94405cf0445f5be2b60a02c21dda5`
- preserved monster image status: `확보`
- preserved ids: `m_snail` / `s_mon_snail_dew_trail`
- preserved WHAT: `이슬 미끄럼길` / `액티브` / `ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.8초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
