# Source provenance — 머쉬맘 / 머쉬맘의 포자 충격

- rebuild run: `20260913_153134`
- base package: `AREA_01_IMAGES_INPUT.zip`
- base package SHA-256: `d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343`
- preserved manifest monster image RUID: `86015373d23b4b05bb8fcc6086354652`
- preserved monster image status: `확보`
- preserved ids: `m_mushmom` / `s_mon_mushmom`
- preserved WHAT: `머쉬맘의 포자 충격` / `액티브` / `ATK 계수 1.35로 반경 4.2 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.22초; 지속 0.75/0.72/0.7초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
