# Monster Reference — 머쉬맘

- 작업 순번: 004
- level: 10
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_mushmom`
- model_id: `mushmom`
- image RUID: `86015373d23b4b05bb8fcc6086354652`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mushmom`
- skill name/type: 머쉬맘의 포자 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
