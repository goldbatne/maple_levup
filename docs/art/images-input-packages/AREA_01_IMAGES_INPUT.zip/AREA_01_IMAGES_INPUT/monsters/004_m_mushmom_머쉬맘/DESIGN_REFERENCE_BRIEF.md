# 머쉬맘 — 머쉬맘의 포자 충격: 실제 디자인 참조

monster_id: `m_mushmom` / skill_id: `s_mon_mushmom` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 굵은 포자 핵이 지면에 닿아 버섯갓 모양으로 터지는 충격. ‘머쉬맘 / 머쉬맘의 포자 충격’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 황갈 포자색 #B77A3A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 황금 충격광 #FFD66B; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘버섯갓 충격파’, 보조 효과 1개는 ‘굵은 포자 파편’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_mushmom_머쉬맘/MONSTER_IMAGE.png`

RUID: `86015373d23b4b05bb8fcc6086354652` / SHA-256: `d475d084a2630c88270472a946ceb2603b0494efd1a9eb873d2b09fa7788991b`

## 이 스킬에 적용할 구체적인 디자인
큰 포자 코어가 낮은 갓 형태로 부풀고 지면 충격 후 포자로 흩어진다. 화염 폭발이나 돌 분화구 대신 포자 덩어리 두께를 유지한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 포이즌 미스트 / `skill/214.img/skill/2141004`
- 관찰한 표현: 흐릿한 외곽 안쪽에 덩어리별 농도와 중간톤이 남는 기체 층
- 가져오지 않을 요소: 초록 독 색상과 독의 의미를 포자·먹물로 옮기지 않는다
- special: `reference_resource_design/mist/source/876042858c574e829697ce796ea71f99.gif` / SHA-256 `cea2acc7650f23f690a2b31f6e98ecb0dcbfc91267e515071f17cfddeb5b29f7`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/mist/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F000.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F002.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F004.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F006.png`
  - `reference_resource_design/mist/frames/876042858c574e829697ce796ea71f99_F007.png`
- tile: `reference_resource_design/mist/source/ae5eacd6c09c48a1b0cbaf88dc7edb50.gif` / SHA-256 `8e932ef2c8522668c97e19eea1e728db33cc7b78a977a120e085a1ad420a6142`
  전체 연속 PNG 24장과 GIF 타이밍은 `reference_resource_design/mist/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F000.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F006.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F012.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F018.png`
  - `reference_resource_design/mist/frames/ae5eacd6c09c48a1b0cbaf88dc7edb50_F023.png`
- icon: `reference_resource_design/mist/source/c6a8f199cd68461c9f0373565e857bee.png` / SHA-256 `aba0bf9069b562ed9d96d479261dfa88467832a762f76c916314f08badbcaf00`

### 어스 브레이크 VI / `skill/10114.img/skill/101141005`
- 관찰한 표현: 낮은 지면층의 균열광과 짧은 각진 충격면, 사라지는 잔진
- 가져오지 않을 요소: 주황 전기 균열을 모든 지면 재질로 사용하지 않는다
- tile: `reference_resource_design/quake/source/3b0608e170634d34a96f0f516827d7a8.gif` / SHA-256 `5e06345ec19ff6dab34ed3450933be5c07878f84aeb7ec1605fdba8e7eb44c26`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/quake/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F000.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F002.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F004.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F006.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F007.png`
- hit/0: `reference_resource_design/quake/source/a92a2168b9254a9eb29f1fe2f8ce1460.gif` / SHA-256 `d050152fd42d2a7038ef6d57f04cf916c7222bae7ef5ff55dff640a246c24dab`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/quake/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F000.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F001.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F003.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F004.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F005.png`
- icon: `reference_resource_design/quake/source/e3546d827b934bdb811649349501439f.png` / SHA-256 `5c78fd7e65cd2388f9208f0aa77d1489ac413f02b8f1234f2bacce3c6f062a49`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`
- `global_skill_style_library/area00_finish_baseline/icons/004_m_mano_s_mon_mano_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F07.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F08.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F09.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F10.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/004_m_mano_마노/004_m_mano_s_mon_mano_F11.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_mushmom_머쉬맘/MONSTER_IMAGE.png` / SHA-256 `d475d084a2630c88270472a946ceb2603b0494efd1a9eb873d2b09fa7788991b`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_mushmom_OFFICIAL_VFX_BOARD.png` / SHA-256 `73960bf4b9afa19c3b16e31a0c266ad7db54a6a3d015d2ebd1da57d7dd5090a4`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_mushmom_AREA00_FINISH_BOARD.png` / SHA-256 `20fbbca37b8a850575823b2514d5d8072b3a94290ccf40a713488329a45d9446`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_mushmom_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
