# Source provenance — 파란 달팽이 / 푸른 껍질

- rebuild run: `20260913_153134`
- base package: `AREA_01_IMAGES_INPUT.zip`
- base package SHA-256: `d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343`
- preserved manifest monster image RUID: `0c69164656d24f64bd1a1f6ee4019dff`
- preserved monster image status: `확보`
- preserved ids: `m_blue_snail` / `s_mon_blue_snail`
- preserved WHAT: `푸른 껍질` / `버프` / `자신에게 3초 동안 피해 40% 감소` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.85/0.7초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
