# Monster Reference — 주황 버섯

- 작업 순번: 003
- level: 5
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_mushroom`
- model_id: `mushroom`
- image RUID: `a95cfed2c8fe4d2cb64cbb62db051f92`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mushroom`
- skill name/type: 포자 살포 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
