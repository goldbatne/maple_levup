# Source provenance — 주황 버섯 / 포자 살포

- rebuild run: `20260913_153134`
- base package: `AREA_01_IMAGES_INPUT.zip`
- base package SHA-256: `d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343`
- preserved manifest monster image RUID: `a95cfed2c8fe4d2cb64cbb62db051f92`
- preserved monster image status: `확보`
- preserved ids: `m_mushroom` / `s_mon_mushroom`
- preserved WHAT: `포자 살포` / `액티브` / `INT 계수 1.1로 반경 2.5 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.08/0.16초; 지속 0.55/0.6/0.65초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
