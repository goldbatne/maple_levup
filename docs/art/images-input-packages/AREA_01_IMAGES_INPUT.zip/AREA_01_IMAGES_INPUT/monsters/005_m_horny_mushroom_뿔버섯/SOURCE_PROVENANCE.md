# Source provenance — 뿔버섯 / 단단한 뿔

- rebuild run: `20260913_153134`
- base package: `AREA_01_IMAGES_INPUT.zip`
- base package SHA-256: `d7b6cdf322ca2aff0b2bf9163826641a4c5c1a4ae8d8fc9b31b386a928aa1343`
- preserved manifest monster image RUID: `574596d79f004965a293d2551343633f`
- preserved monster image status: `확보`
- preserved ids: `m_horny_mushroom` / `s_mon_horny_mushroom`
- preserved WHAT: `단단한 뿔` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
