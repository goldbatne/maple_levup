# Monster Reference — 뿔버섯

- 작업 순번: 005
- level: 12
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_horny_mushroom`
- model_id: `hornymushroom`
- image RUID: `574596d79f004965a293d2551343633f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_horny_mushroom`
- skill name/type: 단단한 뿔 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
