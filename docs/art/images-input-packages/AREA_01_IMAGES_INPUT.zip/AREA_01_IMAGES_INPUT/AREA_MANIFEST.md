# area_01 헤네시스 근교 Manifest

- 처리 순서: 2
- 레벨 범위: Lv1~12
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | area_01 | 헤네시스 근교 | m_snail | 달팽이 | 2db94405cf0445f5be2b60a02c21dda5 | 확보 | s_mon_snail_dew_trail | 이슬 미끄럼길 | 액티브 | ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.8초 | N | monsters/001_m_snail_달팽이 |
| 2 | 3 | area_01 | 헤네시스 근교 | m_blue_snail | 파란 달팽이 | 0c69164656d24f64bd1a1f6ee4019dff | 확보 | s_mon_blue_snail | 푸른 껍질 | 버프 | 자신에게 3초 동안 피해 40% 감소 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.85/0.7초 | N | monsters/002_m_blue_snail_파란_달팽이 |
| 3 | 5 | area_01 | 헤네시스 근교 | m_mushroom | 주황 버섯 | a95cfed2c8fe4d2cb64cbb62db051f92 | 확보 | s_mon_mushroom | 포자 살포 | 액티브 | INT 계수 1.1로 반경 2.5 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.08/0.16초; 지속 0.55/0.6/0.65초 | N | monsters/003_m_mushroom_주황_버섯 |
| 4 | 10 | area_01 | 헤네시스 근교 | m_mushmom | 머쉬맘 | 86015373d23b4b05bb8fcc6086354652 | 확보 | s_mon_mushmom | 머쉬맘의 포자 충격 | 액티브 | ATK 계수 1.35로 반경 4.2 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.22초; 지속 0.75/0.72/0.7초 | Y | monsters/004_m_mushmom_머쉬맘 |
| 5 | 12 | area_01 | 헤네시스 근교 | m_horny_mushroom | 뿔버섯 | 574596d79f004965a293d2551343633f | 확보 | s_mon_horny_mushroom | 단단한 뿔 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/005_m_horny_mushroom_뿔버섯 |
