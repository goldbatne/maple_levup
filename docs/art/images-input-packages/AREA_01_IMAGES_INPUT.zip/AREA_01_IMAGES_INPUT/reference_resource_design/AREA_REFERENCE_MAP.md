# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 달팽이 / 이슬 미끄럼길: [monsters/001_m_snail_달팽이/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_snail_달팽이/DESIGN_REFERENCE_BRIEF.md) — water, water_shield
- 파란 달팽이 / 푸른 껍질: [monsters/002_m_blue_snail_파란_달팽이/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_blue_snail_파란_달팽이/DESIGN_REFERENCE_BRIEF.md) — water_shield, metal
- 주황 버섯 / 포자 살포: [monsters/003_m_mushroom_주황_버섯/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_mushroom_주황_버섯/DESIGN_REFERENCE_BRIEF.md) — mist, nature
- 머쉬맘 / 머쉬맘의 포자 충격: [monsters/004_m_mushmom_머쉬맘/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_mushmom_머쉬맘/DESIGN_REFERENCE_BRIEF.md) — mist, quake
- 뿔버섯 / 단단한 뿔: [monsters/005_m_horny_mushroom_뿔버섯/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_horny_mushroom_뿔버섯/DESIGN_REFERENCE_BRIEF.md) — metal, needle