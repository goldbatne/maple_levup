# Source provenance — 추억의 사제 / 추억의 묵상

- rebuild run: `20260913_153134`
- base package: `AREA_17_IMAGES_INPUT.zip`
- base package SHA-256: `dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee`
- preserved manifest monster image RUID: `36ff7a667243465caef855b4fb7b9f84`
- preserved monster image status: `확보`
- preserved ids: `m_memory_monk` / `s_mon_memory_monk`
- preserved WHAT: `추억의 묵상` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
