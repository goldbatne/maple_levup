# Monster Reference — 추억의 수호대장

- 작업 순번: 004
- level: 168
- Area: `area_17` / 시간의 신전
- monster_id: `m_chief_memory_guardian`
- model_id: `chiefmemoryguardian`
- image RUID: `de30bc44af34409eb14d46100dc4e48e`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_chief_memory_guardian`
- skill name/type: 시간 수호진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
