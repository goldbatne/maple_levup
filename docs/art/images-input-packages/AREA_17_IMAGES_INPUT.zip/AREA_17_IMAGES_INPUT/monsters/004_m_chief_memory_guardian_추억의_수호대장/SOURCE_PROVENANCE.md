# Source provenance — 추억의 수호대장 / 시간 수호진

- rebuild run: `20260913_153134`
- base package: `AREA_17_IMAGES_INPUT.zip`
- base package SHA-256: `dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee`
- preserved manifest monster image RUID: `de30bc44af34409eb14d46100dc4e48e`
- preserved monster image status: `확보`
- preserved ids: `m_chief_memory_guardian` / `s_mon_chief_memory_guardian`
- preserved WHAT: `시간 수호진` / `액티브` / `STR 계수 5.2로 반경 5.9 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.22초; 지속 .74/.86초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
