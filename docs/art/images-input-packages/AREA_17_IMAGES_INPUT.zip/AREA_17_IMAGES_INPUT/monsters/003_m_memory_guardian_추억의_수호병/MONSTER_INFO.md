# Monster Reference — 추억의 수호병

- 작업 순번: 003
- level: 165
- Area: `area_17` / 시간의 신전
- monster_id: `m_memory_guardian`
- model_id: `memoryguardian`
- image RUID: `0b258556de2e401e97014ae48fe96b7a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_memory_guardian`
- skill name/type: 수호병의 기억갑주 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
