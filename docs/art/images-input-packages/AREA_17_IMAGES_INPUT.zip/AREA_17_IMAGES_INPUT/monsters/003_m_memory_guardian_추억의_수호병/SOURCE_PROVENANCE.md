# Source provenance — 추억의 수호병 / 수호병의 기억갑주

- rebuild run: `20260913_153134`
- base package: `AREA_17_IMAGES_INPUT.zip`
- base package SHA-256: `dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee`
- preserved manifest monster image RUID: `0b258556de2e401e97014ae48fe96b7a`
- preserved monster image status: `확보`
- preserved ids: `m_memory_guardian` / `s_mon_memory_guardian`
- preserved WHAT: `수호병의 기억갑주` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
