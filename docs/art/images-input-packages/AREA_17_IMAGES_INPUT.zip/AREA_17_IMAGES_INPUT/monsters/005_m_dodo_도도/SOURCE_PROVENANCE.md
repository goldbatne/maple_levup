# Source provenance — 도도 / 기억 포식

- rebuild run: `20260913_153134`
- base package: `AREA_17_IMAGES_INPUT.zip`
- base package SHA-256: `dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee`
- preserved manifest monster image RUID: `2d63f90f9d464f7192713ad9209e9e63`
- preserved monster image status: `확보`
- preserved ids: `m_dodo` / `s_mon_dodo`
- preserved WHAT: `기억 포식` / `액티브` / `INT 계수 5.45로 반경 7 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.22초; 지속 .8/.92초; 투사체 72e16f10f6ec4cf0a1fe3146e73f0856가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
