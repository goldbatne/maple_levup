# Monster Reference — 도도

- 작업 순번: 005
- level: 170
- Area: `area_17` / 시간의 신전
- monster_id: `m_dodo`
- model_id: `dodo`
- image RUID: `2d63f90f9d464f7192713ad9209e9e63`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dodo`
- skill name/type: 기억 포식 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
