# Monster Reference — 추억의 신관

- 작업 순번: 002
- level: 163
- Area: `area_17` / 시간의 신전
- monster_id: `m_memory_monk_trainee`
- model_id: `memorymonktrainee`
- image RUID: `699e78db5d3a48578388d33dc333258a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_memory_monk_trainee`
- skill name/type: 추억의 기도파 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
