# 추억의 신관 — 추억의 기도파: 실제 디자인 참조

monster_id: `m_memory_monk_trainee` / skill_id: `s_mon_memory_monk_trainee` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 작은 기도 구슬이 모여 앞으로 번지는 파동. ‘추억의 신관 / 추억의 기도파’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 기도 청백 #AFCFD4; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 추억 금갈 #C3A46A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘기도 구슬’, 보조 효과 1개는 ‘전방 잔파’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/002_m_memory_monk_trainee_추억의_신관/MONSTER_IMAGE.png`

RUID: `699e78db5d3a48578388d33dc333258a` / SHA-256: `0d4ad6317b9fdb870ca9d9ce473431b3b9200e018cc8ccf837ffdc831016febe`

## 이 스킬에 적용할 구체적인 디자인
기도 구슬이 모인 뒤 전방 파동으로 열린다. 별 구체 하나로 고정하지 않고 구슬의 모임과 분산을 읽히게 한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 소울 시커 VI / `skill/6514.img/skill/65141001`
- 관찰한 표현: 밝은 별 코어와 두께가 다른 곡선 층, 마지막 조각의 분산
- 가져오지 않을 요소: 원본 초승달 탄 모양과 분홍 팔레트는 고정 명세를 덮어쓰지 않는다
- effect: `reference_resource_design/star/source/1f5354b4660f462dbbaadfeb18f20eed.gif` / SHA-256 `434f4eb01b7ec18be909d33f0f8779b5c964762dc7578f91b690a9da5dc22d32`
  전체 연속 PNG 12장과 GIF 타이밍은 `reference_resource_design/star/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/star/frames/1f5354b4660f462dbbaadfeb18f20eed_F000.png`
  - `reference_resource_design/star/frames/1f5354b4660f462dbbaadfeb18f20eed_F003.png`
  - `reference_resource_design/star/frames/1f5354b4660f462dbbaadfeb18f20eed_F006.png`
  - `reference_resource_design/star/frames/1f5354b4660f462dbbaadfeb18f20eed_F009.png`
  - `reference_resource_design/star/frames/1f5354b4660f462dbbaadfeb18f20eed_F011.png`
- effect1: `reference_resource_design/star/source/d86e56aed5d041ab8210ed9750103d74.gif` / SHA-256 `f8bbcbe9fcb57dc5068391d2765d7731943db6d773b74002cef7e1402d33fe27`
  전체 연속 PNG 14장과 GIF 타이밍은 `reference_resource_design/star/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/star/frames/d86e56aed5d041ab8210ed9750103d74_F000.png`
  - `reference_resource_design/star/frames/d86e56aed5d041ab8210ed9750103d74_F003.png`
  - `reference_resource_design/star/frames/d86e56aed5d041ab8210ed9750103d74_F007.png`
  - `reference_resource_design/star/frames/d86e56aed5d041ab8210ed9750103d74_F010.png`
  - `reference_resource_design/star/frames/d86e56aed5d041ab8210ed9750103d74_F013.png`
- icon: `reference_resource_design/star/source/7fa3bf35d3de48569b1a20e8f1540192.png` / SHA-256 `f2f8dea604d424b3a455c61d64d063caf1632fada2af7b51beb8dd005b41d06b`

### 정기 뿌리기 / 정기 뿌리기 강화 / `skill/16212.img/skill/162121021`
- 관찰한 표현: 작은 입자군이 코어 주위에서 퍼져 농도와 광량을 함께 잃는 전개
- 가져오지 않을 요소: 꽃별 문양과 연두 팔레트를 강제하지 않는다
- effect: `reference_resource_design/nature/source/15fb0e791d5843108b230b3216ff0764.gif` / SHA-256 `1bf89cbd617c689cb874dd98241eb5d7734293758efd7ddadd3680a5255000f2`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F000.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F002.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F005.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F007.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F009.png`
- hit/0: `reference_resource_design/nature/source/04c96fc0062c418682c8075beb003a0c.gif` / SHA-256 `2d769417bd428c55eedb33fd8f565fadcd185bbc2a11b0eb32a3e93d211ef4ac`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F000.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F002.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F005.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F007.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F009.png`
- icon: `reference_resource_design/nature/source/c9fac8505f8c4efc9b9864dc540d038f.png` / SHA-256 `ce30ebdc7957924300b5798b16992e9816a96d8769b13bac9b439a056a68d0ae`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/002_m_memory_monk_trainee_추억의_신관/MONSTER_IMAGE.png` / SHA-256 `0d4ad6317b9fdb870ca9d9ce473431b3b9200e018cc8ccf837ffdc831016febe`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_memory_monk_trainee_OFFICIAL_VFX_BOARD.png` / SHA-256 `99bab9f9f396b1369b2264989af3c0da1d3412bad1ad8856ba4ea4bff6e16f59`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_memory_monk_trainee_AREA00_FINISH_BOARD.png` / SHA-256 `2ada257dc1998dcd157c1098ef49e297b07e827382fe5c2d402b32f143f4e1dc`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_memory_monk_trainee_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
