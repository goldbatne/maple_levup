# Source provenance — 추억의 신관 / 추억의 기도파

- rebuild run: `20260913_153134`
- base package: `AREA_17_IMAGES_INPUT.zip`
- base package SHA-256: `dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee`
- preserved manifest monster image RUID: `699e78db5d3a48578388d33dc333258a`
- preserved monster image status: `확보`
- preserved ids: `m_memory_monk_trainee` / `s_mon_memory_monk_trainee`
- preserved WHAT: `추억의 기도파` / `액티브` / `INT 계수 5.05로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 .72/.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
