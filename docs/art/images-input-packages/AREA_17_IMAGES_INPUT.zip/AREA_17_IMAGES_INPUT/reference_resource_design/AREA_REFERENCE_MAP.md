# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 추억의 사제 / 추억의 묵상: [monsters/001_m_memory_monk_추억의_사제/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_memory_monk_추억의_사제/DESIGN_REFERENCE_BRIEF.md) — clock, nature
- 추억의 신관 / 추억의 기도파: [monsters/002_m_memory_monk_trainee_추억의_신관/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_memory_monk_trainee_추억의_신관/DESIGN_REFERENCE_BRIEF.md) — star, nature
- 추억의 수호병 / 수호병의 기억갑주: [monsters/003_m_memory_guardian_추억의_수호병/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_memory_guardian_추억의_수호병/DESIGN_REFERENCE_BRIEF.md) — metal, earth
- 추억의 수호대장 / 시간 수호진: [monsters/004_m_chief_memory_guardian_추억의_수호대장/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_chief_memory_guardian_추억의_수호대장/DESIGN_REFERENCE_BRIEF.md) — metal, clock
- 도도 / 기억 포식: [monsters/005_m_dodo_도도/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_dodo_도도/DESIGN_REFERENCE_BRIEF.md) — dark_magic, clock