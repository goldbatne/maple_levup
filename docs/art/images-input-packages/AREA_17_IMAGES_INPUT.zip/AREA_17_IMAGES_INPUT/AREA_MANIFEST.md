# area_17 시간의 신전 Manifest

- 처리 순서: 17
- 레벨 범위: Lv161~170
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 161 | area_17 | 시간의 신전 | m_memory_monk | 추억의 사제 | 36ff7a667243465caef855b4fb7b9f84 | 확보 | s_mon_memory_monk | 추억의 묵상 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_memory_monk_추억의_사제 |
| 2 | 163 | area_17 | 시간의 신전 | m_memory_monk_trainee | 추억의 신관 | 699e78db5d3a48578388d33dc333258a | 확보 | s_mon_memory_monk_trainee | 추억의 기도파 | 액티브 | INT 계수 5.05로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 .72/.82초 | N | monsters/002_m_memory_monk_trainee_추억의_신관 |
| 3 | 165 | area_17 | 시간의 신전 | m_memory_guardian | 추억의 수호병 | 0b258556de2e401e97014ae48fe96b7a | 확보 | s_mon_memory_guardian | 수호병의 기억갑주 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_memory_guardian_추억의_수호병 |
| 4 | 168 | area_17 | 시간의 신전 | m_chief_memory_guardian | 추억의 수호대장 | de30bc44af34409eb14d46100dc4e48e | 확보 | s_mon_chief_memory_guardian | 시간 수호진 | 액티브 | STR 계수 5.2로 반경 5.9 범위 최대 4대상 피해; 9초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.22초; 지속 .74/.86초 | N | monsters/004_m_chief_memory_guardian_추억의_수호대장 |
| 5 | 170 | area_17 | 시간의 신전 | m_dodo | 도도 | 2d63f90f9d464f7192713ad9209e9e63 | 확보 | s_mon_dodo | 기억 포식 | 액티브 | INT 계수 5.45로 반경 7 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.22초; 지속 .8/.92초; 투사체 72e16f10f6ec4cf0a1fe3146e73f0856가 목표 방향으로 이동 | Y | monsters/005_m_dodo_도도 |
