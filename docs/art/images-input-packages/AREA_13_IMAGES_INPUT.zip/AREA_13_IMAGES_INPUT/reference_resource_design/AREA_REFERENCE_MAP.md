# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 흰 모래토끼 / 사막 굴착탄: [monsters/001_m_white_sand_rabbit_흰_모래토끼/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_white_sand_rabbit_흰_모래토끼/DESIGN_REFERENCE_BRIEF.md) — sand, bubble
- 목도리 프릴드 / 목도리의 사막감각: [monsters/002_m_scarf_plead_목도리_프릴드/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_scarf_plead_목도리_프릴드/DESIGN_REFERENCE_BRIEF.md) — gale, sand
- 미요캐츠 / 미요캐츠의 모래매복: [monsters/003_m_meercat_미요캐츠/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_meercat_미요캐츠/DESIGN_REFERENCE_BRIEF.md) — earth, sand
- 모래난쟁이 / 사막 대장장이의 체력: [monsters/004_m_sand_dwarf_모래난쟁이/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_sand_dwarf_모래난쟁이/DESIGN_REFERENCE_BRIEF.md) — metal, nature
- 데우 / 잠든 선인장의 폭발: [monsters/005_m_deo_데우/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_deo_데우/DESIGN_REFERENCE_BRIEF.md) — sand, needle