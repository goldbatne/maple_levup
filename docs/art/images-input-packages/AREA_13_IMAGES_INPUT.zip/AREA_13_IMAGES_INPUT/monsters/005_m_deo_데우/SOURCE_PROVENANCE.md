# Source provenance — 데우 / 잠든 선인장의 폭발

- rebuild run: `20260913_153134`
- base package: `AREA_13_IMAGES_INPUT.zip`
- base package SHA-256: `f7cde9ce9fad34bf843d0cdab5db0e0c38a807c2a55eda1981ef50734d70639c`
- preserved manifest monster image RUID: `6cf930e280f44694a0a0feedbfd855ed`
- preserved monster image status: `확보`
- preserved ids: `m_deo` / `s_mon_deo`
- preserved WHAT: `잠든 선인장의 폭발` / `액티브` / `INT 계수 4.25로 반경 6.4 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.78/0.9초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
