# 데우 — 잠든 선인장의 폭발: 실제 디자인 참조

monster_id: `m_deo` / skill_id: `s_mon_deo` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 선인장 가시가 원형으로 벌어지며 모래와 함께 폭발. ‘데우 / 잠든 선인장의 폭발’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 선인장 녹색 #568C4C; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 사막 황금 #D9B45E; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘선인장 가시핵’, 보조 효과 1개는 ‘모래 폭발’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/005_m_deo_데우/MONSTER_IMAGE.png`

RUID: `6cf930e280f44694a0a0feedbfd855ed` / SHA-256: `59364a49d85bab71c05e8c69428a8f5041f776803605c21a7728645eaecb459c`

## 이 스킬에 적용할 구체적인 디자인
선인장 가시가 방사형으로 터지며 모래가 뒤따른다. 굵은 삼각 참격이나 회오리 한 개로 만들지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 헥스 : 샌드스톰 / `skill/15414.img/skill/154141500`
- 관찰한 표현: 모래의 겹친 띠와 농도 차, 큰 흐름 뒤에 남는 가벼운 먼지
- 가져오지 않을 요소: 모든 모래 스킬을 원통형 회오리로 바꾸지 않는다
- keydown: `reference_resource_design/sand/source/28c33a05afb04953a8b3527b9a374382.gif` / SHA-256 `3484d74f501ee8a131836b0220cd82034393fe4d3300a3cbdeace21e6ca68bcb`
  전체 연속 PNG 14장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F000.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F003.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F007.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F010.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F013.png`
- keydownend: `reference_resource_design/sand/source/b97b5eda839440c3921f38656ef77649.gif` / SHA-256 `e403595b5a984595cbe0b31bdd7c654ba8d86ddf295534863f52243b27b92cf6`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F000.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F001.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F002.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F003.png`
- icon: `reference_resource_design/sand/source/7e6eda520af54b87bc552712f3804ea6.png` / SHA-256 `b9d5c6b9e4f3da2aee959eb87c464998986d8dc03f78e1b6432b098902cd5de4`

### [처형] 포이즌 니들 / `skill/6312.img/skill/63121006`
- 관찰한 표현: 날카로운 유색 면과 어두운 잔상이 분리되는 짧은 절단광
- 가져오지 않을 요소: 삼각 베기 덩어리를 침·가시 자체로 복제하지 않는다
- effect/0: `reference_resource_design/needle/source/c0743765873d43bf965f0fb21af31073.png` / SHA-256 `5df66e15e87f369baadeaba752189cee1c0d9d6e7e961536acca28ed23adcac1`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/c0743765873d43bf965f0fb21af31073_F000.png`
- effect/1: `reference_resource_design/needle/source/328ab7becdbe429dbf30664eeead7f32.png` / SHA-256 `40aca4ec90ea229d84912ec1112a38e61eb7053706c76956ce16f9490808bdc8`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/328ab7becdbe429dbf30664eeead7f32_F000.png`
- effect/2: `reference_resource_design/needle/source/65dc52b274e64a4d9eb5b46398cbed2e.png` / SHA-256 `066a9b72547d6f2ef9f1e06bfe7eafad130ba9d2ef6da2f9208cb1aa39ace329`
  전체 연속 PNG 1장과 GIF 타이밍은 `reference_resource_design/needle/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/needle/frames/65dc52b274e64a4d9eb5b46398cbed2e_F000.png`
- icon: `reference_resource_design/needle/source/c835fd4d1ab44279bc697053162911ee.png` / SHA-256 `3b93bd39a3629fb851828803e0f6078306bdb4b1c12a1f194bed5247ca789580`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/005_m_deo_데우/MONSTER_IMAGE.png` / SHA-256 `59364a49d85bab71c05e8c69428a8f5041f776803605c21a7728645eaecb459c`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_deo_OFFICIAL_VFX_BOARD.png` / SHA-256 `96ccbae6616f167d6529e760447dabe832a8aea3d775759c787f8b1e84cad213`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_deo_AREA00_FINISH_BOARD.png` / SHA-256 `24d926a6424a593bd42461f535465e3877f9980c5ecc5d8ac444ab268ec07d90`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_deo_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
