# Monster Reference — 데우

- 작업 순번: 005
- level: 130
- Area: `area_13` / 니할 사막
- monster_id: `m_deo`
- model_id: `deo`
- image RUID: `6cf930e280f44694a0a0feedbfd855ed`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_deo`
- skill name/type: 잠든 선인장의 폭발 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
