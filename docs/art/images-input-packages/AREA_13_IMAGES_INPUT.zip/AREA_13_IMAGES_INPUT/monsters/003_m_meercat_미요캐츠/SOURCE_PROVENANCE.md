# Source provenance — 미요캐츠 / 미요캐츠의 모래매복

- rebuild run: `20260913_153134`
- base package: `AREA_13_IMAGES_INPUT.zip`
- base package SHA-256: `f7cde9ce9fad34bf843d0cdab5db0e0c38a807c2a55eda1981ef50734d70639c`
- preserved manifest monster image RUID: `fc3c2944ce44425c8d7f302a8610b886`
- preserved monster image status: `확보`
- preserved ids: `m_meercat` / `s_mon_meercat`
- preserved WHAT: `미요캐츠의 모래매복` / `액티브` / `ATK 계수 3.95로 반경 4.8 범위 최대 3대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.74초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
