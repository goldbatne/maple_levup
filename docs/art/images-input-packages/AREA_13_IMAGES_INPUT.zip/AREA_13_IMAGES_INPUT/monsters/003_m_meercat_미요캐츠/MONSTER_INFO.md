# Monster Reference — 미요캐츠

- 작업 순번: 003
- level: 125
- Area: `area_13` / 니할 사막
- monster_id: `m_meercat`
- model_id: `meercat`
- image RUID: `fc3c2944ce44425c8d7f302a8610b886`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_meercat`
- skill name/type: 미요캐츠의 모래매복 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
