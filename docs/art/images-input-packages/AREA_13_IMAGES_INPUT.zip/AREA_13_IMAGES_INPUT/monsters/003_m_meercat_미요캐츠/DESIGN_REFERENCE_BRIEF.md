# 미요캐츠 — 미요캐츠의 모래매복: 실제 디자인 참조

monster_id: `m_meercat` / skill_id: `s_mon_meercat` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 모래언덕 아래 숨었다 솟는 두 갈래 매복 흔적. ‘미요캐츠 / 미요캐츠의 모래매복’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 모래 황갈 #C9A260; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 미요캣 갈색 #81604A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘솟는 모래봉’, 보조 효과 1개는 ‘숨은 눈빛’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/003_m_meercat_미요캐츠/MONSTER_IMAGE.png`

RUID: `fc3c2944ce44425c8d7f302a8610b886` / SHA-256: `a6c5101d1db03e24fce39cf19bc9ace7670b47a2e99960863a6dc69d849cd87b`

## 이 스킬에 적용할 구체적인 디자인
두 모래 매복 흔적이 지면에서 솟는 간격을 유지한다. 파란 물결이나 한 개 거대 회오리로 합치지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 토파류 : 지 VI / `skill/16414.img/skill/164141031`
- 관찰한 표현: 지면에서 큰 덩어리가 솟고 작은 조각이 뒤따르는 두께와 전개
- 가져오지 않을 요소: 파란 소용돌이 무늬를 암석·뿌리 재질로 복제하지 않는다
- effect: `reference_resource_design/earth/source/b52e4783d81c40459328d7365f877687.gif` / SHA-256 `6c51d1749b23cdb421380a5dd6f4eae7404a9b4e5e9a445884f552efcde70784`
  전체 연속 PNG 9장과 GIF 타이밍은 `reference_resource_design/earth/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F000.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F002.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F004.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F006.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F008.png`
- effect0: `reference_resource_design/earth/source/2f320471786744ae8063f9708bf088d0.gif` / SHA-256 `25deb5216ac99afdd632c412e558dbfa5e515a5bceb631a5452b65475d7584e5`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/earth/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F000.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F002.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F005.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F007.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F009.png`
- icon: `reference_resource_design/earth/source/5480e0dfc9ba46daa64230e493a4facc.png` / SHA-256 `a239ecd07d6eb0f69845bc66b6123fa5df3342ddc38faa686d909bf10b294df6`

### 헥스 : 샌드스톰 / `skill/15414.img/skill/154141500`
- 관찰한 표현: 모래의 겹친 띠와 농도 차, 큰 흐름 뒤에 남는 가벼운 먼지
- 가져오지 않을 요소: 모든 모래 스킬을 원통형 회오리로 바꾸지 않는다
- keydown: `reference_resource_design/sand/source/28c33a05afb04953a8b3527b9a374382.gif` / SHA-256 `3484d74f501ee8a131836b0220cd82034393fe4d3300a3cbdeace21e6ca68bcb`
  전체 연속 PNG 14장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F000.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F003.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F007.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F010.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F013.png`
- keydownend: `reference_resource_design/sand/source/b97b5eda839440c3921f38656ef77649.gif` / SHA-256 `e403595b5a984595cbe0b31bdd7c654ba8d86ddf295534863f52243b27b92cf6`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F000.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F001.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F002.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F003.png`
- icon: `reference_resource_design/sand/source/7e6eda520af54b87bc552712f3804ea6.png` / SHA-256 `b9d5c6b9e4f3da2aee959eb87c464998986d8dc03f78e1b6432b098902cd5de4`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/003_m_meercat_미요캐츠/MONSTER_IMAGE.png` / SHA-256 `a6c5101d1db03e24fce39cf19bc9ace7670b47a2e99960863a6dc69d849cd87b`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_meercat_OFFICIAL_VFX_BOARD.png` / SHA-256 `8391c2487b2b0cd536bc18fc8b3f729fd9e20f047eb1795a39f94c6de5c7572a`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_meercat_AREA00_FINISH_BOARD.png` / SHA-256 `085ed9bdff80a851e691cfc56d9640d9e12ce3ea631feab72de4bac32aa40e6a`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_meercat_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
