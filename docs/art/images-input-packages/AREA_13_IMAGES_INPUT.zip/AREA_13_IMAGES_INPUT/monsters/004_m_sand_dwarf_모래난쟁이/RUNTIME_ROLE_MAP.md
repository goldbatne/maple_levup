# Runtime role map — 모래난쟁이 / 사막 대장장이의 체력

- monster_id: `m_sand_dwarf`
- skill_id: `s_mon_sand_dwarf`
- skill_type: `패시브`
- required NEW_ART roles: **ICON**
- declared current motion: 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시
- role decision: 현행 패키지 선언상 런타임 VFX 없음. 패시브는 기본 ICON만 필수 NEW_ART다.
- base ICON is 256x256 RGBA. disabled/mouseover variants are not required by this INPUT.
- game scale, offset, RUID, AnimationClip settings are outside this image-production package and must not be changed.
