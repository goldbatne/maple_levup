# Source provenance — 모래난쟁이 / 사막 대장장이의 체력

- rebuild run: `20260913_153134`
- base package: `AREA_13_IMAGES_INPUT.zip`
- base package SHA-256: `f7cde9ce9fad34bf843d0cdab5db0e0c38a807c2a55eda1981ef50734d70639c`
- preserved manifest monster image RUID: `64f166fa4e5445bc982071dea297d988`
- preserved monster image status: `확보`
- preserved ids: `m_sand_dwarf` / `s_mon_sand_dwarf`
- preserved WHAT: `사막 대장장이의 체력` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
