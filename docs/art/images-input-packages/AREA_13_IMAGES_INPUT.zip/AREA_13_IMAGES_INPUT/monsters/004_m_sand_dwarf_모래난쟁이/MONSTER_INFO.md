# Monster Reference — 모래난쟁이

- 작업 순번: 004
- level: 128
- Area: `area_13` / 니할 사막
- monster_id: `m_sand_dwarf`
- model_id: `sanddwarf`
- image RUID: `64f166fa4e5445bc982071dea297d988`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_sand_dwarf`
- skill name/type: 사막 대장장이의 체력 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
