# 모래난쟁이 — 사막 대장장이의 체력: 실제 디자인 참조

monster_id: `m_sand_dwarf` / skill_id: `s_mon_sand_dwarf` / 타입: 패시브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 대장장이 망치 문양과 단단히 맺힌 붉은 체력 불씨. ‘모래난쟁이 / 사막 대장장이의 체력’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 대장간 적갈 #A94F3B; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 모래 금색 #D7B565; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘망치 문양’, 보조 효과 1개는 ‘붉은 체력핵’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_sand_dwarf_모래난쟁이/MONSTER_IMAGE.png`

RUID: `64f166fa4e5445bc982071dea297d988` / SHA-256: `32508448188d7626b9e291989084bf8fbed9ef1e81c46ebe20f5ffe6f75e3f54`

## 이 스킬에 적용할 구체적인 디자인
대장장이 망치 표식과 붉은 체력 불꽃을 ICON으로 구성한다. 왕실 방패·꽃 문양을 복제하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 로얄 가드 VI / `skill/5114.img/skill/51141002`
- 관찰한 표현: 단단한 테두리와 내부면이 분리된 방어막, 끝에서 얇아지는 광층
- 가져오지 않을 요소: 왕실 방패 모양·황금색·문장을 복제하지 않는다. 목재·솜을 금속으로 바꾸지 않는다
- effect_ple/loop: `reference_resource_design/metal/source/a98a866ed6544c7c898a6a0ff2708ac2.gif` / SHA-256 `d525df050cea5e65fdcfce58b8cdde09414bc175a705d2744de8870be742fc25`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/metal/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/metal/frames/a98a866ed6544c7c898a6a0ff2708ac2_F000.png`
  - `reference_resource_design/metal/frames/a98a866ed6544c7c898a6a0ff2708ac2_F002.png`
  - `reference_resource_design/metal/frames/a98a866ed6544c7c898a6a0ff2708ac2_F004.png`
  - `reference_resource_design/metal/frames/a98a866ed6544c7c898a6a0ff2708ac2_F006.png`
  - `reference_resource_design/metal/frames/a98a866ed6544c7c898a6a0ff2708ac2_F007.png`
- effect_ple/end: `reference_resource_design/metal/source/5044542ed02947009eff46ea1e86a5a1.gif` / SHA-256 `5c8f92c2afe9740840de2a0fc54ea9da9c13cf990cf72276d920d3dbfb58e7c2`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/metal/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/metal/frames/5044542ed02947009eff46ea1e86a5a1_F000.png`
  - `reference_resource_design/metal/frames/5044542ed02947009eff46ea1e86a5a1_F002.png`
  - `reference_resource_design/metal/frames/5044542ed02947009eff46ea1e86a5a1_F004.png`
  - `reference_resource_design/metal/frames/5044542ed02947009eff46ea1e86a5a1_F006.png`
  - `reference_resource_design/metal/frames/5044542ed02947009eff46ea1e86a5a1_F007.png`
- icon: `reference_resource_design/metal/source/8561087a14e04474be5459657eb1b3ee.png` / SHA-256 `cbebfd496310637da76a6d2915d03847a40b785e32d06843ecaa05bb1d2f0b1b`

### 정기 뿌리기 / 정기 뿌리기 강화 / `skill/16212.img/skill/162121021`
- 관찰한 표현: 작은 입자군이 코어 주위에서 퍼져 농도와 광량을 함께 잃는 전개
- 가져오지 않을 요소: 꽃별 문양과 연두 팔레트를 강제하지 않는다
- effect: `reference_resource_design/nature/source/15fb0e791d5843108b230b3216ff0764.gif` / SHA-256 `1bf89cbd617c689cb874dd98241eb5d7734293758efd7ddadd3680a5255000f2`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F000.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F002.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F005.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F007.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F009.png`
- hit/0: `reference_resource_design/nature/source/04c96fc0062c418682c8075beb003a0c.gif` / SHA-256 `2d769417bd428c55eedb33fd8f565fadcd185bbc2a11b0eb32a3e93d211ef4ac`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F000.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F002.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F005.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F007.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F009.png`
- icon: `reference_resource_design/nature/source/c9fac8505f8c4efc9b9864dc540d038f.png` / SHA-256 `ce30ebdc7957924300b5798b16992e9816a96d8769b13bac9b439a056a68d0ae`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_sand_dwarf_모래난쟁이/MONSTER_IMAGE.png` / SHA-256 `32508448188d7626b9e291989084bf8fbed9ef1e81c46ebe20f5ffe6f75e3f54`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_sand_dwarf_OFFICIAL_VFX_BOARD.png` / SHA-256 `701bd9cc6cb785b958afb1aa59d96d0439577f478b983d3a7fdda6a39c29de7f`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_sand_dwarf_AREA00_FINISH_BOARD.png` / SHA-256 `1025b15018e02c36b34a9beb4949fbd8b6a169ddddba1a787299cde7da8d1f78`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_sand_dwarf_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
