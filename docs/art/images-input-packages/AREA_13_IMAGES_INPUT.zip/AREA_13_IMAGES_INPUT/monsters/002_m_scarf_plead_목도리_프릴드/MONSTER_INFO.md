# Monster Reference — 목도리 프릴드

- 작업 순번: 002
- level: 123
- Area: `area_13` / 니할 사막
- monster_id: `m_scarf_plead`
- model_id: `scarfplead`
- image RUID: `30e7faf77c6c41d583f341c234220597`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_scarf_plead`
- skill name/type: 목도리의 사막감각 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
