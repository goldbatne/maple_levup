# 흰 모래토끼 — 사막 굴착탄: 실제 디자인 참조

monster_id: `m_white_sand_rabbit` / skill_id: `s_mon_white_sand_rabbit` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 모래를 파고 솟는 원뿔형 굴착탄과 작은 모래알. ‘흰 모래토끼 / 사막 굴착탄’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 백사장 베이지 #DCCB9A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 햇빛 황색 #F5D66D; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘모래 원뿔탄’, 보조 효과 1개는 ‘굴착 궤적’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/001_m_white_sand_rabbit_흰_모래토끼/MONSTER_IMAGE.png`

RUID: `981c64ae30bd4f98aef886e9314d8e64` / SHA-256: `de9fd37727b97e83a05143abf6a9d37404d00231217e665262fe9b03a08d893a`

## 이 스킬에 적용할 구체적인 디자인
모래 알갱이가 원뿔 굴착탄으로 모여 앞으로 나간다. 원통 회오리나 둥근 보라 구체로 대체하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 헥스 : 샌드스톰 / `skill/15414.img/skill/154141500`
- 관찰한 표현: 모래의 겹친 띠와 농도 차, 큰 흐름 뒤에 남는 가벼운 먼지
- 가져오지 않을 요소: 모든 모래 스킬을 원통형 회오리로 바꾸지 않는다
- keydown: `reference_resource_design/sand/source/28c33a05afb04953a8b3527b9a374382.gif` / SHA-256 `3484d74f501ee8a131836b0220cd82034393fe4d3300a3cbdeace21e6ca68bcb`
  전체 연속 PNG 14장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F000.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F003.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F007.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F010.png`
  - `reference_resource_design/sand/frames/28c33a05afb04953a8b3527b9a374382_F013.png`
- keydownend: `reference_resource_design/sand/source/b97b5eda839440c3921f38656ef77649.gif` / SHA-256 `e403595b5a984595cbe0b31bdd7c654ba8d86ddf295534863f52243b27b92cf6`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/sand/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F000.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F001.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F002.png`
  - `reference_resource_design/sand/frames/b97b5eda839440c3921f38656ef77649_F003.png`
- icon: `reference_resource_design/sand/source/7e6eda520af54b87bc552712f3804ea6.png` / SHA-256 `b9d5c6b9e4f3da2aee959eb87c464998986d8dc03f78e1b6432b098902cd5de4`

### 버블 스타 / 버블 스타 강화 / `skill/40000.img/skill/400004429`
- 관찰한 표현: 밝은 내부 코어와 반투명 외피, 진행 방향 쪽의 압축과 후방 잔상
- 가져오지 않을 요소: 보라 구체와 후프를 모든 투사체의 모양으로 사용하지 않는다
- ball: `reference_resource_design/bubble/source/e4912b933bbc48a483451dae347bf6f3.gif` / SHA-256 `ef279982003fd473729c6516a8ea1a89fdddbdbefd90a9230b4fd3d3980497f1`
  전체 연속 PNG 4장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F000.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F001.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F002.png`
  - `reference_resource_design/bubble/frames/e4912b933bbc48a483451dae347bf6f3_F003.png`
- effect: `reference_resource_design/bubble/source/bcfebd118b0f4cb2b86971fe681b1081.gif` / SHA-256 `f197c7c9d60663bf5521183f5cb984b49c85251dd44f29627ce7462b7c7bbf5d`
  전체 연속 PNG 13장과 GIF 타이밍은 `reference_resource_design/bubble/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F000.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F003.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F006.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F009.png`
  - `reference_resource_design/bubble/frames/bcfebd118b0f4cb2b86971fe681b1081_F012.png`
- icon: `reference_resource_design/bubble/source/0b85676a40c74bc288d997270378bb12.png` / SHA-256 `6a6a6818cce417faa65da3e26a5732a11964f9550af30ebac3a115be60758656`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/001_m_white_sand_rabbit_흰_모래토끼/MONSTER_IMAGE.png` / SHA-256 `de9fd37727b97e83a05143abf6a9d37404d00231217e665262fe9b03a08d893a`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_white_sand_rabbit_OFFICIAL_VFX_BOARD.png` / SHA-256 `f2aed86857bac095ac4d86623e951c7a81feafc09e9878ff507dc95064e7a341`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_white_sand_rabbit_AREA00_FINISH_BOARD.png` / SHA-256 `a84ac9494a571998b8c6d1e32092764e194152aa1eecd5d92f0a64f36cb7a25f`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_white_sand_rabbit_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
