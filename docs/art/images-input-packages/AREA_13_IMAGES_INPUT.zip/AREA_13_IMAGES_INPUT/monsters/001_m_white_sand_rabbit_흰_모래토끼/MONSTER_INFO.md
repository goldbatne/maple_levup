# Monster Reference — 흰 모래토끼

- 작업 순번: 001
- level: 121
- Area: `area_13` / 니할 사막
- monster_id: `m_white_sand_rabbit`
- model_id: `whitesandrabbit`
- image RUID: `981c64ae30bd4f98aef886e9314d8e64`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_white_sand_rabbit`
- skill name/type: 사막 굴착탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
