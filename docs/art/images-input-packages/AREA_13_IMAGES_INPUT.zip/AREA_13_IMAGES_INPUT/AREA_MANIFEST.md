# area_13 니할 사막 Manifest

- 처리 순서: 13
- 레벨 범위: Lv121~130
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 121 | area_13 | 니할 사막 | m_white_sand_rabbit | 흰 모래토끼 | 981c64ae30bd4f98aef886e9314d8e64 | 확보 | s_mon_white_sand_rabbit | 사막 굴착탄 | 액티브 | ATK 계수 3.8로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0.12초; 지속 0.72초 | N | monsters/001_m_white_sand_rabbit_흰_모래토끼 |
| 2 | 123 | area_13 | 니할 사막 | m_scarf_plead | 목도리 프릴드 | 30e7faf77c6c41d583f341c234220597 | 확보 | s_mon_scarf_plead | 목도리의 사막감각 | 패시브 | 보유만 해도 LUK +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_scarf_plead_목도리_프릴드 |
| 3 | 125 | area_13 | 니할 사막 | m_meercat | 미요캐츠 | fc3c2944ce44425c8d7f302a8610b886 | 확보 | s_mon_meercat | 미요캐츠의 모래매복 | 액티브 | ATK 계수 3.95로 반경 4.8 범위 최대 3대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.74초 | N | monsters/003_m_meercat_미요캐츠 |
| 4 | 128 | area_13 | 니할 사막 | m_sand_dwarf | 모래난쟁이 | 64f166fa4e5445bc982071dea297d988 | 확보 | s_mon_sand_dwarf | 사막 대장장이의 체력 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_sand_dwarf_모래난쟁이 |
| 5 | 130 | area_13 | 니할 사막 | m_deo | 데우 | 6cf930e280f44694a0a0feedbfd855ed | 확보 | s_mon_deo | 잠든 선인장의 폭발 | 액티브 | INT 계수 4.25로 반경 6.4 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.78/0.9초 | Y | monsters/005_m_deo_데우 |
