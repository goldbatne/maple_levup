# Monster Reference — 다크 와이번

- 작업 순번: 004
- level: 158
- Area: `area_16` / 미나르숲
- monster_id: `m_dark_wyvern`
- model_id: `darkwyvern`
- image RUID: `2d932a6e7989426a9856fb5fc2d0e59f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_wyvern`
- skill name/type: 검은 비늘의 근력 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
