# Source provenance — 다크 와이번 / 검은 비늘의 근력

- rebuild run: `20260913_153134`
- base package: `AREA_16_IMAGES_INPUT.zip`
- base package SHA-256: `f0d4ed4f364cee44258de39b111f95ff18e4f58cb1c522ef2c0c9de715dd168a`
- preserved manifest monster image RUID: `2d932a6e7989426a9856fb5fc2d0e59f`
- preserved monster image status: `확보`
- preserved ids: `m_dark_wyvern` / `s_mon_dark_wyvern`
- preserved WHAT: `검은 비늘의 근력` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
