# Source provenance — 마뇽 / 마뇽의 용화염

- rebuild run: `20260913_153134`
- base package: `AREA_16_IMAGES_INPUT.zip`
- base package SHA-256: `f0d4ed4f364cee44258de39b111f95ff18e4f58cb1c522ef2c0c9de715dd168a`
- preserved manifest monster image RUID: `b8cdd7920392456f99272649c7cb7c2d`
- preserved monster image status: `확보`
- preserved ids: `m_manon` / `s_mon_manon`
- preserved WHAT: `마뇽의 용화염` / `액티브` / `INT 계수 5.15로 반경 6.9 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.17/0.34초; 지속 .72/.76/.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
