# Monster Reference — 마뇽

- 작업 순번: 005
- level: 160
- Area: `area_16` / 미나르숲
- monster_id: `m_manon`
- model_id: `manon`
- image RUID: `b8cdd7920392456f99272649c7cb7c2d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_manon`
- skill name/type: 마뇽의 용화염 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
