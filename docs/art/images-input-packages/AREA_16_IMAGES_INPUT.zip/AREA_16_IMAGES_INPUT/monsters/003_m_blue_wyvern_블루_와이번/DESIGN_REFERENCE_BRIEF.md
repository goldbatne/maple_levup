# 블루 와이번 — 빙룡 숨결: 실제 디자인 참조

monster_id: `m_blue_wyvern` / skill_id: `s_mon_blue_wyvern` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 용의 입김처럼 길게 뻗는 빙결 숨결과 쐐기 얼음. ‘블루 와이번 / 빙룡 숨결’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 빙룡 청색 #4B9FD5; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 빙결 백청 #D6F6FF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘빙룡 숨결’, 보조 효과 1개는 ‘얼음 쐐기’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/003_m_blue_wyvern_블루_와이번/MONSTER_IMAGE.png`

RUID: `07bc82953fca4677bc00f74680ec337b` / SHA-256: `f92376059afd06b522d5c127ce3453b7a1501aeaf583b4c94c611778668e2587`

## 이 스킬에 적용할 구체적인 디자인
긴 냉기 브레스와 쐐기 얼음 조각을 분리한다. 참조 늑대 머리·마법진·와이번 본체는 생성하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 프리징 브레스 / `skill/222.img/skill/2221011`
- 관찰한 표현: 앞쪽 얼음 면과 뒤쪽 옅은 냉기 밀도의 차, 종료 시 잔류 냉기
- 가져오지 않을 요소: 늑대 머리·원형 발사 문양을 제외하고 호흡 흐름만 새 소재에 구성한다
- keydown: `reference_resource_design/frost_breath/source/82faaa3358324d5ab259a72ae9a8c05e.gif` / SHA-256 `10cedc85535c32b7a07bdfef5f1fc030f6bb7d536d9f77cc1ab503e4631ffdd8`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/frost_breath/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/frost_breath/frames/82faaa3358324d5ab259a72ae9a8c05e_F000.png`
  - `reference_resource_design/frost_breath/frames/82faaa3358324d5ab259a72ae9a8c05e_F002.png`
  - `reference_resource_design/frost_breath/frames/82faaa3358324d5ab259a72ae9a8c05e_F004.png`
  - `reference_resource_design/frost_breath/frames/82faaa3358324d5ab259a72ae9a8c05e_F006.png`
  - `reference_resource_design/frost_breath/frames/82faaa3358324d5ab259a72ae9a8c05e_F007.png`
- keydownend: `reference_resource_design/frost_breath/source/40b431d8d9bb4a16a23eb7724962b161.gif` / SHA-256 `518da6ee7450ad4fa9268ef58c666c5874e23ab62bbc5207042398a4cd7e4440`
  전체 연속 PNG 5장과 GIF 타이밍은 `reference_resource_design/frost_breath/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/frost_breath/frames/40b431d8d9bb4a16a23eb7724962b161_F000.png`
  - `reference_resource_design/frost_breath/frames/40b431d8d9bb4a16a23eb7724962b161_F001.png`
  - `reference_resource_design/frost_breath/frames/40b431d8d9bb4a16a23eb7724962b161_F002.png`
  - `reference_resource_design/frost_breath/frames/40b431d8d9bb4a16a23eb7724962b161_F003.png`
  - `reference_resource_design/frost_breath/frames/40b431d8d9bb4a16a23eb7724962b161_F004.png`
- icon: `reference_resource_design/frost_breath/source/fce4228656b546ac98793726418ffc86.png` / SHA-256 `e7ce8b97d0bc0d95817900f7d748f9ca1a4cf39967aa25d985fd7d30daa9e808`

### 블리자드 VI / `skill/224.img/skill/2241003`
- 관찰한 표현: 얼음의 어두운 면·중간 청색 면·흰 모서리와 각진 파쇄
- 가져오지 않을 요소: 빙주 낙하를 목표의 다른 동작으로 대체하지 않는다
- effect: `reference_resource_design/ice/source/85919f65afd340aca9f601c2d090f67c.gif` / SHA-256 `e701c48214add5ed438f681a61ed64471cd5733fd8cc7ff5ac6570eb2c2e3824`
  전체 연속 PNG 31장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F000.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F007.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F015.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F023.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F030.png`
- hit/0: `reference_resource_design/ice/source/8edaaf07b78742adad6e4036a21bec76.gif` / SHA-256 `57ccfa365fc06e70d66f8202b3c4c407553d20b128eec8290769159631296030`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F000.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F002.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F004.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F006.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F007.png`
- icon: `reference_resource_design/ice/source/dd93587d98c44bf1a2698a14f273c662.png` / SHA-256 `1993c7929877b25b12609ce410048ed58267baca6df4ef4b095496238024d0f6`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/003_m_blue_wyvern_블루_와이번/MONSTER_IMAGE.png` / SHA-256 `f92376059afd06b522d5c127ce3453b7a1501aeaf583b4c94c611778668e2587`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_blue_wyvern_OFFICIAL_VFX_BOARD.png` / SHA-256 `dd970ac3897738181cf5fb492ca3897d2097485e93bef561212314ea99e2607e`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_blue_wyvern_AREA00_FINISH_BOARD.png` / SHA-256 `46bb4fa6d0f4d2d51c064adfd9520008177889e8606d86a70e5d0515ca7cab14`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_blue_wyvern_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
