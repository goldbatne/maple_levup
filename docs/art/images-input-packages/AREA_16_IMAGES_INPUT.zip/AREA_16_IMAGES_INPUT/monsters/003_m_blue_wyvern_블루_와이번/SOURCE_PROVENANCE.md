# Source provenance — 블루 와이번 / 빙룡 숨결

- rebuild run: `20260913_153134`
- base package: `AREA_16_IMAGES_INPUT.zip`
- base package SHA-256: `f0d4ed4f364cee44258de39b111f95ff18e4f58cb1c522ef2c0c9de715dd168a`
- preserved manifest monster image RUID: `07bc82953fca4677bc00f74680ec337b`
- preserved monster image status: `확보`
- preserved ids: `m_blue_wyvern` / `s_mon_blue_wyvern`
- preserved WHAT: `빙룡 숨결` / `액티브` / `INT 계수 4.9로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.72/0.82초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
