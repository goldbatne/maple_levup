# Monster Reference — 블루 와이번

- 작업 순번: 003
- level: 155
- Area: `area_16` / 미나르숲
- monster_id: `m_blue_wyvern`
- model_id: `bluewyvern`
- image RUID: `07bc82953fca4677bc00f74680ec337b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_wyvern`
- skill name/type: 빙룡 숨결 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
