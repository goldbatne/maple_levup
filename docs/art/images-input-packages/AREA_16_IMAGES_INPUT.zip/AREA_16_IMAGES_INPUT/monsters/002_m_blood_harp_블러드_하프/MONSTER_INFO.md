# Monster Reference — 블러드 하프

- 작업 순번: 002
- level: 153
- Area: `area_16` / 미나르숲
- monster_id: `m_blood_harp`
- model_id: `bloodharp`
- image RUID: `8c2ec5bf58894061a19479ed7545637b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blood_harp`
- skill name/type: 핏빛 깃울림 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
