# Source provenance — 블러드 하프 / 핏빛 깃울림

- rebuild run: `20260913_153134`
- base package: `AREA_16_IMAGES_INPUT.zip`
- base package SHA-256: `f0d4ed4f364cee44258de39b111f95ff18e4f58cb1c522ef2c0c9de715dd168a`
- preserved manifest monster image RUID: `8c2ec5bf58894061a19479ed7545637b`
- preserved monster image status: `확보`
- preserved ids: `m_blood_harp` / `s_mon_blood_harp`
- preserved WHAT: `핏빛 깃울림` / `액티브` / `INT 계수 4.75로 반경 5.6 범위 최대 4대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.68/0.78초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
