# Monster Reference — 하프

- 작업 순번: 001
- level: 151
- Area: `area_16` / 미나르숲
- monster_id: `m_harp`
- model_id: `harp`
- image RUID: `96bd8dd2077844d1a0e5ce6b956d94ef`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_harp`
- skill name/type: 하늘 둥지의 날갯결 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
