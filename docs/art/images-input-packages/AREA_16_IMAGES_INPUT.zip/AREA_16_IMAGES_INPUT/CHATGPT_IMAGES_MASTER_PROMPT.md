# ChatGPT Images Master Prompt — area_16 미나르숲

첨부된 ZIP 전체를 먼저 분석하세요. 이 ZIP은 `area_16` / **미나르숲**의 몬스터 5종에 대한 확정 입력 패키지입니다.

1. `AREA_MANIFEST`와 모든 `monsters/*/GENERATION_SPEC.md`를 읽으세요.
2. `global_skill_style_library`의 **전체** STYLE_INDEX, STYLE_ATLAS, skills/*/preview.png를 분석하세요. RECENT_PRIMARY가 비어 있으면 RECENT_SECONDARY를 사실상의 최신 우선 스타일 세트로 사용하세요. UNKNOWN과 LEGACY_REFERENCE는 비교·보조 참고이며 최종 렌더링 우선순위가 아닙니다. 전체 라이브러리는 유지하되 최종 아트 판단은 최신 메이플스토리/MSW 시각 문법을 우선하세요.
3. WHAT(몬스터, 스킬명, 타입, 효과, 동작)은 이미 확정되었습니다. 바꾸거나 재설계하지 마세요. HOW만 메이플스토리/MSW풍 시각 언어로 제작하세요.
4. 최신 스타일에서 어두운 외곽→중간톤 형상→밝은 코어, 발광, 반투명 레이어, 타격 플래시, 잔상, 파편, 에너지 흐름, 준비→상승→절정→소멸, 자연스러운 fade, 프레임 간 형태 변화를 우선 참고하세요.
5. 화면 점유율과 밀도는 각 GENERATION_SPEC의 레벨·체급·보스 여부·출력 프로필을 따르세요. 저레벨 일반몹을 고레벨 플레이어 스킬처럼 과장하지 마세요.
6. 기존 스킬의 무기, 캐릭터, 메커니즘, 고유 실루엣을 직접 복제하지 마세요. 스타일 문법만 참고하세요.
7. 각 몬스터에 대해 VFX 프레임과 ICON을 모두 생성하세요. 패시브 VFX는 현행 런타임 미적용 참고 모티브이며 기능을 추가하지 않습니다.
8. VFX 주 납품물은 반드시 `F00`, `F01`, `F02` ... 형식의 **프레임 분리형 개별 PNG**여야 합니다. PNG, RGBA, 실제 alpha 투명 배경, 체커보드 금지, 빈 프레임 금지, 프레임 누락 금지, 동일 캔버스·동일 중심축, 임의 크롭 금지, 우측 기준(FlipX 가능)을 지키세요.
9. VFX에 몬스터 본체, 글자, 숫자, UI, 워터마크를 넣지 마세요.
10. `OUTPUT_NAMING_SPEC.md`와 `OUTPUT_FORMAT_SPEC.md`를 정확히 따르세요. contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물이 아닙니다. 가능하면 프레임 분리형 결과 전체를 Area OUTPUT ZIP으로 반환하세요.

먼저 누락 파일을 점검한 뒤, 미확보 자료는 해당 GENERATION_SPEC와 확보된 자료로 계속 진행하고 임의의 공식 설정을 만들어내지 마세요.
