# Input source state

- rebuild run: `20260913_153134`
- base canonical package: `docs/art/images-input-packages/AREA_16_IMAGES_INPUT.zip`
- base package SHA-256: `f0d4ed4f364cee44258de39b111f95ff18e4f58cb1c522ef2c0c9de715dd168a`
- manifest/monster documents and MONSTER_IMAGE files were preserved from that canonical package, except for the appended reference assignment in GENERATION_SPEC.
- game data was not modified.
- AREA 06 is intentionally retired in the current project design, so operational Area ids are 00~05 and 07~20.
- resource search capture and AREA 00 baseline provenance are inside `global_skill_style_library`.
