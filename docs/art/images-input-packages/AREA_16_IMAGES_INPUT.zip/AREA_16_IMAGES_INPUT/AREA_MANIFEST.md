# area_16 미나르숲 Manifest

- 처리 순서: 16
- 레벨 범위: Lv151~160
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 151 | area_16 | 미나르숲 | m_harp | 하프 | 96bd8dd2077844d1a0e5ce6b956d94ef | 확보 | s_mon_harp | 하늘 둥지의 날갯결 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_harp_하프 |
| 2 | 153 | area_16 | 미나르숲 | m_blood_harp | 블러드 하프 | 8c2ec5bf58894061a19479ed7545637b | 확보 | s_mon_blood_harp | 핏빛 깃울림 | 액티브 | INT 계수 4.75로 반경 5.6 범위 최대 4대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.68/0.78초 | N | monsters/002_m_blood_harp_블러드_하프 |
| 3 | 155 | area_16 | 미나르숲 | m_blue_wyvern | 블루 와이번 | 07bc82953fca4677bc00f74680ec337b | 확보 | s_mon_blue_wyvern | 빙룡 숨결 | 액티브 | INT 계수 4.9로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.72/0.82초 | N | monsters/003_m_blue_wyvern_블루_와이번 |
| 4 | 158 | area_16 | 미나르숲 | m_dark_wyvern | 다크 와이번 | 2d932a6e7989426a9856fb5fc2d0e59f | 확보 | s_mon_dark_wyvern | 검은 비늘의 근력 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_dark_wyvern_다크_와이번 |
| 5 | 160 | area_16 | 미나르숲 | m_manon | 마뇽 | b8cdd7920392456f99272649c7cb7c2d | 확보 | s_mon_manon | 마뇽의 용화염 | 액티브 | INT 계수 5.15로 반경 6.9 범위 대상 제한 없음 피해; 11초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.17/0.34초; 지속 .72/.76/.82초 | Y | monsters/005_m_manon_마뇽 |
