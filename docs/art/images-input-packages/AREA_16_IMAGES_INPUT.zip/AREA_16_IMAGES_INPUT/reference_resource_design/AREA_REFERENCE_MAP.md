# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 하프 / 하늘 둥지의 날갯결: [monsters/001_m_harp_하프/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_harp_하프/DESIGN_REFERENCE_BRIEF.md) — gale, star
- 블러드 하프 / 핏빛 깃울림: [monsters/002_m_blood_harp_블러드_하프/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_blood_harp_블러드_하프/DESIGN_REFERENCE_BRIEF.md) — sound, star
- 블루 와이번 / 빙룡 숨결: [monsters/003_m_blue_wyvern_블루_와이번/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_blue_wyvern_블루_와이번/DESIGN_REFERENCE_BRIEF.md) — frost_breath, ice
- 다크 와이번 / 검은 비늘의 근력: [monsters/004_m_dark_wyvern_다크_와이번/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_dark_wyvern_다크_와이번/DESIGN_REFERENCE_BRIEF.md) — metal, dark_barrier
- 마뇽 / 마뇽의 용화염: [monsters/005_m_manon_마뇽/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_manon_마뇽/DESIGN_REFERENCE_BRIEF.md) — fire, dragon_fire