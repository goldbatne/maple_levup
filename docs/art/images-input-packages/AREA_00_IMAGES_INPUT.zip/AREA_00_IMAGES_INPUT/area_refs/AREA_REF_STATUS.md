# Area 분위기 자료

- 상태: 확보
- 프로젝트 원본: `docs/art/pilot-snail-images25/input/REF_05_AREA00_BACKGROUND.png`
- 용도: 색감·배경 대비 참고만 사용. 배경 자체를 VFX에 그리지 않는다.
