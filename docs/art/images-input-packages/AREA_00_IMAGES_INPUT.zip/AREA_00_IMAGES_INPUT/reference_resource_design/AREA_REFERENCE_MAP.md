# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 달팽이 / 이슬 미끄럼길: [monsters/001_m_snail_달팽이/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_snail_달팽이/DESIGN_REFERENCE_BRIEF.md) — water, water_shield
- 파란 달팽이 / 푸른 껍질: [monsters/002_m_blue_snail_파란_달팽이/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_blue_snail_파란_달팽이/DESIGN_REFERENCE_BRIEF.md) — water_shield, metal
- 빨간 달팽이 / 붉은 껍질 돌진: [monsters/003_m_red_snail_빨간_달팽이/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_red_snail_빨간_달팽이/DESIGN_REFERENCE_BRIEF.md) — punch, fire
- 마노 / 마노의 무지개 파동: [monsters/004_m_mano_마노/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_mano_마노/DESIGN_REFERENCE_BRIEF.md) — water, star
- 슬라임 / 끈적한 몸통: [monsters/005_m_slime_슬라임/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_slime_슬라임/DESIGN_REFERENCE_BRIEF.md) — water, water_shield