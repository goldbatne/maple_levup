# AREA 00 제작 품질 게이트

외부 TXT/CHATGPT_IMAGES_MASTER_PROMPT의 단일 스킬 파이프라인을 따른다. 여러 스킬을 한 이미지에 생성하면 즉시 FAIL이다.

## 첫 파이프라인 게이트

`s_mon_snail_dew_trail`의 필수 VFX가 참조 입력, 원화, 프레임 분리, 알파, 동작, ICON 게이트를 통과하기 전 나머지 스킬을 생성하지 않는다. 실패 원인을 분류하고 방식이나 프롬프트를 바꿔 같은 스킬만 다시 만든다. 같은 방식의 반복 재시도는 금지한다.

## 스킬별 PASS

- Identity: manifest와 GENERATION_SPEC의 WHAT, 소재, 팔레트, 방향 유지
- References: MONSTER_IMAGE와 두 prepared board를 실제 생성 입력으로 사용하고 경로·SHA-256 기록
- VFX: RUNTIME_ROLE_MAP이 요구한 경우 명세 수량의 개별 256×256 RGBA PNG 존재
- Passive: ICON-only는 불필요한 VFX를 만들지 않음
- Motion: RGB 형상이 같고 alpha만 달라지는 방식이 아니며 준비·성장·절정·해체·fade가 실제 형태 변화
- Stability: 같은 pivot/축/공통 스케일이며 프레임별 자동 크롭 흔들림 없음
- Rendering: 어두운 유색 면, 중간톤, 밝은 코어, 재질별 반사와 통제된 파편 구분
- Alpha: 바깥쪽 완전 투명 픽셀과 반투명 가장자리, 흰/검정/회색 matte 없음
- Isolation: 텍스트·번호·UI·몬스터 본체·다른 셀·공식 캐릭터/무기 없음
- Icon: 256×256 RGBA, 64px 읽힘, 완성 VFX 또는 고정 소재와 연결

## Area 패키징 PASS

- 정확히 VFX 44장, ICON 5장
- 연속 번호, 정확한 이름·폴더·canvas·RGBA
- 최종 PNG로 합성한 preview/contact/animation viewer
- manifest/result/validation/reference/state/source·추출 기록
- ZIP CRC와 각 엔트리 SHA-256 확인

하나라도 실패하면 정상 이름 `AREA_00_IMAGES_OUTPUT.zip`을 만들지 않는다. 실패 시안과 보고서만 든 ZIP은 납품물이 아니다.
