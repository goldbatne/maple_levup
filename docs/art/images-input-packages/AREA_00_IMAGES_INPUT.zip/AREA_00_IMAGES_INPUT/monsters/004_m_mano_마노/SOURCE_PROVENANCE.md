# Source provenance — 마노 / 마노의 무지개 파동

- rebuild run: `20260913_153134`
- base package: `AREA_00_IMAGES_INPUT.zip`
- base package SHA-256: `d1eb7b7f46061d3ef61c11781f0df0629d407d4415c8464f7567abea3a3dfdf7`
- preserved manifest monster image RUID: `e035bb90c053401b88de2159dfa230eb`
- preserved monster image status: `확보`
- preserved ids: `m_mano` / `s_mon_mano`
- preserved WHAT: `마노의 무지개 파동` / `액티브` / `INT 계수 1.45로 반경 4.5 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.08/0.2초; 지속 0.65/0.75/0.8초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
