# Runtime role map — 빨간 달팽이 / 붉은 껍질 돌진

- monster_id: `m_red_snail`
- skill_id: `s_mon_red_snail`
- skill_type: `액티브`
- required NEW_ART roles: **ICON | VFX**
- declared current motion: layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.05/0.32초; 지속 0.65/0.55/0.45초; 시전자가 목표 방향으로 돌진
- role decision: GENERATION_SPEC의 frame-separated VFX와 기본 ICON이 필수 NEW_ART다.
- base ICON is 256x256 RGBA. disabled/mouseover variants are not required by this INPUT.
- game scale, offset, RUID, AnimationClip settings are outside this image-production package and must not be changed.
