# Source provenance — 빨간 달팽이 / 붉은 껍질 돌진

- rebuild run: `20260913_153134`
- base package: `AREA_00_IMAGES_INPUT.zip`
- base package SHA-256: `d1eb7b7f46061d3ef61c11781f0df0629d407d4415c8464f7567abea3a3dfdf7`
- preserved manifest monster image RUID: `ffb9e9fba641457c818e9bf9d724461a`
- preserved monster image status: `확보`
- preserved ids: `m_red_snail` / `s_mon_red_snail`
- preserved WHAT: `붉은 껍질 돌진` / `액티브` / `ATK 계수 1.15로 단일 대상 피해; 4초 재사용; 5장 보유 시 계수 ×1.8; 4 거리 돌진` / `layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.05/0.32초; 지속 0.65/0.55/0.45초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
