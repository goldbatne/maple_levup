# area_05 노틸러스 Manifest

- 처리 순서: 6
- 레벨 범위: Lv41~60
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 41 | area_05 | 노틸러스 | m_ribbon_pig | 리본 돼지 | 6a699b8c31b94474bb795c7394c3af3b | 확보 | s_mon_ribbon_pig | 리본 돌진 | 액티브 | ATK 계수 1.8로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5.5 거리 돌진 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.04초; 지속 0.52/0.65초; 시전자가 목표 방향으로 돌진 | N | monsters/001_m_ribbon_pig_리본_돼지 |
| 2 | 43 | area_05 | 노틸러스 | m_blue_pig | 파란 리본돼지 | cba2695db0034210a59cd88b5894457b | 확보 | s_mon_blue_pig | 푸른 리본 매듭 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_blue_pig_파란_리본돼지 |
| 3 | 45 | area_05 | 노틸러스 | m_starfish | 불가사리 | 03351051e9e54fca87469eaa47c5398b | 확보 | s_mon_starfish | 별가시 회전 | 액티브 | ATK 계수 1.95로 반경 4 범위 최대 3대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.06초; 지속 0.55/0.68초 | N | monsters/003_m_starfish_불가사리 |
| 4 | 48 | area_05 | 노틸러스 | m_jellyfish | 쿨 젤리피쉬 | aef6048234a447c993fbdac54940f8f9 | 확보 | s_mon_jellyfish | 차가운 젤리 | 패시브 | 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_jellyfish_쿨_젤리피쉬 |
| 5 | 60 | area_05 | 노틸러스 | m_king_clang | 킹크랑 | cddcc91429d24abbb0c071135ace8b39 | 확보 | s_mon_king_clang | 왕게의 집게 파도 | 액티브 | ATK 계수 2.65로 반경 5.2 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.64/0.78초 | Y | monsters/005_m_king_clang_킹크랑 |
