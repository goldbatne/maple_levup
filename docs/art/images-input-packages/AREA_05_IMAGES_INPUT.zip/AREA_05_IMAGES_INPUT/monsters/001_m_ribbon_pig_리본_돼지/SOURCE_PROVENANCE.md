# Source provenance — 리본 돼지 / 리본 돌진

- rebuild run: `20260913_153134`
- base package: `AREA_05_IMAGES_INPUT.zip`
- base package SHA-256: `c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242`
- preserved manifest monster image RUID: `6a699b8c31b94474bb795c7394c3af3b`
- preserved monster image status: `확보`
- preserved ids: `m_ribbon_pig` / `s_mon_ribbon_pig`
- preserved WHAT: `리본 돌진` / `액티브` / `ATK 계수 1.8로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5.5 거리 돌진` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.04초; 지속 0.52/0.65초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
