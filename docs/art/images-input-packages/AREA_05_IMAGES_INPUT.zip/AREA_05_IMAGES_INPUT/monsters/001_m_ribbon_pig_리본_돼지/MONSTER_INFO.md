# Monster Reference — 리본 돼지

- 작업 순번: 001
- level: 41
- Area: `area_05` / 노틸러스
- monster_id: `m_ribbon_pig`
- model_id: `ribbonpig`
- image RUID: `6a699b8c31b94474bb795c7394c3af3b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ribbon_pig`
- skill name/type: 리본 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
