# Monster Reference — 불가사리

- 작업 순번: 003
- level: 45
- Area: `area_05` / 노틸러스
- monster_id: `m_starfish`
- model_id: `starfish`
- image RUID: `03351051e9e54fca87469eaa47c5398b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_starfish`
- skill name/type: 별가시 회전 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
