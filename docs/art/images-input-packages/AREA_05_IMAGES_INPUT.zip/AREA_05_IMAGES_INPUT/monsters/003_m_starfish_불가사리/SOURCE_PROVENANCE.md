# Source provenance — 불가사리 / 별가시 회전

- rebuild run: `20260913_153134`
- base package: `AREA_05_IMAGES_INPUT.zip`
- base package SHA-256: `c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242`
- preserved manifest monster image RUID: `03351051e9e54fca87469eaa47c5398b`
- preserved monster image status: `확보`
- preserved ids: `m_starfish` / `s_mon_starfish`
- preserved WHAT: `별가시 회전` / `액티브` / `ATK 계수 1.95로 반경 4 범위 최대 3대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.06초; 지속 0.55/0.68초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
