# Source provenance — 쿨 젤리피쉬 / 차가운 젤리

- rebuild run: `20260913_153134`
- base package: `AREA_05_IMAGES_INPUT.zip`
- base package SHA-256: `c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242`
- preserved manifest monster image RUID: `aef6048234a447c993fbdac54940f8f9`
- preserved monster image status: `확보`
- preserved ids: `m_jellyfish` / `s_mon_jellyfish`
- preserved WHAT: `차가운 젤리` / `패시브` / `보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
