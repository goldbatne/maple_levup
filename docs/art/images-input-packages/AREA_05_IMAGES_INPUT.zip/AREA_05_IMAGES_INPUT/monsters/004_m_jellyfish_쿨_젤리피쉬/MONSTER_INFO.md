# Monster Reference — 쿨 젤리피쉬

- 작업 순번: 004
- level: 48
- Area: `area_05` / 노틸러스
- monster_id: `m_jellyfish`
- model_id: `jellyfish`
- image RUID: `aef6048234a447c993fbdac54940f8f9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jellyfish`
- skill name/type: 차가운 젤리 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
