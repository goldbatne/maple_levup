# 쿨 젤리피쉬 — 차가운 젤리: 실제 디자인 참조

monster_id: `m_jellyfish` / skill_id: `s_mon_jellyfish` / 타입: 패시브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 차가운 젤리 방울이 늘어졌다 튀며 남기는 서리 테두리. ‘쿨 젤리피쉬 / 차가운 젤리’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 젤리 하늘 #67D6E8; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 서리 백청 #D8FAFF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘젤리 방울’, 보조 효과 1개는 ‘서리 튐’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_jellyfish_쿨_젤리피쉬/MONSTER_IMAGE.png`

RUID: `aef6048234a447c993fbdac54940f8f9` / SHA-256: `08dbbe6792be763bab07bed0b6cbfbaadc7b649cc12bb2b258ba65dee1bc2256`

## 이 스킬에 적용할 구체적인 디자인
차가운 젤리가 늘어나고 되튈 때 가장자리만 서리처럼 밝힌다. 단단한 빙주로 몸통 재질을 대체하지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 워터실드 / `skill/2311.img/skill/23111005`
- 관찰한 표현: 투명한 내부와 두꺼운 푸른 테두리, 국소 반사점이 분리된 물막
- 가져오지 않을 요소: effect의 요정 본체는 사용하지 않는다. 구형 모양은 목표 명세가 막일 때만 적용한다
- repeat: `reference_resource_design/water_shield/source/53e7aaf6b3f1401ba1909ebeebd337ab.gif` / SHA-256 `98725d84cd0ef2e40ea1ccf5d3c617b49d192d83181c0eddff4d4e912e5b0bcf`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/water_shield/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/water_shield/frames/53e7aaf6b3f1401ba1909ebeebd337ab_F000.png`
  - `reference_resource_design/water_shield/frames/53e7aaf6b3f1401ba1909ebeebd337ab_F002.png`
  - `reference_resource_design/water_shield/frames/53e7aaf6b3f1401ba1909ebeebd337ab_F004.png`
  - `reference_resource_design/water_shield/frames/53e7aaf6b3f1401ba1909ebeebd337ab_F006.png`
  - `reference_resource_design/water_shield/frames/53e7aaf6b3f1401ba1909ebeebd337ab_F007.png`
- icon: `reference_resource_design/water_shield/source/d3c555f2af214be799c296ad9020bf24.png` / SHA-256 `a97a8aeb054dc3c59b2b95fc74bfd0568c267f40fb9d866c3fdd054b872e285e`

### 블리자드 VI / `skill/224.img/skill/2241003`
- 관찰한 표현: 얼음의 어두운 면·중간 청색 면·흰 모서리와 각진 파쇄
- 가져오지 않을 요소: 빙주 낙하를 목표의 다른 동작으로 대체하지 않는다
- effect: `reference_resource_design/ice/source/85919f65afd340aca9f601c2d090f67c.gif` / SHA-256 `e701c48214add5ed438f681a61ed64471cd5733fd8cc7ff5ac6570eb2c2e3824`
  전체 연속 PNG 31장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F000.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F007.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F015.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F023.png`
  - `reference_resource_design/ice/frames/85919f65afd340aca9f601c2d090f67c_F030.png`
- hit/0: `reference_resource_design/ice/source/8edaaf07b78742adad6e4036a21bec76.gif` / SHA-256 `57ccfa365fc06e70d66f8202b3c4c407553d20b128eec8290769159631296030`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/ice/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F000.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F002.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F004.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F006.png`
  - `reference_resource_design/ice/frames/8edaaf07b78742adad6e4036a21bec76_F007.png`
- icon: `reference_resource_design/ice/source/dd93587d98c44bf1a2698a14f273c662.png` / SHA-256 `1993c7929877b25b12609ce410048ed58267baca6df4ef4b095496238024d0f6`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/005_m_slime_s_mon_slime_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/005_m_slime_슬라임/005_m_slime_s_mon_slime_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_jellyfish_쿨_젤리피쉬/MONSTER_IMAGE.png` / SHA-256 `08dbbe6792be763bab07bed0b6cbfbaadc7b649cc12bb2b258ba65dee1bc2256`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_jellyfish_OFFICIAL_VFX_BOARD.png` / SHA-256 `df9cdb51b4adb4e8a13a675cb92bacdc5d29e1ac3a7a6983841e607e9af7ba01`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_jellyfish_AREA00_FINISH_BOARD.png` / SHA-256 `662d5f45cd2215039bd29910634554eacf3617d654ac1ce1ebdf9a32dd4c8f2e`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_jellyfish_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
