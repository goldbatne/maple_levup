# Monster Reference — 파란 리본돼지

- 작업 순번: 002
- level: 43
- Area: `area_05` / 노틸러스
- monster_id: `m_blue_pig`
- model_id: `bluepig`
- image RUID: `cba2695db0034210a59cd88b5894457b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_pig`
- skill name/type: 푸른 리본 매듭 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
