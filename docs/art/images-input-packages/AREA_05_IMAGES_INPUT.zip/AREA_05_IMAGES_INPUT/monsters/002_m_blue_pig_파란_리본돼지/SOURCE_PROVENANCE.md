# Source provenance — 파란 리본돼지 / 푸른 리본 매듭

- rebuild run: `20260913_153134`
- base package: `AREA_05_IMAGES_INPUT.zip`
- base package SHA-256: `c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242`
- preserved manifest monster image RUID: `cba2695db0034210a59cd88b5894457b`
- preserved monster image status: `확보`
- preserved ids: `m_blue_pig` / `s_mon_blue_pig`
- preserved WHAT: `푸른 리본 매듭` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
