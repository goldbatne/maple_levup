# Source provenance — 킹크랑 / 왕게의 집게 파도

- rebuild run: `20260913_153134`
- base package: `AREA_05_IMAGES_INPUT.zip`
- base package SHA-256: `c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242`
- preserved manifest monster image RUID: `cddcc91429d24abbb0c071135ace8b39`
- preserved monster image status: `확보`
- preserved ids: `m_king_clang` / `s_mon_king_clang`
- preserved WHAT: `왕게의 집게 파도` / `액티브` / `ATK 계수 2.65로 반경 5.2 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.64/0.78초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
