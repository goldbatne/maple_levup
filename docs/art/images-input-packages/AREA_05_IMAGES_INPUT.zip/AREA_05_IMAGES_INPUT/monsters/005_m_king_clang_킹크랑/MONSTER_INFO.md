# Monster Reference — 킹크랑

- 작업 순번: 005
- level: 60
- Area: `area_05` / 노틸러스
- monster_id: `m_king_clang`
- model_id: `kingclang`
- image RUID: `cddcc91429d24abbb0c071135ace8b39`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_king_clang`
- skill name/type: 왕게의 집게 파도 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
