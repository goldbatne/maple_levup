# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 리본 돼지 / 리본 돌진: [monsters/001_m_ribbon_pig_리본_돼지/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_ribbon_pig_리본_돼지/DESIGN_REFERENCE_BRIEF.md) — punch, star
- 파란 리본돼지 / 푸른 리본 매듭: [monsters/002_m_blue_pig_파란_리본돼지/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_blue_pig_파란_리본돼지/DESIGN_REFERENCE_BRIEF.md) — metal, star
- 불가사리 / 별가시 회전: [monsters/003_m_starfish_불가사리/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_starfish_불가사리/DESIGN_REFERENCE_BRIEF.md) — star, water
- 쿨 젤리피쉬 / 차가운 젤리: [monsters/004_m_jellyfish_쿨_젤리피쉬/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_jellyfish_쿨_젤리피쉬/DESIGN_REFERENCE_BRIEF.md) — water_shield, ice
- 킹크랑 / 왕게의 집게 파도: [monsters/005_m_king_clang_킹크랑/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_king_clang_킹크랑/DESIGN_REFERENCE_BRIEF.md) — water, punch