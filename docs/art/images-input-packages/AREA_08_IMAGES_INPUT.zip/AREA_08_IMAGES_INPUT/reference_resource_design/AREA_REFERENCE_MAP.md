# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 스타픽시 / 별빛 탄환: [monsters/001_m_star_pixie_스타픽시/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_star_pixie_스타픽시/DESIGN_REFERENCE_BRIEF.md) — star, bubble
- 주니어 샐리온 / 붉은 뿔의 기백: [monsters/002_m_jr_cellion_주니어_샐리온/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_jr_cellion_주니어_샐리온/DESIGN_REFERENCE_BRIEF.md) — fire, nature
- 루나픽시 / 월광 구슬: [monsters/003_m_lunar_pixie_루나픽시/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_lunar_pixie_루나픽시/DESIGN_REFERENCE_BRIEF.md) — star, bubble
- 러스터픽시 / 태양빛 잔상: [monsters/004_m_luster_pixie_러스터픽시/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_luster_pixie_러스터픽시/DESIGN_REFERENCE_BRIEF.md) — star, garden
- 엘리쟈 / 여신의 정원 폭풍: [monsters/005_m_eliza_엘리쟈/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_eliza_엘리쟈/DESIGN_REFERENCE_BRIEF.md) — gale, garden