# area_08 오르비스 Manifest

- 처리 순서: 8
- 레벨 범위: Lv71~80
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 71 | area_08 | 오르비스 | m_star_pixie | 스타픽시 | ca136923b7e84267af993bdbabada385 | 확보 | s_mon_star_pixie | 별빛 탄환 | 액티브 | INT 계수 2.45로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.62/0.58초; 투사체 b61e7e2a50b2405794f88fdddf44b73a가 목표 방향으로 이동 | N | monsters/001_m_star_pixie_스타픽시 |
| 2 | 73 | area_08 | 오르비스 | m_jr_cellion | 주니어 샐리온 | 016bc9a459104e2a8a2fea03d7130519 | 확보 | s_mon_jr_cellion | 붉은 뿔의 기백 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/002_m_jr_cellion_주니어_샐리온 |
| 3 | 75 | area_08 | 오르비스 | m_lunar_pixie | 루나픽시 | ff4a57bc3d4a4488b0053c33f4c3369f | 확보 | s_mon_lunar_pixie | 월광 구슬 | 액티브 | INT 계수 2.6로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.68/0.62초; 투사체 4f6509d9539f4d76a9bb4e8f17e12cc7가 목표 방향으로 이동 | N | monsters/003_m_lunar_pixie_루나픽시 |
| 4 | 78 | area_08 | 오르비스 | m_luster_pixie | 러스터픽시 | 35f555b27d3a4d438224a29e73fac305 | 확보 | s_mon_luster_pixie | 태양빛 잔상 | 패시브 | 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/004_m_luster_pixie_러스터픽시 |
| 5 | 80 | area_08 | 오르비스 | m_eliza | 엘리쟈 | d458879e2e2949f2bb2e915ff67fbc64 | 확보 | s_mon_eliza | 여신의 정원 폭풍 | 액티브 | INT 계수 3로 반경 5.8 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.22초; 지속 0.72/0.85초 | Y | monsters/005_m_eliza_엘리쟈 |
