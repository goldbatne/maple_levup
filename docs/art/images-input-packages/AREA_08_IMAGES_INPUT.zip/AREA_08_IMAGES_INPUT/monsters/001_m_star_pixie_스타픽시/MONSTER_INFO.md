# Monster Reference — 스타픽시

- 작업 순번: 001
- level: 71
- Area: `area_08` / 오르비스
- monster_id: `m_star_pixie`
- model_id: `starpixie`
- image RUID: `ca136923b7e84267af993bdbabada385`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_star_pixie`
- skill name/type: 별빛 탄환 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
