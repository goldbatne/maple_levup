# Monster Reference — 엘리쟈

- 작업 순번: 005
- level: 80
- Area: `area_08` / 오르비스
- monster_id: `m_eliza`
- model_id: `eliza`
- image RUID: `d458879e2e2949f2bb2e915ff67fbc64`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_eliza`
- skill name/type: 여신의 정원 폭풍 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
