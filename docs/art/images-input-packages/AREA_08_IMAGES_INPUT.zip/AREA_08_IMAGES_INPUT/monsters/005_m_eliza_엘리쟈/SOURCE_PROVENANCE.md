# Source provenance — 엘리쟈 / 여신의 정원 폭풍

- rebuild run: `20260913_153134`
- base package: `AREA_08_IMAGES_INPUT.zip`
- base package SHA-256: `16de199833389106e8347c229eb023a95f42b2fcc8e1cef924ab5780962117dd`
- preserved manifest monster image RUID: `d458879e2e2949f2bb2e915ff67fbc64`
- preserved monster image status: `확보`
- preserved ids: `m_eliza` / `s_mon_eliza`
- preserved WHAT: `여신의 정원 폭풍` / `액티브` / `INT 계수 3로 반경 5.8 범위 대상 제한 없음 피해; 8초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.22초; 지속 0.72/0.85초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
