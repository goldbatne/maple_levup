# Monster Reference — 루나픽시

- 작업 순번: 003
- level: 75
- Area: `area_08` / 오르비스
- monster_id: `m_lunar_pixie`
- model_id: `lunarpixie`
- image RUID: `ff4a57bc3d4a4488b0053c33f4c3369f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_lunar_pixie`
- skill name/type: 월광 구슬 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
