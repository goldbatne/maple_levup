# Source provenance — 루나픽시 / 월광 구슬

- rebuild run: `20260913_153134`
- base package: `AREA_08_IMAGES_INPUT.zip`
- base package SHA-256: `16de199833389106e8347c229eb023a95f42b2fcc8e1cef924ab5780962117dd`
- preserved manifest monster image RUID: `ff4a57bc3d4a4488b0053c33f4c3369f`
- preserved monster image status: `확보`
- preserved ids: `m_lunar_pixie` / `s_mon_lunar_pixie`
- preserved WHAT: `월광 구슬` / `액티브` / `INT 계수 2.6로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.2초; 지속 0.68/0.62초; 투사체 4f6509d9539f4d76a9bb4e8f17e12cc7가 목표 방향으로 이동`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
