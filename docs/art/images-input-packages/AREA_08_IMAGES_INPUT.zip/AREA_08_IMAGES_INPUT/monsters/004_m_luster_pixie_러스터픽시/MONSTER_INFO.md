# Monster Reference — 러스터픽시

- 작업 순번: 004
- level: 78
- Area: `area_08` / 오르비스
- monster_id: `m_luster_pixie`
- model_id: `lusterpixie`
- image RUID: `35f555b27d3a4d438224a29e73fac305`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_luster_pixie`
- skill name/type: 태양빛 잔상 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
