# Source provenance — 러스터픽시 / 태양빛 잔상

- rebuild run: `20260913_153134`
- base package: `AREA_08_IMAGES_INPUT.zip`
- base package SHA-256: `16de199833389106e8347c229eb023a95f42b2fcc8e1cef924ab5780962117dd`
- preserved manifest monster image RUID: `35f555b27d3a4d438224a29e73fac305`
- preserved monster image status: `확보`
- preserved ids: `m_luster_pixie` / `s_mon_luster_pixie`
- preserved WHAT: `태양빛 잔상` / `패시브` / `보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
