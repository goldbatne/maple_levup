# Monster Reference — 주니어 샐리온

- 작업 순번: 002
- level: 73
- Area: `area_08` / 오르비스
- monster_id: `m_jr_cellion`
- model_id: `jrcellion`
- image RUID: `016bc9a459104e2a8a2fea03d7130519`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_cellion`
- skill name/type: 붉은 뿔의 기백 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
