# 주니어 샐리온 — 붉은 뿔의 기백: 실제 디자인 참조

monster_id: `m_jr_cellion` / skill_id: `s_mon_jr_cellion` / 타입: 패시브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 붉은 뿔 끝에서 솟는 짧은 기백 불꽃과 압력 고리. ‘주니어 샐리온 / 붉은 뿔의 기백’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 뿔 적색 #C94C55; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 기백 금빛 #F2C45B; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘붉은 뿔’, 보조 효과 1개는 ‘기백 고리’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/002_m_jr_cellion_주니어_샐리온/MONSTER_IMAGE.png`

RUID: `016bc9a459104e2a8a2fea03d7130519` / SHA-256: `f6afda60c0857052b3f96edad9bd2f6454b228aed81c3b208bf84d3fe1a431e2`

## 이 스킬에 적용할 구체적인 디자인
붉은 뿔끝의 활력과 압력 고리를 ICON으로 읽히게 한다. 불 마법진이나 동물 얼굴이 주제가 되지 않게 한다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 오비탈 플레임 VI / `skill/1214.img/skill/12141000`
- 관찰한 표현: 짙은 주황 덩어리와 노란 코어가 분리된 불꽃 가장자리와 분해
- 가져오지 않을 요소: 원형 불 문양·룬은 제외하며 목표의 화염 방향을 유지한다
- effect: `reference_resource_design/fire/source/9d8fc36fee8d4bcb96a0deedd60ddb31.gif` / SHA-256 `fd6925af02f3a7ef26c99e9908e6bfb3a92d11c9df97ed893b7c51397768d90d`
  전체 연속 PNG 16장과 GIF 타이밍은 `reference_resource_design/fire/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/fire/frames/9d8fc36fee8d4bcb96a0deedd60ddb31_F000.png`
  - `reference_resource_design/fire/frames/9d8fc36fee8d4bcb96a0deedd60ddb31_F004.png`
  - `reference_resource_design/fire/frames/9d8fc36fee8d4bcb96a0deedd60ddb31_F008.png`
  - `reference_resource_design/fire/frames/9d8fc36fee8d4bcb96a0deedd60ddb31_F012.png`
  - `reference_resource_design/fire/frames/9d8fc36fee8d4bcb96a0deedd60ddb31_F015.png`
- icon: `reference_resource_design/fire/source/d0efe4b598b4402580fac9a2d94cff33.png` / SHA-256 `1edc8a2bfc5a20b6b801c7ad7f20ff6bf1be5f1a117ec73bc1ddbaf602db88e3`

### 정기 뿌리기 / 정기 뿌리기 강화 / `skill/16212.img/skill/162121021`
- 관찰한 표현: 작은 입자군이 코어 주위에서 퍼져 농도와 광량을 함께 잃는 전개
- 가져오지 않을 요소: 꽃별 문양과 연두 팔레트를 강제하지 않는다
- effect: `reference_resource_design/nature/source/15fb0e791d5843108b230b3216ff0764.gif` / SHA-256 `1bf89cbd617c689cb874dd98241eb5d7734293758efd7ddadd3680a5255000f2`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F000.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F002.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F005.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F007.png`
  - `reference_resource_design/nature/frames/15fb0e791d5843108b230b3216ff0764_F009.png`
- hit/0: `reference_resource_design/nature/source/04c96fc0062c418682c8075beb003a0c.gif` / SHA-256 `2d769417bd428c55eedb33fd8f565fadcd185bbc2a11b0eb32a3e93d211ef4ac`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/nature/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F000.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F002.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F005.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F007.png`
  - `reference_resource_design/nature/frames/04c96fc0062c418682c8075beb003a0c_F009.png`
- icon: `reference_resource_design/nature/source/c9fac8505f8c4efc9b9864dc540d038f.png` / SHA-256 `ce30ebdc7957924300b5798b16992e9816a96d8769b13bac9b439a056a68d0ae`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/002_m_jr_cellion_주니어_샐리온/MONSTER_IMAGE.png` / SHA-256 `f6afda60c0857052b3f96edad9bd2f6454b228aed81c3b208bf84d3fe1a431e2`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_jr_cellion_OFFICIAL_VFX_BOARD.png` / SHA-256 `49a9adfa3395282807f22c954389d85f2100a4c841e027fad9052e02e58c52a0`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_jr_cellion_AREA00_FINISH_BOARD.png` / SHA-256 `26c3f7512ff18adb0c811f48bc36f153512a2f8bfda68e7ed35c9553007ab1cd`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_jr_cellion_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
