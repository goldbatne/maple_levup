# area_20 황혼의 페리온 Manifest

- 처리 순서: 20
- 레벨 범위: Lv191~200
- 포획 가능 몬스터: 5종
- 자료 누락: 0건

| work_order | level | area_id | area_name | monster_id | monster_name | monster_image_ruid | monster_image_status | skill_id | skill_name | skill_type | actual_effect | actual_motion | boss | folder |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 191 | area_20 | 황혼의 페리온 | m_mutant_dark_stump | 변형된 다크 스텀프 | 9b09382f4ba6483eb11a931f49a68f9b | 확보 | s_mon_mutant_dark_stump | 뒤틀린 고목의 껍질 | 패시브 | 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/001_m_mutant_dark_stump_변형된_다크_스텀프 |
| 2 | 193 | area_20 | 황혼의 페리온 | m_mutant_iron_hog | 변형된 아이언호그 | cd613d0025674a6f8b1cc7211054eb41 | 확보 | s_mon_mutant_iron_hog | 황야의 철갑 돌진 | 액티브 | ATK 계수 6.15로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8; 6.8 거리 돌진 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.18초; 지속 .68/.78초; 시전자가 목표 방향으로 돌진 | N | monsters/002_m_mutant_iron_hog_변형된_아이언호그 |
| 3 | 195 | area_20 | 황혼의 페리온 | m_mutant_stone_mask | 변형된 스톤마스크 | f020a220a2ad40a28d4920b790b32f3c | 확보 | s_mon_mutant_stone_mask | 발굴지의 석면 | 패시브 | 보유만 해도 DEF +1; 중복 1장당 +0.25, 5장 최대 +2 | 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시 | N | monsters/003_m_mutant_stone_mask_변형된_스톤마스크 |
| 4 | 198 | area_20 | 황혼의 페리온 | m_ancient_dark_golem | 에인션트 다크골렘 | f60c7188fcd544ef869845a34ff92b30 | 확보 | s_mon_ancient_dark_golem | 고대 암흑 지진 | 액티브 | ATK 계수 6.45로 반경 6.4 범위 최대 5대상 피해; 10초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.3초; 지속 .9/1.0초 | N | monsters/004_m_ancient_dark_golem_에인션트_다크골렘 |
| 5 | 200 | area_20 | 황혼의 페리온 | m_mutant_stumpy | 변형된 스텀피 | fe3077e91e5442579b6cfaa6b4c59469 | 확보 | s_mon_mutant_stumpy | 검은 뿌리의 묘지 | 액티브 | ATK 계수 6.7로 반경 7.6 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8 | layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.24초; 지속 .88/1.02초 | Y | monsters/005_m_mutant_stumpy_변형된_스텀피 |
