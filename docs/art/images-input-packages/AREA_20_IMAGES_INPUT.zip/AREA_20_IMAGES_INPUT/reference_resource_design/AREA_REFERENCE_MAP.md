# Area 스킬별 실제 참조 연결

각 몬스터 폴더의 brief를 읽고 실제 이미지를 생성 입력으로 사용한다. 공통 ZIP은 필요 없다.

- 변형된 다크 스텀프 / 뒤틀린 고목의 껍질: [monsters/001_m_mutant_dark_stump_변형된_다크_스텀프/DESIGN_REFERENCE_BRIEF.md](../monsters/001_m_mutant_dark_stump_변형된_다크_스텀프/DESIGN_REFERENCE_BRIEF.md) — dark_barrier, metal
- 변형된 아이언호그 / 황야의 철갑 돌진: [monsters/002_m_mutant_iron_hog_변형된_아이언호그/DESIGN_REFERENCE_BRIEF.md](../monsters/002_m_mutant_iron_hog_변형된_아이언호그/DESIGN_REFERENCE_BRIEF.md) — punch, sand
- 변형된 스톤마스크 / 발굴지의 석면: [monsters/003_m_mutant_stone_mask_변형된_스톤마스크/DESIGN_REFERENCE_BRIEF.md](../monsters/003_m_mutant_stone_mask_변형된_스톤마스크/DESIGN_REFERENCE_BRIEF.md) — earth, metal
- 에인션트 다크골렘 / 고대 암흑 지진: [monsters/004_m_ancient_dark_golem_에인션트_다크골렘/DESIGN_REFERENCE_BRIEF.md](../monsters/004_m_ancient_dark_golem_에인션트_다크골렘/DESIGN_REFERENCE_BRIEF.md) — earth, quake
- 변형된 스텀피 / 검은 뿌리의 묘지: [monsters/005_m_mutant_stumpy_변형된_스텀피/DESIGN_REFERENCE_BRIEF.md](../monsters/005_m_mutant_stumpy_변형된_스텀피/DESIGN_REFERENCE_BRIEF.md) — earth, dark_magic