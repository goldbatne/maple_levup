# Monster Reference — 변형된 스톤마스크

- 작업 순번: 003
- level: 195
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_stone_mask`
- model_id: `mutantstonemask`
- image RUID: `f020a220a2ad40a28d4920b790b32f3c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_stone_mask`
- skill name/type: 발굴지의 석면 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
