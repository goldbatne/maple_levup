# Monster Reference — 변형된 스텀피

- 작업 순번: 005
- level: 200
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_stumpy`
- model_id: `mutantstumpy`
- image RUID: `fe3077e91e5442579b6cfaa6b4c59469`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_stumpy`
- skill name/type: 검은 뿌리의 묘지 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
