# Source provenance — 변형된 스텀피 / 검은 뿌리의 묘지

- rebuild run: `20260913_153134`
- base package: `AREA_20_IMAGES_INPUT.zip`
- base package SHA-256: `41726ac492bc6725150cf9204146804acd29b8024f14a9a64eac2f3601c4d249`
- preserved manifest monster image RUID: `fe3077e91e5442579b6cfaa6b4c59469`
- preserved monster image status: `확보`
- preserved ids: `m_mutant_stumpy` / `s_mon_mutant_stumpy`
- preserved WHAT: `검은 뿌리의 묘지` / `액티브` / `ATK 계수 6.7로 반경 7.6 범위 대상 제한 없음 피해; 12초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.24초; 지속 .88/1.02초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
