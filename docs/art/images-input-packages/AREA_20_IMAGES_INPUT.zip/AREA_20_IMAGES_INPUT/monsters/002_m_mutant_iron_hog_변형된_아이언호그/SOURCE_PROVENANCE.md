# Source provenance — 변형된 아이언호그 / 황야의 철갑 돌진

- rebuild run: `20260913_153134`
- base package: `AREA_20_IMAGES_INPUT.zip`
- base package SHA-256: `41726ac492bc6725150cf9204146804acd29b8024f14a9a64eac2f3601c4d249`
- preserved manifest monster image RUID: `cd613d0025674a6f8b1cc7211054eb41`
- preserved monster image status: `확보`
- preserved ids: `m_mutant_iron_hog` / `s_mon_mutant_iron_hog`
- preserved WHAT: `황야의 철갑 돌진` / `액티브` / `ATK 계수 6.15로 단일 대상 피해; 8초 재사용; 5장 보유 시 계수 ×1.8; 6.8 거리 돌진` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.18초; 지속 .68/.78초; 시전자가 목표 방향으로 돌진`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
