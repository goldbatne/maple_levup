# Monster Reference — 변형된 아이언호그

- 작업 순번: 002
- level: 193
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_iron_hog`
- model_id: `mutantironhog`
- image RUID: `cd613d0025674a6f8b1cc7211054eb41`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_iron_hog`
- skill name/type: 황야의 철갑 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
