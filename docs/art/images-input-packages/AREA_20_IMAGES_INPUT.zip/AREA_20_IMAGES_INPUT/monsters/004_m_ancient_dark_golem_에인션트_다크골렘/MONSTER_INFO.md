# Monster Reference — 에인션트 다크골렘

- 작업 순번: 004
- level: 198
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_ancient_dark_golem`
- model_id: `ancientdarkgolem`
- image RUID: `f60c7188fcd544ef869845a34ff92b30`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ancient_dark_golem`
- skill name/type: 고대 암흑 지진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
