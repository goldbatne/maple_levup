# Source provenance — 에인션트 다크골렘 / 고대 암흑 지진

- rebuild run: `20260913_153134`
- base package: `AREA_20_IMAGES_INPUT.zip`
- base package SHA-256: `41726ac492bc6725150cf9204146804acd29b8024f14a9a64eac2f3601c4d249`
- preserved manifest monster image RUID: `f60c7188fcd544ef869845a34ff92b30`
- preserved monster image status: `확보`
- preserved ids: `m_ancient_dark_golem` / `s_mon_ancient_dark_golem`
- preserved WHAT: `고대 암흑 지진` / `액티브` / `ATK 계수 6.45로 반경 6.4 범위 최대 5대상 피해; 10초 재사용; 5장 보유 시 계수 ×1.8` / `layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.3초; 지속 .9/1.0초`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
