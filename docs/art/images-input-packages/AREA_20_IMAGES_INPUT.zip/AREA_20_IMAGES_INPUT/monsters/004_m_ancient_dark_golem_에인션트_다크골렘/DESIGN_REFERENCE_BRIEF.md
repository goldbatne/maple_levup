# 에인션트 다크골렘 — 고대 암흑 지진: 실제 디자인 참조

monster_id: `m_ancient_dark_golem` / skill_id: `s_mon_ancient_dark_golem` / 타입: 액티브

경로는 INPUT ZIP 루트 기준이다. 원본 소재·역할을 아래 공식 스킬로 대체하는 지시가 아니다.

## 고정 소재와 몬스터
- 핵심 소재: 고대 암석 균열이 지면을 가로지르며 검은 돌기둥을 세우는 지진. ‘에인션트 다크골렘 / 고대 암흑 지진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 고대 흑암 #35343B; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 균열 적갈 #A55A43; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘균열 지면’, 보조 효과 1개는 ‘암흑 돌기둥’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함

실제 몬스터 입력: `monsters/004_m_ancient_dark_golem_에인션트_다크골렘/MONSTER_IMAGE.png`

RUID: `f60c7188fcd544ef869845a34ff92b30` / SHA-256: `9caac00e345cd8f2aa0e039e94a39cb4a945f3304951a0b0354743d0220f23b4`

## 이 스킬에 적용할 구체적인 디자인
고대 암석 균열에서 검은 기둥이 솟고 지진층이 낮게 퍼진다. 푸른 물파도나 주황 전기 폭발로 바꾸지 않는다.

## 공식 실제 이미지 — 모두 관찰하고 필요한 프레임을 실제 입력

### 토파류 : 지 VI / `skill/16414.img/skill/164141031`
- 관찰한 표현: 지면에서 큰 덩어리가 솟고 작은 조각이 뒤따르는 두께와 전개
- 가져오지 않을 요소: 파란 소용돌이 무늬를 암석·뿌리 재질로 복제하지 않는다
- effect: `reference_resource_design/earth/source/b52e4783d81c40459328d7365f877687.gif` / SHA-256 `6c51d1749b23cdb421380a5dd6f4eae7404a9b4e5e9a445884f552efcde70784`
  전체 연속 PNG 9장과 GIF 타이밍은 `reference_resource_design/earth/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F000.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F002.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F004.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F006.png`
  - `reference_resource_design/earth/frames/b52e4783d81c40459328d7365f877687_F008.png`
- effect0: `reference_resource_design/earth/source/2f320471786744ae8063f9708bf088d0.gif` / SHA-256 `25deb5216ac99afdd632c412e558dbfa5e515a5bceb631a5452b65475d7584e5`
  전체 연속 PNG 10장과 GIF 타이밍은 `reference_resource_design/earth/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F000.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F002.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F005.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F007.png`
  - `reference_resource_design/earth/frames/2f320471786744ae8063f9708bf088d0_F009.png`
- icon: `reference_resource_design/earth/source/5480e0dfc9ba46daa64230e493a4facc.png` / SHA-256 `a239ecd07d6eb0f69845bc66b6123fa5df3342ddc38faa686d909bf10b294df6`

### 어스 브레이크 VI / `skill/10114.img/skill/101141005`
- 관찰한 표현: 낮은 지면층의 균열광과 짧은 각진 충격면, 사라지는 잔진
- 가져오지 않을 요소: 주황 전기 균열을 모든 지면 재질로 사용하지 않는다
- tile: `reference_resource_design/quake/source/3b0608e170634d34a96f0f516827d7a8.gif` / SHA-256 `5e06345ec19ff6dab34ed3450933be5c07878f84aeb7ec1605fdba8e7eb44c26`
  전체 연속 PNG 8장과 GIF 타이밍은 `reference_resource_design/quake/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F000.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F002.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F004.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F006.png`
  - `reference_resource_design/quake/frames/3b0608e170634d34a96f0f516827d7a8_F007.png`
- hit/0: `reference_resource_design/quake/source/a92a2168b9254a9eb29f1fe2f8ce1460.gif` / SHA-256 `d050152fd42d2a7038ef6d57f04cf916c7222bae7ef5ff55dff640a246c24dab`
  전체 연속 PNG 6장과 GIF 타이밍은 `reference_resource_design/quake/SOURCE.json`의 frames/duration_ms 목록에 있다. 대표 관찰 프레임:
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F000.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F001.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F003.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F004.png`
  - `reference_resource_design/quake/frames/a92a2168b9254a9eb29f1fe2f8ce1460_F005.png`
- icon: `reference_resource_design/quake/source/e3546d827b934bdb811649349501439f.png` / SHA-256 `5c78fd7e65cd2388f9208f0aa77d1489ac413f02b8f1234f2bacce3c6f062a49`

## AREA00 마감 실제 입력
이 PNG들은 기존 패키지에 들어 있던 AREA00 수정 후보의 마감 자료다. 기존 파일 바이트를 유지했다. 사용자가 승인한 00의 품질을 기준으로 삼되 새 결과의 합격을 미리 보장하지 않는다.
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/selected_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`
- `global_skill_style_library/area00_finish_baseline/icons/002_m_blue_snail_s_mon_blue_snail_ICON.png`

## 이 스킬 생성 순서
1. MONSTER_IMAGE + 위 공식 연속 프레임 + AREA00 VFX를 실제 입력한다. 한 호출에 여러 몬스터를 섞지 않는다.
2. RUNTIME_ROLE_MAP의 필수 VFX가 있으면 고정 축에서 준비→성장→절정→해체→fade를 명세 수량과 간격으로 만든다. ICON-only면 이 단계는 NOT_APPLICABLE이다.
3. ICON은 고정 아이콘 모티브를 사용한다. 공식 ICON의 명암 압축을 관찰하고 완성 VFX와 같은 소재로 그린다. 참조의 UI 테두리·숫자·문자·캐릭터는 새 자산에 넣지 않는다.
4. 최종 파일의 소재·실루엣·재질·방향·축·알파를 실제 비교한다. 파일 검사 PASS와 아트 PASS를 분리하고 실제 호출에 넣지 않은 이미지에 INPUT_USED=true를 쓰지 않는다.

## AREA00 전체 연속 마감 이미지

아래 전 프레임을 실제로 보아 형태 변화와 두께·광량의 흐름을 비교한다. 새 스킬의 소재·크기·동작은 GENERATION_SPEC를 따른다.
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F00.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F01.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F02.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F03.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F04.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F05.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F06.png`
- `global_skill_style_library/area00_finish_baseline/full_vfx_frames/002_m_blue_snail_파란_달팽이/002_m_blue_snail_s_mon_blue_snail_F07.png`

## 제작 호출에 바로 사용할 준비 보드

- 실제 몬스터: `monsters/004_m_ancient_dark_golem_에인션트_다크골렘/MONSTER_IMAGE.png` / SHA-256 `9caac00e345cd8f2aa0e039e94a39cb4a945f3304951a0b0354743d0220f23b4`
- 공식 VFX 다단계 보드: `reference_resource_design/prepared_boards/s_mon_ancient_dark_golem_OFFICIAL_VFX_BOARD.png` / SHA-256 `11fb7b91e2ab9a4b47c837a15b6dd9c5231b1df6cb5a2ba2550275679f691d60`
- 승인 AREA00 마감·ICON 보드: `reference_resource_design/prepared_boards/s_mon_ancient_dark_golem_AREA00_FINISH_BOARD.png` / SHA-256 `c250e2838a0f2fbed1f0d739a6f0ce68b89812b51385ef33420028921cb84912`
- 구성 원본·타일·해시: `reference_resource_design/prepared_boards/s_mon_ancient_dark_golem_BOARD_MANIFEST.json`

이 세 이미지를 해당 스킬 생성의 실제 reference input으로 전달한다. 회색 바탕·격자·참조 고유 소재는 결과에 넣지 않는다. 여러 스킬을 한 번에 생성하지 않는다.
