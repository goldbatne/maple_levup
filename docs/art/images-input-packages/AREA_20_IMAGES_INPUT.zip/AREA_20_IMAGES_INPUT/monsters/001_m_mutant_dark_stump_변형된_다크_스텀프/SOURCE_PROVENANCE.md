# Source provenance — 변형된 다크 스텀프 / 뒤틀린 고목의 껍질

- rebuild run: `20260913_153134`
- base package: `AREA_20_IMAGES_INPUT.zip`
- base package SHA-256: `41726ac492bc6725150cf9204146804acd29b8024f14a9a64eac2f3601c4d249`
- preserved manifest monster image RUID: `9b09382f4ba6483eb11a931f49a68f9b`
- preserved monster image status: `확보`
- preserved ids: `m_mutant_dark_stump` / `s_mon_mutant_dark_stump`
- preserved WHAT: `뒤틀린 고목의 껍질` / `패시브` / `보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2` / `현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시`
- MONSTER_IMAGE.png was copied byte-for-byte from the base canonical package.
- current game data files were not edited or asserted as Maker-registered by this rebuild.
- style references were added from the official MSW resource search website/API and the actual AREA 00 refined candidate; they do not replace the preserved WHAT.
