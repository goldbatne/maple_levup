# Monster Reference — 변형된 다크 스텀프

- 작업 순번: 001
- level: 191
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_dark_stump`
- model_id: `mutantdarkstump`
- image RUID: `9b09382f4ba6483eb11a931f49a68f9b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_dark_stump`
- skill name/type: 뒤틀린 고목의 껍질 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.
