# AREA_07 Images Input Manifest — V2

- Area: `area_07` / 슬리피우드
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 6종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 61 | `m_zombie_mushroom` | 좀비버섯 | `s_mon_zombie_mushroom` | 죽은 포자의 끈기 | 패시브 | N |
| 2 | 63 | `m_copper_drake` | 카파 드레이크 | `s_mon_copper_drake` | 청동 비늘 | 패시브 | N |
| 3 | 65 | `m_drake` | 드레이크 | `s_mon_drake` | 동굴 용염 | 액티브 | N |
| 4 | 68 | `m_wild_kargo` | 와일드카고 | `s_mon_wild_kargo` | 야수의 그림자 돌진 | 액티브 | N |
| 5 | 70 | `m_jr_balrog` | 주니어 발록 | `s_mon_jr_balrog` | 발록의 화염 파동 | 액티브 | Y |
| 6 | 70 | `m_tauromacis` | 타우로마시스 | `s_mon_tauromacis` | 수문장의 낙뢰 | 액티브 | N |
