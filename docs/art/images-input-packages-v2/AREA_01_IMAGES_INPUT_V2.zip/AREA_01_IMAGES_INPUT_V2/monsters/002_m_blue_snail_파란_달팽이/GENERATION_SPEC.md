# GENERATION SPEC — 파란 달팽이 / 푸른 껍질

## 확정 데이터

- 작업 순번: 002
- 레벨: 3
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_blue_snail`
- 몬스터 이름: 파란 달팽이
- monster image RUID: `0c69164656d24f64bd1a1f6ee4019dff`
- skill_id: `s_mon_blue_snail`
- 최종 스킬 이름: **푸른 껍질**
- 스킬 타입: **버프**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: 자신에게 3초 동안 피해 40% 감소
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.85/0.7초

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 파란 달팽이의 모델 ID·RUID와 메이플 아일랜드·리스항구 | 헤네시스 근교 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 겹친 껍질 결을 닮은 반원형 보호막과 짧은 반사광. ‘파란 달팽이 / 푸른 껍질’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 푸른 껍질 청색 #4E9EDB; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 물빛 백청 #C9F4FF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 진행 방향·엔진 이동: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다. layer drift는 엔진 적용: L1 ruid=566b0886b4cf4f3997a29ecd3a1954b5, type=animationclip, style=clip, delay=0s, duration=0.85s, scale=0.65, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.7s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 자신만 감싼다. 다른 대상, 타격점, 공격 폭발은 표시하지 않는다.
- 화면 점유율: 중소형(캐릭터 중심 0.8~1.2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음~중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 시전자 둘레 윤곽 출현 → 보호 구조 닫힘 → 반사광 절정 → 실드 지속과 혼동되지 않게 짧게 페이드.
- 판정 정렬: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘푸른 껍질 아치’, 보조 효과 1개는 ‘흰 반사광’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BUFF_SELF`
- VFX: 8 frames, 각 256×256 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 판정/재생: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 방향: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다.
- 현재 리소스: L1 ruid=566b0886b4cf4f3997a29ecd3a1954b5, type=animationclip, style=clip, delay=0s, duration=0.85s, scale=0.65, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.7s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 256×256 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

