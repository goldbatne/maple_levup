# Runtime Role Map — m_snail / s_mon_snail_dew_trail

- 역할: APPROVED_REUSE_CAST_VFX=AREA 00 승인 AnimationClip 재사용; ICON=AREA 00 승인 UI 아이콘 재사용
- 발생 위치: AREA 00 반입 보고서에서 플레이어 좌·우 방향 및 몬스터 시전자 재생을 검증했다. 현재 작업 트리의 SkillTable 원본 행이 삭제되어 세부 offset은 새 값으로 확정하지 않는다.
- 판정/재생: 승인 기록 기준 8프레임 × 0.1초, 총 0.8초 one-shot. 피해 판정 시점은 현재 삭제된 SkillTable 행을 추정하지 않는다.
- 방향: 승인 런타임 기록의 좌우 재생을 그대로 재사용한다. 새 이미지 내부 이동·recenter·Flip 규칙을 추가하지 않는다.
- 현재 승인 리소스: AnimationClip `6097484d513a4fde82ad15557fdc81d3` / ICON `c0699b32529049c68de3d13022479bf9`
- 필요 파일:
  - approved_reuse/AREA_00 아래에 포함된 승인 F00... 프레임과 ICON을 바이트 그대로 사용
  - 신규 VFX/ICON 생성 금지; AREA 00 승인 에셋과 해시가 다르면 재사용 중단
- 좌표 단위: 현재 삭제된 SkillTable 행 때문에 새 좌표·크기 값을 만들지 않는다. 승인 적용값을 유지한다.
- 반복: 승인 AnimationClip은 one-shot. 재사용 정책은 동일 monster_id + skill_id에만 적용한다.
