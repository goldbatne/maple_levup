# AREA_01 Images Input Manifest — V2

- Area: `area_01` / 헤네시스 근교
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: m_adv_hero
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 1 | `m_snail` | 달팽이 | `s_mon_snail_dew_trail` | 이슬 미끄럼길 | 액티브 | N |
| 2 | 3 | `m_blue_snail` | 파란 달팽이 | `s_mon_blue_snail` | 푸른 껍질 | 버프 | N |
| 3 | 5 | `m_mushroom` | 주황 버섯 | `s_mon_mushroom` | 포자 살포 | 액티브 | N |
| 4 | 10 | `m_mushmom` | 머쉬맘 | `s_mon_mushmom` | 머쉬맘의 포자 충격 | 액티브 | Y |
| 5 | 12 | `m_horny_mushroom` | 뿔버섯 | `s_mon_horny_mushroom` | 단단한 뿔 | 패시브 | N |
