# AREA_13 Images Input Manifest — V2

- Area: `area_13` / 니할 사막
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 121 | `m_white_sand_rabbit` | 흰 모래토끼 | `s_mon_white_sand_rabbit` | 사막 굴착탄 | 액티브 | N |
| 2 | 123 | `m_scarf_plead` | 목도리 프릴드 | `s_mon_scarf_plead` | 목도리의 사막감각 | 패시브 | N |
| 3 | 125 | `m_meercat` | 미요캐츠 | `s_mon_meercat` | 미요캐츠의 모래매복 | 액티브 | N |
| 4 | 128 | `m_sand_dwarf` | 모래난쟁이 | `s_mon_sand_dwarf` | 사막 대장장이의 체력 | 패시브 | N |
| 5 | 130 | `m_deo` | 데우 | `s_mon_deo` | 잠든 선인장의 폭발 | 액티브 | Y |
