# Runtime Role Map — m_meercat / s_mon_meercat

- 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 판정/재생: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 방향: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다.
- 현재 리소스: L1 ruid=412bce166c844b07ba1b4aa3ddcd53fa, type=animationclip, style=clip, delay=0s, duration=0.74s, scale=0.9, offset=(0,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
