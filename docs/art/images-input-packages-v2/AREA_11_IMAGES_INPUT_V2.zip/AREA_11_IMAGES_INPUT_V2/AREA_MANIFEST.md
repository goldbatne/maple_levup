# AREA_11 Images Input Manifest — V2

- Area: `area_11` / 루더스 호수
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 101 | `m_ratz` | 라츠 | `s_mon_ratz` | 태엽쥐의 민첩 | 패시브 | N |
| 2 | 103 | `m_drumming_bunny` | 북치는 토끼 | `s_mon_drumming_bunny` | 태엽 북진동 | 액티브 | N |
| 3 | 105 | `m_bloctopus` | 블록퍼스 | `s_mon_bloctopus` | 블록 위장 | 패시브 | N |
| 4 | 108 | `m_king_bloctopus` | 킹 블록퍼스 | `s_mon_king_bloctopus` | 왕관 블록탄 | 액티브 | N |
| 5 | 110 | `m_rombot` | 롬바드 | `s_mon_rombot` | 에오스 중력파 | 액티브 | Y |
