# GENERATION SPEC — 롬바드 / 에오스 중력파

## 확정 데이터

- 작업 순번: 005
- 레벨: 110
- Area: `area_11` / 루더스 호수
- monster_id: `m_rombot`
- 몬스터 이름: 롬바드
- monster image RUID: `b41def4288404055b3b8850daa99cfbf`
- skill_id: `s_mon_rombot`
- 최종 스킬 이름: **에오스 중력파**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 실제 현재 효과: ATK 계수 3.8로 반경 6 범위 대상 제한 없음 피해; 9초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.72/0.8초

## 원작/지역 연결

[P][A] 롬바드와 에오스탑은 연결되나 ‘중력파’ 능력은 확인되지 않았다.

## 시각 번역

- 핵심 소재: 에오스 톱니 코어가 공간을 아래로 휘게 하는 중력 고리. ‘롬바드 / 에오스 중력파’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 기계 철회 #5E6873; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 중력 보라 #7654A5; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=91c5d5dd661e4e079271b4446f7eb262, type=animationclip, style=clip, delay=0s, duration=0.72s, scale=1.1, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=06bbe7d534094761b54b147f3a79ca38, type=animationclip, style=clip, delay=0.18s, duration=0.8s, scale=0.8, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 큼(캐릭터 2~3배, 화면을 가리지 않음); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 높음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘톱니 코어’, 보조 효과 1개는 ‘눌린 중력 고리’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BOSS_ACTIVE`
- VFX: 12 frames, 각 512×512 RGBA PNG, 약 0.08 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 판정/재생: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 방향: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다.
- 현재 리소스: L1 ruid=91c5d5dd661e4e079271b4446f7eb262, type=animationclip, style=clip, delay=0s, duration=0.72s, scale=1.1, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=06bbe7d534094761b54b147f3a79ca38, type=animationclip, style=clip, delay=0.18s, duration=0.8s, scale=0.8, offset=(0,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 12 frames × 512×512 RGBA, 0.08s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

