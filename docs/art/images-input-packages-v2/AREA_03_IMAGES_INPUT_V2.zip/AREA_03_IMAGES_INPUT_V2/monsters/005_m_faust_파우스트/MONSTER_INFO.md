# Monster Reference — 파우스트

- 작업 순번: 005
- level: 20
- Area: `area_03` / 엘리니아
- monster_id: `m_faust`
- model_id: `faust`
- image RUID: `9922e94142f9413aa5359297f852a5a2`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_faust`
- skill name/type: 저주의 인형 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Faust.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `f63eb17a6ef230009335f5595e5373b700ce82831274c8273307aea0cef835d4`
- image: 320×240 RGBA / alpha 0~255 / bbox [83, 0, 237, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
