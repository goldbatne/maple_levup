# Runtime Role Map — m_faust / s_mon_faust

- 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 판정/재생: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 방향: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지).
- 현재 리소스: L1 ruid=22444db0645d47f48f300f36b3d90e4b, type=animationclip, style=clip, delay=0s, duration=0.9s, scale=0.55, offset=(0,0.1) world unit, drift=(0,0) world unit/s; L2 ruid=9051254fb84a4a898f3d99a213a896ec, type=animationclip, style=clip, delay=0.18s, duration=0.75s, scale=0.7, offset=(0,0.05) world unit, drift=(0,0) world unit/s; projectile_ruid=49b21aaa1d574ba787149841a31bf1a5
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 12 frames × 512×512 RGBA, 0.08s/frame
  - PROJECTILE: 현행 projectile_ruid를 그대로 유지하며 이번 V2 신규 생성 범위에는 포함하지 않음
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
