# Monster Reference — 다크 스텀프

- 작업 순번: 002
- level: 13
- Area: `area_03` / 엘리니아
- monster_id: `m_dark_stump`
- model_id: `darkstump`
- image RUID: `ed3908e24d694bb786023fc1ed073489`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_stump`
- skill name/type: 단단한 밑동 / 버프

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/DarkStump.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `8c18f5d77891a73e4b8c0d44703ebf3adfba3ba07e5cc4455066a81d4610c963`
- image: 320×240 RGBA / alpha 0~255 / bbox [14, 0, 306, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
