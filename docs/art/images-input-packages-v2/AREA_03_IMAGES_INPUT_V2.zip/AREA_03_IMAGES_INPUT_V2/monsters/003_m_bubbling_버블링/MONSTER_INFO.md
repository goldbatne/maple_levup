# Monster Reference — 버블링

- 작업 순번: 003
- level: 15
- Area: `area_03` / 엘리니아
- monster_id: `m_bubbling`
- model_id: `bubbling`
- image RUID: `e24531def0ec4687b2c5de2cfb32b02e`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_bubbling`
- skill name/type: 물방울 마력 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Bubbling.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `c98a05167fe02da612a0dc0dde72abe2e04ed333709cdad93c86983e2ed0f0e7`
- image: 320×240 RGBA / alpha 0~255 / bbox [6, 12, 279, 228]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
