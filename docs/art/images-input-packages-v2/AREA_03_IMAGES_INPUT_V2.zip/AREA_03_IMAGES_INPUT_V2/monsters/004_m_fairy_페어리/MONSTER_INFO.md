# Monster Reference — 페어리

- 작업 순번: 004
- level: 18
- Area: `area_03` / 엘리니아
- monster_id: `m_fairy`
- model_id: `fairy`
- image RUID: `1ed0265245594bf0904ceb88ecaf16ba`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_fairy`
- skill name/type: 요정의 마법가루 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Fairy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `288b2e3417bffd9353d4663e21029e34239191987804195a89a0d7cae7306da9`
- image: 320×240 RGBA / alpha 0~255 / bbox [61, 32, 259, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
