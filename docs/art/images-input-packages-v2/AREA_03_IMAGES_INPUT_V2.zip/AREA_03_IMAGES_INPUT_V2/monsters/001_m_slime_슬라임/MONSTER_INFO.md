# Monster Reference — 슬라임

- 작업 순번: 001
- level: 11
- Area: `area_03` / 엘리니아
- monster_id: `m_slime`
- model_id: `slime`
- image RUID: `50faf654ee5d479cb2958edce9feaef0`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_slime`
- skill name/type: 끈적한 몸통 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Slime.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `7d64e45d56e3965fb6b2af20a180e9f1e052210463406ef04bc91e1ebd447036`
- image: 320×240 RGBA / alpha 0~255 / bbox [7, 4, 276, 236]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
