# AREA 00 승인 에셋 재사용

아래 파일은 AREA 00 승인 OUTPUT의 바이트 복사본이다. 호환되는 동일 monster_id + skill_id에만 재사용하며 다시 생성하지 않는다.

## m_slime / s_mon_slime

- source: `docs/art/area00-images-output/AREA_00_IMAGES_OUTPUT/monsters/005_m_slime_슬라임`
- files:
  - `approved_reuse/AREA_00/005_m_slime_슬라임/ICON/005_m_slime_s_mon_slime_ICON.png` — SHA-256 `c4deb5eb4a24ea52d0e79ee12d2d9d73156ccc70de448cf5c902f7cfe1470b90`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/005_m_slime_s_mon_slime_CONTACT_PREVIEW.png` — SHA-256 `eaf30f54bbf6d0ab62ef79c0a245183592d6710f7a40c909669e48d2db42f4f6`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/labeled_preview.png` — SHA-256 `95346e5e52a19d71fe3af7f147e73802c9eae2d53255bc9475b143dec39635ce`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F00.png` — SHA-256 `8ea04631a8e2c5dda4644971dff0da46374f0516107a6c4078a22ed49eb84932`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F01.png` — SHA-256 `a77604fc3e50d5c9fdf674f58e6e1c57cb0cf8339b88450916e15c8b1833854c`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F02.png` — SHA-256 `ede62a4e5c2af755bf5a5bc759b33ab174bc95764b296a2c5bae4bcacd3e8fef`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F03.png` — SHA-256 `7cb6d63a2e7a22ff318eb2349445368849f079f6bfbdcc6b4d85faffe8c388a0`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F04.png` — SHA-256 `142c9cb3c8fa789b4879c1ada3acf47e3da5fd019874363eb394a9d6582f3b4b`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F05.png` — SHA-256 `21fb25a7fd72d26a6b3957326d232c4282d5c2018072a44907d0516d7bee63ca`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F06.png` — SHA-256 `d39b9691e36c96e2d79d8d1bff5d2168f4938a571b6f56b6a0ec6aa0bd225db3`
  - `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F07.png` — SHA-256 `3ef9a4d717b38c5f0755081303dab9fee17828fd647429da314c8eccb905f348`
