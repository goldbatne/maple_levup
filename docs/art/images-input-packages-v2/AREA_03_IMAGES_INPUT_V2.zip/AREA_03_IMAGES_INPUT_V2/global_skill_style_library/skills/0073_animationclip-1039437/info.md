# animationclip-1039437

- RUID: `5bc3cb66370a45ae9ba7349672a7cf2b`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: mixed/unknown
- 프리뷰: 확보
- 사용 연결: -:공식 검색 후보: 초보자 스킬:supplementary_search

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
