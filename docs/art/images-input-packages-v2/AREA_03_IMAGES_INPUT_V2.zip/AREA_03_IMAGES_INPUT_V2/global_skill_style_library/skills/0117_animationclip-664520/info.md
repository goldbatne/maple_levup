# animationclip-664520

- RUID: `997628810df4448f9e534bc426d6794a`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: dash
- 프리뷰: 확보
- 사용 연결: s_mon_axe_stump:도끼 휘두르기:layer_ruids; s_mon_red_snail:붉은 껍질 돌진:layer_ruids; s_mon_skeleton_commander:뼈 무덤:layer_ruids; s_mon_snail:몸통 박치기:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
