# 에인션트 다크골렘

- RUID: `3803b5c17bf04b56bef115b3afbf388b`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: impact/explosion
- 프리뷰: 확보
- 사용 연결: s_mon_ancient_dark_golem:고대 암흑 지진:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
