# sprite-8932807

- RUID: `dcfc97ad90e146d08a46225082ae590b`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: icon
- 프리뷰: 확보
- 사용 연결: s_mon_stirge:밤의 감각:icon_ruid

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
