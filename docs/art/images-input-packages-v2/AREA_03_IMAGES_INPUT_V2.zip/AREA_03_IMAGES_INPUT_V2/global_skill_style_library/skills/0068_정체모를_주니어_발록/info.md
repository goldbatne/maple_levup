# 정체모를 주니어 발록

- RUID: `5638984319fd476ca3d89e2aaca7f32a`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: wave/area
- 프리뷰: 확보
- 사용 연결: s_mon_drake:동굴 용염:layer_ruids; s_mon_jr_balrog:발록의 화염 파동:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
