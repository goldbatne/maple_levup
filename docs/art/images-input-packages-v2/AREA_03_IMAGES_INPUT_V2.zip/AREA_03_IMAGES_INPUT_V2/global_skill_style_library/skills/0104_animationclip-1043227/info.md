# animationclip-1043227

- RUID: `86734a2715504c10b1e50ae810609e25`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: impact/explosion
- 프리뷰: 확보
- 사용 연결: s_mon_blue_snail:푸른 껍질:layer_ruids; s_mon_mushmom:머쉬맘의 포자 충격:layer_ruids; s_mon_stone:암석 피부:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
