# 블러드 하프

- RUID: `518e72a0592d48b3b3e451be46a4f39e`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: layered VFX
- 프리뷰: 확보
- 사용 연결: s_mon_blood_harp:핏빛 깃울림:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
