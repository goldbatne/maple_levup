# animationclip-661888

- RUID: `67a9ec7922374ed79f28d6bb3096aff4`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **RECENT_SECONDARY**
- 시기 근거: 6차/HEXA 의미 검색 후보; 정확한 스킬명·출시일 미확인
- 시기 확신도: LOW
- 효과 계열: mixed/unknown
- 프리뷰: 확보
- 사용 연결: -:공식 검색 후보: HEXA 스킬:supplementary_search

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
