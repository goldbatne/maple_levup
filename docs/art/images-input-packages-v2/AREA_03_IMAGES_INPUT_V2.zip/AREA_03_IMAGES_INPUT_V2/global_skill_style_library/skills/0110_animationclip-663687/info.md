# animationclip-663687

- RUID: `8b26a0cdb63d455e82d1ca0fddf5e139`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **LEGACY_REFERENCE**
- 시기 근거: 프로젝트 T16-3a의 모험가 계보 자료; 자산 자체 개정일 미확인
- 시기 확신도: MEDIUM
- 효과 계열: layered VFX
- 프리뷰: 확보
- 사용 연결: s_hero_02:브랜디쉬:effect_ruid

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
