# 푸른 껍질

- RUID: `73c1bdafcb7e42bc8db0041883226449`
- 출처: 프로젝트 보존 원본/반입 프레임
- 스타일 우선순위: **LEGACY_REFERENCE**
- 시기 근거: 프로젝트 T20/T32/T37 직접 제작 아이콘 기록
- 시기 확신도: HIGH_PROJECT_ONLY
- 효과 계열: icon
- 프리뷰: 확보
- 사용 연결: s_mon_blue_snail:푸른 껍질:icon_ruid

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.
