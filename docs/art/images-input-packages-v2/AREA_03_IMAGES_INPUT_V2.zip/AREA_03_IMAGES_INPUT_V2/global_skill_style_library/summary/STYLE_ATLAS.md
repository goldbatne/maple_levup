# Global Style Atlas — 검증된 역할과 시기 불확실성

## 코퍼스 범위

- 수집된 고유 RUID: 183개. 현재 프로젝트 시각 필드와 공식 검색 보조 후보의 합집합이며 메이플 전체 스킬 전수 자료가 아니다.
- 스타일 분류: RECENT_PRIMARY 0 / RECENT_SECONDARY 19 / LEGACY_REFERENCE 41 / UNKNOWN 108 / EXCLUDE_STYLE 15.
- 역할 분류: VFX 105 / ICON 40 / MONSTER_CHARACTER 10 / SCENE 5 / UNCONFIRMED 23.

## 사용 원칙

1. WHAT은 GENERATION_SPEC의 확정 데이터이며 변경하지 않는다.
2. RECENT_PRIMARY는 검증 가능한 출시 시기·버전 근거가 있을 때만 최신 우선으로 사용한다.
3. RECENT_SECONDARY는 6차/HEXA 검색 후보일 뿐 최신성이 검증되지 않았다. RECENT_PRIMARY가 비어도 자동 승격하지 않는다.
4. UNKNOWN/LEGACY_REFERENCE는 비교·보조용이다. 파일 다운로드 시각은 아트 제작·업데이트 시각이 아니다.
5. `role_classification=VFX`인 프리뷰에서만 효과의 선·명암·알파 가장자리·파편 밀도를 참고한다.
6. `MONSTER_CHARACTER`, `SCENE`, `EXCLUDE_STYLE`은 신규 VFX 외형 레퍼런스로 쓰지 않는다. 효과와 본체가 함께 있으면 효과 영역의 렌더링만 참고하고 캐릭터·무기·고유 실루엣은 가져오지 않는다.
7. 아이콘은 대표 실루엣 1개 + 보조 효과 1개를 작은 크기에서 읽히게 한다.

## 공통 렌더링 문법

- 어두운 외곽 → 중간톤 형상 → 제한된 밝은 코어의 단계가 읽혀야 한다.
- 발광·반투명 레이어는 형태를 지우지 않는 범위에서 사용한다.
- 프레임은 준비 → 상승 → 절정 → 소멸을 따르되, 패시브 참고 모티브에는 공격 절정을 강제하지 않는다.
- 중심축과 알파 가장자리를 안정적으로 유지한다.
