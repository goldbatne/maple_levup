# AREA_03 Images Input Manifest — V2

- Area: `area_03` / 엘리니아
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: m_adv_bowmaster
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 11 | `m_slime` | 슬라임 | `s_mon_slime` | 끈적한 몸통 | 액티브 | N |
| 2 | 13 | `m_dark_stump` | 다크 스텀프 | `s_mon_dark_stump` | 단단한 밑동 | 버프 | N |
| 3 | 15 | `m_bubbling` | 버블링 | `s_mon_bubbling` | 물방울 마력 | 패시브 | N |
| 4 | 18 | `m_fairy` | 페어리 | `s_mon_fairy` | 요정의 마법가루 | 액티브 | N |
| 5 | 20 | `m_faust` | 파우스트 | `s_mon_faust` | 저주의 인형 | 액티브 | Y |
