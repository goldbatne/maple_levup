# Monster Reference — 큐브슬라임

- 작업 순번: 001
- level: 131
- Area: `area_14` / 마가티아
- monster_id: `m_cube_slime`
- model_id: `cubeslime`
- image RUID: `e93e27480f1043ef8e51fa3b0906a4d9`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_cube_slime`
- skill name/type: 연금 큐브막 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/CubeSlime.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `cc82eda2f347c91dd7403be132f8eb05f9fde4d9ebb9126780493643b4796dc8`
- image: 320×240 RGBA / alpha 0~255 / bbox [33, 11, 288, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
