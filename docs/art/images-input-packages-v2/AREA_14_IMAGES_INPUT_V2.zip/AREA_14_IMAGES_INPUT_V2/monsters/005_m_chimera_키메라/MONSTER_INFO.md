# Monster Reference — 키메라

- 작업 순번: 005
- level: 140
- Area: `area_14` / 마가티아
- monster_id: `m_chimera`
- model_id: `chimera`
- image RUID: `3f5236d28b1f409797fe7c4b48743b8a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_chimera`
- skill name/type: 융합체의 산성 포격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Chimera.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `1f224672a6a93e181bfdde11201b19aea4d372efc189844a58e314ea7c66ea8a`
- image: 320×240 RGBA / alpha 0~255 / bbox [63, 0, 255, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
