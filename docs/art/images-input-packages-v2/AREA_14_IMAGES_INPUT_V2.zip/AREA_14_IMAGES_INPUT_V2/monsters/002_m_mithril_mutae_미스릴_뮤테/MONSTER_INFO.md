# Monster Reference — 미스릴 뮤테

- 작업 순번: 002
- level: 133
- Area: `area_14` / 마가티아
- monster_id: `m_mithril_mutae`
- model_id: `mithrilmutae`
- image RUID: `b06abb18fb52476d8bc7bdd5e46abe19`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mithril_mutae`
- skill name/type: 미스릴 외피 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MithrilMutae.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `c4573d1bee1c0eaec034f102a9e71c7a078f7711b42fb6aaa3d26a99e97d0f56`
- image: 320×240 RGBA / alpha 0~255 / bbox [38, 13, 283, 235]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
