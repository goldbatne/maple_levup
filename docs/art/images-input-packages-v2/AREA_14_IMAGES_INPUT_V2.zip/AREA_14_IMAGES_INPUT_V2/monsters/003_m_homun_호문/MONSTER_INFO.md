# Monster Reference — 호문

- 작업 순번: 003
- level: 135
- Area: `area_14` / 마가티아
- monster_id: `m_homun`
- model_id: `homun`
- image RUID: `8f0fb531779d41738664009091d7b017`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_homun`
- skill name/type: 플라스크 독무 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Homun.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `3e35d4268077e95e997698b147c5d0a594c0e986bd07fc4b2940ab84636ffe65`
- image: 320×240 RGBA / alpha 0~255 / bbox [48, 10, 272, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
