# Monster Reference — 로이드

- 작업 순번: 004
- level: 138
- Area: `area_14` / 마가티아
- monster_id: `m_roid`
- model_id: `roid`
- image RUID: `364bc76e0cc3429ea8ca758319ec7678`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_roid`
- skill name/type: 알카드노 에너지탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Roid.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `cd549622a64af95f0e0c06bf0db5306c51011f818372d548f480577ab27c05f8`
- image: 320×240 RGBA / alpha 0~255 / bbox [86, 29, 217, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
