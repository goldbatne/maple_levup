# AREA_14 Images Input Manifest — V2

- Area: `area_14` / 마가티아
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 131 | `m_cube_slime` | 큐브슬라임 | `s_mon_cube_slime` | 연금 큐브막 | 패시브 | N |
| 2 | 133 | `m_mithril_mutae` | 미스릴 뮤테 | `s_mon_mithril_mutae` | 미스릴 외피 | 패시브 | N |
| 3 | 135 | `m_homun` | 호문 | `s_mon_homun` | 플라스크 독무 | 액티브 | N |
| 4 | 138 | `m_roid` | 로이드 | `s_mon_roid` | 알카드노 에너지탄 | 액티브 | N |
| 5 | 140 | `m_chimera` | 키메라 | `s_mon_chimera` | 융합체의 산성 포격 | 액티브 | Y |
