# AREA_10 Images Input Manifest — V2

- Area: `area_10` / 아쿠아로드
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 91 | `m_bubble_fish` | 버블피쉬 | `s_mon_bubble_fish` | 기포막 | 패시브 | N |
| 2 | 93 | `m_mask_fish` | 마스크피쉬 | `s_mon_mask_fish` | 가면 아래의 감각 | 패시브 | N |
| 3 | 95 | `m_squid` | 스퀴드 | `s_mon_squid` | 심해 먹물 폭발 | 액티브 | N |
| 4 | 98 | `m_shark` | 샤크 | `s_mon_shark` | 포식자의 수류탄 | 액티브 | N |
| 5 | 100 | `m_pianus` | 피아누스 | `s_mon_pianus` | 심해왕의 광선 | 액티브 | Y |
