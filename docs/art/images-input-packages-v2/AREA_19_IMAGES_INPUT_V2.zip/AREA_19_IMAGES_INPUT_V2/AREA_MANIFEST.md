# AREA_19 Images Input Manifest — V2

- Area: `area_19` / 미래의 문
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 181 | `m_official_knight_c` | 정식기사 C | `s_mon_official_knight_c` | 기사단 뇌전 연각 | 액티브 | N |
| 2 | 183 | `m_official_knight_d` | 정식기사 D | `s_mon_official_knight_d` | 기사단의 바람 조준 | 패시브 | N |
| 3 | 185 | `m_advanced_knight_a` | 상급기사 A | `s_mon_advanced_knight_a` | 그림자 기사의 민첩 | 패시브 | N |
| 4 | 188 | `m_advanced_knight_b` | 상급기사 B | `s_mon_advanced_knight_b` | 상급기사의 이프리트 화염 | 액티브 | N |
| 5 | 190 | `m_cygnus` | 시그너스 | `s_mon_cygnus` | 타락한 여제의 정원 | 액티브 | Y |
