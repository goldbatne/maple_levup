# GENERATION SPEC — 리본 돼지 / 리본 돌진

## 확정 데이터

- 작업 순번: 001
- 레벨: 41
- Area: `area_05` / 노틸러스
- monster_id: `m_ribbon_pig`
- 몬스터 이름: 리본 돼지
- monster image RUID: `6a699b8c31b94474bb795c7394c3af3b`
- skill_id: `s_mon_ribbon_pig`
- 최종 스킬 이름: **리본 돌진**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: ATK 계수 1.8로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5.5 거리 돌진
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.04초; 지속 0.52/0.65초; 시전자가 목표 방향으로 돌진

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 리본 돼지의 모델 ID·RUID와 노틸러스 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 분홍 리본 매듭이 전방으로 길게 풀리는 돌진 궤적. ‘리본 돼지 / 리본 돌진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 리본 분홍 #F38AA5; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 충돌 백분홍 #FFD6DF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 조준 8방향으로 5.5 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다. layer drift는 엔진 적용: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.52s, scale=0.55, offset=(-0.1,-0.05) world unit, drift=(0,0) world unit/s; L2 ruid=057c2da13da2492c95cb92db424803db, type=animationclip, style=clip, delay=0.04s, duration=0.65s, scale=0.58, offset=(0.2,0) world unit, drift=(0.9,0) world unit/s
- 대상 표현: 도착점 주변 피격 범위만 읽히게 하고 이동 경로 전체를 범위로 오인시키지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 도착점 압축 → 충돌 절정 → 파편/잔상 소멸. 출발부터 도착까지의 전신 이동을 시트 안에서 반복하지 않는다.
- 판정 정렬: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘분홍 리본 매듭’, 보조 효과 1개는 ‘전방 잔상’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 발생 위치: 플레이어는 조준 8방향으로 5.5 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 판정/재생: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 방향: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다.
- 현재 리소스: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.52s, scale=0.55, offset=(-0.1,-0.05) world unit, drift=(0,0) world unit/s; L2 ruid=057c2da13da2492c95cb92db424803db, type=animationclip, style=clip, delay=0.04s, duration=0.65s, scale=0.58, offset=(0.2,0) world unit, drift=(0.9,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

