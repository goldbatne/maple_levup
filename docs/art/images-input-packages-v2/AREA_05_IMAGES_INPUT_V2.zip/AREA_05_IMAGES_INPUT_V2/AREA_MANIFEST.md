# AREA_05 Images Input Manifest — V2

- Area: `area_05` / 노틸러스
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 41 | `m_ribbon_pig` | 리본 돼지 | `s_mon_ribbon_pig` | 리본 돌진 | 액티브 | N |
| 2 | 43 | `m_blue_pig` | 파란 리본돼지 | `s_mon_blue_pig` | 푸른 리본 매듭 | 패시브 | N |
| 3 | 45 | `m_starfish` | 불가사리 | `s_mon_starfish` | 별가시 회전 | 액티브 | N |
| 4 | 48 | `m_jellyfish` | 쿨 젤리피쉬 | `s_mon_jellyfish` | 차가운 젤리 | 패시브 | N |
| 5 | 60 | `m_king_clang` | 킹크랑 | `s_mon_king_clang` | 왕게의 집게 파도 | 액티브 | Y |
