# START HERE — area_16 미나르숲 V2

1. PACKAGE_REVISION과 AREA_MANIFEST에서 범위와 보류를 확인한다.
2. 각 MONSTER_INFO/SOURCE_PROVENANCE/GENERATION_SPEC/RUNTIME_ROLE_MAP을 읽는다.
3. MASTER_PROMPT와 OUTPUT 규격을 따른다.
4. MONSTER_IMAGE는 재생성하지 않고 Preview에 그대로 합성한다.
5. STYLE_INDEX의 역할/시기 불확실성을 지키며 RECENT_SECONDARY를 최신으로 자동 승격하지 않는다.
6. 주 납품물은 역할별 개별 RGBA PNG이고 시트는 선택 Preview다.
7. 출력 루트는 `AREA_16_IMAGES_OUTPUT/`이다.

금지: 스킬 기획·게임 데이터 변경, 리소스 등록, AnimationClip 변경, 이미지 생성 완료를 파일 없이 선언.
