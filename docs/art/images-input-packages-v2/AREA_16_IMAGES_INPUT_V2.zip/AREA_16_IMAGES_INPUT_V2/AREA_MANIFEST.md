# AREA_16 Images Input Manifest — V2

- Area: `area_16` / 미나르숲
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 151 | `m_harp` | 하프 | `s_mon_harp` | 하늘 둥지의 날갯결 | 패시브 | N |
| 2 | 153 | `m_blood_harp` | 블러드 하프 | `s_mon_blood_harp` | 핏빛 깃울림 | 액티브 | N |
| 3 | 155 | `m_blue_wyvern` | 블루 와이번 | `s_mon_blue_wyvern` | 빙룡 숨결 | 액티브 | N |
| 4 | 158 | `m_dark_wyvern` | 다크 와이번 | `s_mon_dark_wyvern` | 검은 비늘의 근력 | 패시브 | N |
| 5 | 160 | `m_manon` | 마뇽 | `s_mon_manon` | 마뇽의 용화염 | 액티브 | Y |
