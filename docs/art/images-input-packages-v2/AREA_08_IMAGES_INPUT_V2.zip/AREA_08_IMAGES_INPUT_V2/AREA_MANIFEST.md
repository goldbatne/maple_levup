# AREA_08 Images Input Manifest — V2

- Area: `area_08` / 오르비스
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 71 | `m_star_pixie` | 스타픽시 | `s_mon_star_pixie` | 별빛 탄환 | 액티브 | N |
| 2 | 73 | `m_jr_cellion` | 주니어 샐리온 | `s_mon_jr_cellion` | 붉은 뿔의 기백 | 패시브 | N |
| 3 | 75 | `m_lunar_pixie` | 루나픽시 | `s_mon_lunar_pixie` | 월광 구슬 | 액티브 | N |
| 4 | 78 | `m_luster_pixie` | 러스터픽시 | `s_mon_luster_pixie` | 태양빛 잔상 | 패시브 | N |
| 5 | 80 | `m_eliza` | 엘리쟈 | `s_mon_eliza` | 여신의 정원 폭풍 | 액티브 | Y |
