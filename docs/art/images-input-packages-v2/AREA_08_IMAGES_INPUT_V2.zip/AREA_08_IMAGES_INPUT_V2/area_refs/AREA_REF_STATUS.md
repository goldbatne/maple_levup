# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t64/orbis`
- 합성 대상: 00_cloud.png, 01_sky_marble.png, 02_star_path.png, 03_sky_void.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
