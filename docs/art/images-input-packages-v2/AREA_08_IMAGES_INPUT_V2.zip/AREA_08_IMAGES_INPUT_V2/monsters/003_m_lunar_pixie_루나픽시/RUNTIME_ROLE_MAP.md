# Runtime Role Map — m_lunar_pixie / s_mon_lunar_pixie

- 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 판정/재생: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 방향: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지).
- 현재 리소스: L1 ruid=e7ee1a40564c43afbced2da544471266, type=animationclip, style=clip, delay=0s, duration=0.68s, scale=0.8, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=6d96350411834e2b90a2fe18ff542159, type=animationclip, style=clip, delay=0.2s, duration=0.62s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s; projectile_ruid=4f6509d9539f4d76a9bb4e8f17e12cc7
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
  - PROJECTILE: 현행 projectile_ruid를 그대로 유지하며 이번 V2 신규 생성 범위에는 포함하지 않음
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
