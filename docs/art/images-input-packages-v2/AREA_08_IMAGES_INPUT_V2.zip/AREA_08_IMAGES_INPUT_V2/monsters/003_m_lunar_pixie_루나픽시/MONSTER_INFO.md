# Monster Reference — 루나픽시

- 작업 순번: 003
- level: 75
- Area: `area_08` / 오르비스
- monster_id: `m_lunar_pixie`
- model_id: `lunarpixie`
- image RUID: `ff4a57bc3d4a4488b0053c33f4c3369f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_lunar_pixie`
- skill name/type: 월광 구슬 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/LunarPixie.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `fe28647ddc88a00124b8adf0f10963ef019a7983b230cfd54df9bdaa75c84195`
- image: 320×240 RGBA / alpha 0~255 / bbox [42, 6, 272, 226]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
