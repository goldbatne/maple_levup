# GENERATION SPEC — 스타픽시 / 별빛 탄환

## 확정 데이터

- 작업 순번: 001
- 레벨: 71
- Area: `area_08` / 오르비스
- monster_id: `m_star_pixie`
- 몬스터 이름: 스타픽시
- monster image RUID: `ca136923b7e84267af993bdbabada385`
- skill_id: `s_mon_star_pixie`
- 최종 스킬 이름: **별빛 탄환**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: INT 계수 2.45로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.18초; 지속 0.62/0.58초; 투사체 b61e7e2a50b2405794f88fdddf44b73a가 목표 방향으로 이동

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 스타픽시의 모델 ID·RUID와 오르비스 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 작은 별핵이 꼬리별 잔상을 달고 직선으로 날아가는 탄. ‘스타픽시 / 별빛 탄환’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 별빛 황색 #FFE46A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 하늘 청색 #81BDEB; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 효과 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지). layer drift는 엔진 적용: L1 ruid=78e3188f0fc14797a8383658e626e3ea, type=animationclip, style=clip, delay=0s, duration=0.62s, scale=0.72, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=6ffbabe486c24e5ea6cda2c54022033b, type=animationclip, style=clip, delay=0.18s, duration=0.58s, scale=0.7, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 조준 지점은 그림에 캐릭터로 표시하지 않는다. 현재 전용 IMPACT 출력은 요구하지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: CAST는 발사 준비 → 방출 섬광 → 짧은 잔광. PROJECTILE은 동일 중심축에서 자체 회전/맥동만 하며 위치 이동은 엔진에 맡긴다.
- 판정 정렬: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘오각 별탄’, 보조 효과 1개는 ‘꼬리별 잔상’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 판정/재생: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 방향: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지).
- 현재 리소스: L1 ruid=78e3188f0fc14797a8383658e626e3ea, type=animationclip, style=clip, delay=0s, duration=0.62s, scale=0.72, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=6ffbabe486c24e5ea6cda2c54022033b, type=animationclip, style=clip, delay=0.18s, duration=0.58s, scale=0.7, offset=(0,0) world unit, drift=(0,0) world unit/s; projectile_ruid=b61e7e2a50b2405794f88fdddf44b73a
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
  - PROJECTILE: 현행 projectile_ruid를 그대로 유지하며 이번 V2 신규 생성 범위에는 포함하지 않음
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

