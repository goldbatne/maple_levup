# Monster Reference — 주니어 샐리온

- 작업 순번: 002
- level: 73
- Area: `area_08` / 오르비스
- monster_id: `m_jr_cellion`
- model_id: `jrcellion`
- image RUID: `016bc9a459104e2a8a2fea03d7130519`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_cellion`
- skill name/type: 붉은 뿔의 기백 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/JrCellion.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `f6afda60c0857052b3f96edad9bd2f6454b228aed81c3b208bf84d3fe1a431e2`
- image: 320×240 RGBA / alpha 0~255 / bbox [63, 0, 258, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
