# Monster Reference — 엘리쟈

- 작업 순번: 005
- level: 80
- Area: `area_08` / 오르비스
- monster_id: `m_eliza`
- model_id: `eliza`
- image RUID: `d458879e2e2949f2bb2e915ff67fbc64`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_eliza`
- skill name/type: 여신의 정원 폭풍 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Eliza.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `208c85c1a55bc850ec09e27c9e69b2bb5a199f21b7a2d4e5700a28a1265935ee`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 3, 320, 238]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
