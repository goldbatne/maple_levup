# Monster Reference — 러스터픽시

- 작업 순번: 004
- level: 78
- Area: `area_08` / 오르비스
- monster_id: `m_luster_pixie`
- model_id: `lusterpixie`
- image RUID: `35f555b27d3a4d438224a29e73fac305`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_luster_pixie`
- skill name/type: 태양빛 잔상 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/LusterPixie.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `570c0decec8c5fe2d2418140577af66d523d6ad51156fa4e0185682beba4b7d5`
- image: 320×240 RGBA / alpha 0~255 / bbox [42, 6, 272, 226]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
