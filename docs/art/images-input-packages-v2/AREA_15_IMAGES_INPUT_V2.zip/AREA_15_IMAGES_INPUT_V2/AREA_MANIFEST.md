# AREA_15 Images Input Manifest — V2

- Area: `area_15` / 무릉도원
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 141 | `m_straw_dummy` | 수련용 짚인형 | `s_mon_straw_dummy` | 짚단 균형감각 | 패시브 | N |
| 2 | 143 | `m_wooden_dummy` | 수련용 나무인형 | `s_mon_wooden_dummy` | 목인 회전타 | 액티브 | N |
| 3 | 145 | `m_peach_monkey` | 원공 | `s_mon_peach_monkey` | 천도 투척 | 액티브 | N |
| 4 | 148 | `m_blue_flower_serpent` | 청화사 | `s_mon_blue_flower_serpent` | 청화 비늘 | 패시브 | N |
| 5 | 150 | `m_tae_roon` | 태륜 | `s_mon_tae_roon` | 태륜의 쌍권풍 | 액티브 | Y |
