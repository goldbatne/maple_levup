# Output Naming Spec

출력 루트: `AREA_15_IMAGES_OUTPUT/`

## 필수 규칙

- 기본 CAST/REFERENCE VFX: `NNN_[monster_id]_[skill_id]_F00.png`, `F01.png` ...
- 별도 PROJECTILE이 필요한 경우: `NNN_[monster_id]_[skill_id]_PROJECTILE.png` 또는 명세가 다프레임으로 확정한 경우 `_PROJECTILE_F00.png` ...
- 아이콘: `NNN_[monster_id]_[skill_id]_ICON.png`
- 선택 Preview: `NNN_[monster_id]_[skill_id]_CONTACT_PREVIEW.png`
- NNN은 AREA_MANIFEST의 3자리 작업 순번이며 monster_id/skill_id를 축약·번역하지 않는다.
- 원본 생성 시트가 있으면 `SOURCE_SHEET/`에 보존하고 `SHEET_SPLIT_MANIFEST.csv`에 source_file, role, frame_index, x, y, width, height 열로 분할 좌표를 기록한다.
- 결과 manifest 열은 work_order, area_id, monster_id, monster_name, skill_id, skill_name, skill_type, role, file, width, height, mode, sha256, auto_validation, user_art_approval 순서다.

```text
AREA_15_IMAGES_OUTPUT/
├─ OUTPUT_MANIFEST.md
├─ OUTPUT_MANIFEST.csv
├─ SOURCE_SHEET/                 # 원본 시트가 있을 때
├─ SHEET_SPLIT_MANIFEST.csv      # 분할했을 때
└─ monsters/
   └─ NNN_[monster_id]_[name]/
      ├─ VFX/
      ├─ PROJECTILE/             # 명세에 필요할 때만
      ├─ ICON/
      ├─ PREVIEW/                # 선택
      └─ RESULT_INFO.md
```
