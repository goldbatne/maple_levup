# Monster Reference — 다크 주니어 예티

- 작업 순번: 002
- level: 83
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_dark_jr_yeti`
- model_id: `darkjryeti`
- image RUID: `ce56cf9613174f80976dab5b61f7b604`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_jr_yeti`
- skill name/type: 검은 설원의 은폐 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/DarkJrYeti.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `6be8a604b57658c8e0f9eaf21e6dc436ed45e353e3d760f9ba4bb37b9356d3a8`
- image: 320×240 RGBA / alpha 0~255 / bbox [33, 0, 287, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
