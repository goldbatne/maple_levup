# Monster Reference — 헥터

- 작업 순번: 003
- level: 85
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_hector`
- model_id: `hector`
- image RUID: `7dcc64a4725b4777b8f86a5404b4d4cc`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_hector`
- skill name/type: 설원 늑대 발톱 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Hector.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `5270a4554b0a2580ba3bd8894a63b9140e8b0ec51dc1d715904745da6447e706`
- image: 320×240 RGBA / alpha 0~255 / bbox [84, 59, 314, 185]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
