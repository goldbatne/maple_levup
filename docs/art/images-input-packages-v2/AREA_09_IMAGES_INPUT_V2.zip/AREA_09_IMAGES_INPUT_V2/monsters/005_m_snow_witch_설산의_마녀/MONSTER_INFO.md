# Monster Reference — 설산의 마녀

- 작업 순번: 005
- level: 90
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_snow_witch`
- model_id: `snowwitch`
- image RUID: `4b50438f59154f41aba918b2d28bb8d2`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_snow_witch`
- skill name/type: 추방자의 눈보라 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/SnowWitch.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `8488c15a9728d346caf34ffeec8a4c1d2971ae8a90d865c36f9fb206fe3dfe4f`
- image: 320×240 RGBA / alpha 0~255 / bbox [55, 0, 264, 235]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
