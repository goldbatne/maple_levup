# Monster Reference — 화이트팽

- 작업 순번: 004
- level: 88
- Area: `area_09` / 엘나스 산맥
- monster_id: `m_white_fang`
- model_id: `whitefang`
- image RUID: `aaa3b506804d4418b025da47dbb65b3f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_white_fang`
- skill name/type: 화이트팽의 빙설 송곳니 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/WhiteFang.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `71f7a01b9f3f910afceabad1784f8b8b9f2f4a78f0f9e49dc3ec4428ce3e57c4`
- image: 320×240 RGBA / alpha 0~255 / bbox [84, 59, 314, 185]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
