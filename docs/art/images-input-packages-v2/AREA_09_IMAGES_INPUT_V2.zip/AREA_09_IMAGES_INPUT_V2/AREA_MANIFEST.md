# AREA_09 Images Input Manifest — V2

- Area: `area_09` / 엘나스 산맥
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 81 | `m_jr_yeti` | 주니어 예티 | `s_mon_jr_yeti` | 설인의 체온 | 패시브 | N |
| 2 | 83 | `m_dark_jr_yeti` | 다크 주니어 예티 | `s_mon_dark_jr_yeti` | 검은 설원의 은폐 | 패시브 | N |
| 3 | 85 | `m_hector` | 헥터 | `s_mon_hector` | 설원 늑대 발톱 | 액티브 | N |
| 4 | 88 | `m_white_fang` | 화이트팽 | `s_mon_white_fang` | 화이트팽의 빙설 송곳니 | 액티브 | N |
| 5 | 90 | `m_snow_witch` | 설산의 마녀 | `s_mon_snow_witch` | 추방자의 눈보라 | 액티브 | Y |
