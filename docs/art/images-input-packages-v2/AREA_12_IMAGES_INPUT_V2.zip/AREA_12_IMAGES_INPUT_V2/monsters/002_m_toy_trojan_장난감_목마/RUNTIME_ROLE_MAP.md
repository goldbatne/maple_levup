# Runtime Role Map — m_toy_trojan / s_mon_toy_trojan

- 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 발생 위치: 플레이어는 조준 8방향으로 6.8 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 판정/재생: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 방향: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다.
- 현재 리소스: L1 ruid=fc4857ea48be477c9546c775e0f31d49, type=animationclip, style=clip, delay=0s, duration=0.7s, scale=0.72, offset=(0,0) world unit, drift=(1.0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
