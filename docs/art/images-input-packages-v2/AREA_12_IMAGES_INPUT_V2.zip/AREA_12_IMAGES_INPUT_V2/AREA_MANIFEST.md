# AREA_12 Images Input Manifest — V2

- Area: `area_12` / 루디브리엄
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 111 | `m_brown_teddy` | 브라운테니 | `s_mon_brown_teddy` | 솜인형 완충 | 패시브 | N |
| 2 | 113 | `m_toy_trojan` | 장난감 목마 | `s_mon_toy_trojan` | 태엽 목마 돌진 | 액티브 | N |
| 3 | 115 | `m_master_robo` | 마스터 로보 | `s_mon_master_robo` | 정밀 태엽회로 | 패시브 | N |
| 4 | 118 | `m_chronos` | 크로노스 | `s_mon_chronos` | 크로노스의 시간편린 | 액티브 | N |
| 5 | 120 | `m_timer` | 타이머 | `s_mon_timer` | 시간 정지 충격 | 액티브 | Y |
