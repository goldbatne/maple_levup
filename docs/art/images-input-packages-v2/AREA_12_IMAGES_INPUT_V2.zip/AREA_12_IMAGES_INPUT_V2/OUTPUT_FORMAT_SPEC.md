# Output Format Spec

## 원본 생성과 주 납품물

- 미술 원본을 시트로 생성했다면 **원본 시트와 분할 좌표 기록을 보존**한다.
- 주 납품물은 `F00`, `F01` ... 연속 번호의 **frame-separated RGBA PNG**다. contact/sprite sheet는 선택적 Preview이며 주 납품물을 대체하지 않는다.
- 각 역할(CAST_VFX, PROJECTILE, REFERENCE_VFX)은 GENERATION_SPEC의 `런타임 역할`과 `필요 파일`을 따른다. 서로 다른 역할을 한 시트에 섞지 않는다.
- 실제 배경 alpha가 있어야 한다. 흰색·검정·체커보드 배경, 빈 프레임, 셀 조각, 가장자리 잘림, 누락 프레임은 실패다.
- 동일 역할의 프레임은 캔버스·피봇·스케일이 같아야 한다. 임의 autocrop/recenter 금지.
- 우측 기준/FlipX 규칙은 GENERATION_SPEC를 따른다. 엔진 이동 PROJECTILE과 layer drift는 이미지 내부 전체 이동과 중복하지 않는다.
- ICON은 256×256 RGBA 1장이다. 글자·숫자·UI 프레임·몬스터 본체 전체 금지.
- 파일 자동검사 통과와 사용자 아트 승인은 별개다.

## 프로필 기준

기존 프로필의 프레임 수·캔버스·시간은 몬스터별 GENERATION_SPEC에 보존되어 있다. AREA 00 규격을 다른 스킬에 일괄 복사하지 않는다. 패시브 `REFERENCE_VFX`는 기존 제작 범위의 비전투 참고 산출물이며 런타임 연결 대상이 아니다.

출력 루트: `AREA_12_IMAGES_OUTPUT/`
