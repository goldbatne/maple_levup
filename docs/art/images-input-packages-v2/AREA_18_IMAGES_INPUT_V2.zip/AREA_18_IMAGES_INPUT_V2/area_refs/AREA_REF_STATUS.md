# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t67/omega`
- 합성 대상: 00_hq_steel.png, 01_warning_plate.png, 02_alien_circuit.png, 03_energy_trench.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
