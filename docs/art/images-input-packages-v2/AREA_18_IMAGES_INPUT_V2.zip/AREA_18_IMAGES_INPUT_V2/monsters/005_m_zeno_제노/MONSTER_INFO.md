# Monster Reference — 제노

- 작업 순번: 005
- level: 180
- Area: `area_18` / 지구방위본부
- monster_id: `m_zeno`
- model_id: `zeno`
- image RUID: `689bc520bc2544abb62ec505ca91aab4`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_zeno`
- skill name/type: 제노의 중력장 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Zeno.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `23403efbfe798399ecbc1e0d387af9c6f35f8155cb66d5b9b4553171dd55fb36`
- image: 320×240 RGBA / alpha 0~255 / bbox [48, 19, 273, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
