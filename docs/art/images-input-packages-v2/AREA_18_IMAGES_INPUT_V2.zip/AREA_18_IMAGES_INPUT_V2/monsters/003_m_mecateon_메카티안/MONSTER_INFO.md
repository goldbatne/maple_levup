# Monster Reference — 메카티안

- 작업 순번: 003
- level: 175
- Area: `area_18` / 지구방위본부
- monster_id: `m_mecateon`
- model_id: `mecateon`
- image RUID: `1509ce195a5c49a0aea5f9b189ce7edb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mecateon`
- skill name/type: 기계화 레이저 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Mecateon.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `5a64fe007c70fef4750f267ef87a1142eb78978535858bad33c79345bd404d50`
- image: 320×240 RGBA / alpha 0~255 / bbox [53, 17, 276, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
