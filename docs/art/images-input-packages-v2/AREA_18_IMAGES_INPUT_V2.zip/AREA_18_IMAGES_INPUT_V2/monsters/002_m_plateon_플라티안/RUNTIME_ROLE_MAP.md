# Runtime Role Map — m_plateon / s_mon_plateon

- 역할: ICON=런타임 필수; REFERENCE_VFX=기존 제작 범위에 포함된 비전투 참고 산출물(런타임 미사용·자동 반입 금지)
- 발생 위치: 런타임 시전자/발생점 없음. PlayerStats와 UI가 보유 수를 읽고 정액 스탯을 적용한다.
- 판정/재생: 피해 판정·시전·재생시간·반복 없음.
- 방향: 방향·FlipX·엔진 이동 없음.
- 현재 리소스: icon_ruid=thumbnail://e03cf5ce06784947b45ce95afb70927c
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - REFERENCE_VFX: 기존 명세 유지 6 frames × 256×256 RGBA; 런타임 미사용·자동 반입 금지
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
