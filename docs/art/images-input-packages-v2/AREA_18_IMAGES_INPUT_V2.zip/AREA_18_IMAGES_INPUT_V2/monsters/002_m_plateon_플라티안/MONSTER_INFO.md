# Monster Reference — 플라티안

- 작업 순번: 002
- level: 173
- Area: `area_18` / 지구방위본부
- monster_id: `m_plateon`
- model_id: `plateon`
- image RUID: `e03cf5ce06784947b45ce95afb70927c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_plateon`
- skill name/type: 외계 장갑 조종 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Plateon.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `40081edd846418035956ff6404e1546c23d50963e5173590fe997da4edb0576e`
- image: 320×240 RGBA / alpha 0~255 / bbox [72, 26, 248, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
