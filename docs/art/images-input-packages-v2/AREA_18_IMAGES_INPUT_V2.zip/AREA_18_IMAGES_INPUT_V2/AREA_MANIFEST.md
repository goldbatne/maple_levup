# AREA_18 Images Input Manifest — V2

- Area: `area_18` / 지구방위본부
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 171 | `m_mateon` | 마티안 | `s_mon_mateon` | 마티안 광선탄 | 액티브 | N |
| 2 | 173 | `m_plateon` | 플라티안 | `s_mon_plateon` | 외계 장갑 조종 | 패시브 | N |
| 3 | 175 | `m_mecateon` | 메카티안 | `s_mon_mecateon` | 기계화 레이저 | 액티브 | N |
| 4 | 178 | `m_chief_gray` | 원로 그레이 | `s_mon_chief_gray` | 원로의 정신연산 | 패시브 | N |
| 5 | 180 | `m_zeno` | 제노 | `s_mon_zeno` | 제노의 중력장 | 액티브 | Y |
