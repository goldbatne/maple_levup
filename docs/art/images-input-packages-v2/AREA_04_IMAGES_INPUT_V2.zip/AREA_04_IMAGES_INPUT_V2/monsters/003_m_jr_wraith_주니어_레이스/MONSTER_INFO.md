# Monster Reference — 주니어 레이스

- 작업 순번: 003
- level: 35
- Area: `area_04` / 커닝시티
- monster_id: `m_jr_wraith`
- model_id: `jrwraith`
- image RUID: `ca9fd4116b62417caebde864c675e026`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_wraith`
- skill name/type: 망령 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/JrWraith.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `3a88b1b657440feb530d84e99c38aa3ddd169f9de0a3b0a8d36626629566c369`
- image: 320×240 RGBA / alpha 0~255 / bbox [24, 0, 297, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
