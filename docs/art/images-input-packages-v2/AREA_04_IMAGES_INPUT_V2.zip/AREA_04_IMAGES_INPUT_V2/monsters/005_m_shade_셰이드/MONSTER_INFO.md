# Monster Reference — 셰이드

- 작업 순번: 005
- level: 40
- Area: `area_04` / 커닝시티
- monster_id: `m_shade`
- model_id: `shade`
- image RUID: `4f763744e0ac49469d2305e3c73254b7`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_shade`
- skill name/type: 심연의 장막 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Shade.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9d1c15ac5afa38c02069ccac361fa94663f58e128dab44980c9c08e9fb26aecc`
- image: 320×240 RGBA / alpha 0~255 / bbox [51, 15, 265, 216]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
