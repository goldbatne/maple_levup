# AREA_04 Images Input Manifest — V2

- Area: `area_04` / 커닝시티
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 31 | `m_octopus` | 옥토퍼스 | `s_mon_octopus` | 먹물 폭발 | 액티브 | N |
| 2 | 33 | `m_stirge` | 스티지 | `s_mon_stirge` | 밤의 감각 | 패시브 | N |
| 3 | 35 | `m_jr_wraith` | 주니어 레이스 | `s_mon_jr_wraith` | 망령 충격 | 액티브 | N |
| 4 | 38 | `m_wraith` | 레이스 | `s_mon_wraith` | 원혼의 기운 | 패시브 | N |
| 5 | 40 | `m_shade` | 셰이드 | `s_mon_shade` | 심연의 장막 | 액티브 | Y |
