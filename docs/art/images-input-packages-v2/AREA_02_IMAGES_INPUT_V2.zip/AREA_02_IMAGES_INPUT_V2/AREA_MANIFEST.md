# AREA_02 Images Input Manifest — V2

- Area: `area_02` / 페리온
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 8종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 10 | `m_stone_golem` | 스톤골렘 | `s_mon_stone` | 암석 피부 | 버프 | N |
| 2 | 18 | `m_axe_stump` | 엑스텀프 | `s_mon_axe_stump` | 도끼 휘두르기 | 액티브 | N |
| 3 | 22 | `m_dark_axe_stump` | 다크 엑스텀프 | `s_mon_dark_axe_stump` | 어둠의 뿌리 | 액티브 | N |
| 4 | 26 | `m_wild_boar` | 와일드보어 | `s_mon_wild_boar` | 저돌 맹진 | 액티브 | N |
| 5 | 28 | `m_iron_hog` | 아이언 호그 | `s_mon_iron_hog` | 강철 발굽 | 패시브 | N |
| 6 | 30 | `m_skeleton_commander` | 스켈레톤 지휘관 | `s_mon_skeleton_commander` | 뼈 무덤 | 액티브 | N |
| 7 | 32 | `m_fire_boar` | 파이어보어 | `s_mon_fire_boar` | 화염 돌풍 | 액티브 | N |
| 8 | 42 | `m_stumpy` | 스텀피 | `s_mon_stumpy` | 고목의 생기탄 | 액티브 | Y |
