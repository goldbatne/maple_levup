# Runtime Role Map — m_stone_golem / s_mon_stone

- 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 판정/재생: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 방향: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다.
- 현재 리소스: L1 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0s, duration=0.65s, scale=0.8, offset=(0,-0.06) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.72s, scale=0.9, offset=(0,-0.06) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 256×256 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
