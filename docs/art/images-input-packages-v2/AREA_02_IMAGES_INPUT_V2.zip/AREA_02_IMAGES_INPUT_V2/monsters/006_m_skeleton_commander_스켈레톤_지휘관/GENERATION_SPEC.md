# GENERATION SPEC — 스켈레톤 지휘관 / 뼈 무덤

## 확정 데이터

- 작업 순번: 006
- 레벨: 30
- Area: `area_02` / 페리온
- monster_id: `m_skeleton_commander`
- 몬스터 이름: 스켈레톤 지휘관
- monster image RUID: `ed882269a5d543318ad73e7032632960`
- skill_id: `s_mon_skeleton_commander`
- 최종 스킬 이름: **뼈 무덤**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: ATK 계수 2로 반경 5 범위 최대 2대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.18초; 지속 0.58/0.62/0.5초

## 원작/지역 연결

[P][A] 언데드 지휘관 정체성은 연결되나 ‘뼈 무덤’ 기술 설정은 확인되지 않았다.

## 시각 번역

- 핵심 소재: 지면에서 비스듬히 솟는 뼈기둥과 묘지 흙 파편. ‘스켈레톤 지휘관 / 뼈 무덤’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 뼈 상아 #D9D0B3; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 묘지 자갈색 #655C62; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=db2b67de20f5418cb7b5050ce0641df1, type=animationclip, style=clip, delay=0s, duration=0.58s, scale=0.55, offset=(0,-0.08) world unit, drift=(0,0) world unit/s; L2 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0.1s, duration=0.62s, scale=0.75, offset=(-0.25,-0.05) world unit, drift=(0,0) world unit/s; L3 ruid=997628810df4448f9e534bc426d6794a, type=animationclip, style=clip, delay=0.18s, duration=0.5s, scale=0.6, offset=(0.25,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘교차한 뼈기둥’, 보조 효과 1개는 ‘묘지 흙’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 판정/재생: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 방향: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다.
- 현재 리소스: L1 ruid=db2b67de20f5418cb7b5050ce0641df1, type=animationclip, style=clip, delay=0s, duration=0.58s, scale=0.55, offset=(0,-0.08) world unit, drift=(0,0) world unit/s; L2 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0.1s, duration=0.62s, scale=0.75, offset=(-0.25,-0.05) world unit, drift=(0,0) world unit/s; L3 ruid=997628810df4448f9e534bc426d6794a, type=animationclip, style=clip, delay=0.18s, duration=0.5s, scale=0.6, offset=(0.25,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

