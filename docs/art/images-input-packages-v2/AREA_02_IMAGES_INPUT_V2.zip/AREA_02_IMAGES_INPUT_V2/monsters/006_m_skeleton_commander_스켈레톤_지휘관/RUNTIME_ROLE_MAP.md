# Runtime Role Map — m_skeleton_commander / s_mon_skeleton_commander

- 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 판정/재생: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 방향: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다.
- 현재 리소스: L1 ruid=db2b67de20f5418cb7b5050ce0641df1, type=animationclip, style=clip, delay=0s, duration=0.58s, scale=0.55, offset=(0,-0.08) world unit, drift=(0,0) world unit/s; L2 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0.1s, duration=0.62s, scale=0.75, offset=(-0.25,-0.05) world unit, drift=(0,0) world unit/s; L3 ruid=997628810df4448f9e534bc426d6794a, type=animationclip, style=clip, delay=0.18s, duration=0.5s, scale=0.6, offset=(0.25,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.
