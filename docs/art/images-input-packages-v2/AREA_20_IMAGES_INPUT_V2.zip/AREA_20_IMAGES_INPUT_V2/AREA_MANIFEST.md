# AREA_20 Images Input Manifest — V2

- Area: `area_20` / 황혼의 페리온
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 191 | `m_mutant_dark_stump` | 변형된 다크 스텀프 | `s_mon_mutant_dark_stump` | 뒤틀린 고목의 껍질 | 패시브 | N |
| 2 | 193 | `m_mutant_iron_hog` | 변형된 아이언호그 | `s_mon_mutant_iron_hog` | 황야의 철갑 돌진 | 액티브 | N |
| 3 | 195 | `m_mutant_stone_mask` | 변형된 스톤마스크 | `s_mon_mutant_stone_mask` | 발굴지의 석면 | 패시브 | N |
| 4 | 198 | `m_ancient_dark_golem` | 에인션트 다크골렘 | `s_mon_ancient_dark_golem` | 고대 암흑 지진 | 액티브 | N |
| 5 | 200 | `m_mutant_stumpy` | 변형된 스텀피 | `s_mon_mutant_stumpy` | 검은 뿌리의 묘지 | 액티브 | Y |
