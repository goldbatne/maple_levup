# AREA_17 Images Input Manifest — V2

- Area: `area_17` / 시간의 신전
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 161 | `m_memory_monk` | 추억의 사제 | `s_mon_memory_monk` | 추억의 묵상 | 패시브 | N |
| 2 | 163 | `m_memory_monk_trainee` | 추억의 신관 | `s_mon_memory_monk_trainee` | 추억의 기도파 | 액티브 | N |
| 3 | 165 | `m_memory_guardian` | 추억의 수호병 | `s_mon_memory_guardian` | 수호병의 기억갑주 | 패시브 | N |
| 4 | 168 | `m_chief_memory_guardian` | 추억의 수호대장 | `s_mon_chief_memory_guardian` | 시간 수호진 | 액티브 | N |
| 5 | 170 | `m_dodo` | 도도 | `s_mon_dodo` | 기억 포식 | 액티브 | Y |
