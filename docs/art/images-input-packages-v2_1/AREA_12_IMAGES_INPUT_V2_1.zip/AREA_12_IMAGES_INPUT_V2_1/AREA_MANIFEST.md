# AREA_12 Images Input Manifest — V2

- Area: `area_12` / 루디브리엄
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 111 | `m_brown_teddy` | 브라운테니 | `s_mon_brown_teddy` | 솜인형 완충 | 패시브 | N |
| 2 | 113 | `m_toy_trojan` | 장난감 목마 | `s_mon_toy_trojan` | 태엽 목마 돌진 | 액티브 | N |
| 3 | 115 | `m_master_robo` | 마스터 로보 | `s_mon_master_robo` | 정밀 태엽회로 | 패시브 | N |
| 4 | 118 | `m_chronos` | 크로노스 | `s_mon_chronos` | 크로노스의 시간편린 | 액티브 | N |
| 5 | 120 | `m_timer` | 타이머 | `s_mon_timer` | 시간 정지 충격 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_brown_teddy` | `s_mon_brown_teddy` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_toy_trojan` | `s_mon_toy_trojan` | 플레이어: 8방향으로 6.8wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 fc4857ea48be477c9546c775e0f31d49 animationclip/clip delay=0s duration=0.7s scale=0.72 offset=(0,0)wu drift=(1.0,0)wu/s |
| `m_master_robo` | `s_mon_master_robo` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_chronos` | `s_mon_chronos` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 e5558e07445143b6999f20246768a3fe animationclip/clip delay=0.12s duration=0.8s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_timer` | `s_mon_timer` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 e5558e07445143b6999f20246768a3fe animationclip/clip delay=0s duration=0.78s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 3ef6b2dcc75f4d4990e6e7f106bda49e animationclip/clip delay=0.2s duration=0.88s scale=0.85 offset=(0,0)wu drift=(0,0)wu/s |

