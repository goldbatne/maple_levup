# GENERATION SPEC — 파란 달팽이 / 푸른 껍질

## 확정 데이터

- 작업 순번: 002
- 레벨: 3
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_blue_snail`
- 몬스터 이름: 파란 달팽이
- monster image RUID: `0c69164656d24f64bd1a1f6ee4019dff`
- skill_id: `s_mon_blue_snail`
- 최종 스킬 이름: **푸른 껍질**
- 스킬 타입: **버프**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: 자신에게 3초 동안 피해 40% 감소
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.85/0.7초

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 파란 달팽이의 모델 ID·RUID와 메이플 아일랜드·리스항구 | 헤네시스 근교 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 겹친 껍질 결을 닮은 반원형 보호막과 짧은 반사광. ‘파란 달팽이 / 푸른 껍질’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 푸른 껍질 청색 #4E9EDB; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 물빛 백청 #C9F4FF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 진행 방향·엔진 이동: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다. layer drift는 엔진 적용: L1 ruid=566b0886b4cf4f3997a29ecd3a1954b5, type=animationclip, style=clip, delay=0s, duration=0.85s, scale=0.65, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.7s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 자신만 감싼다. 다른 대상, 타격점, 공격 폭발은 표시하지 않는다.
- 화면 점유율: 중소형(캐릭터 중심 0.8~1.2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음~중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 시전자 둘레 윤곽 출현 → 보호 구조 닫힘 → 반사광 절정 → 실드 지속과 혼동되지 않게 짧게 페이드.
- 판정 정렬: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘푸른 껍질 아치’, 보조 효과 1개는 ‘흰 반사광’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BUFF_SELF`
- VFX: 8 frames, 각 256×256 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: APPROVED_REUSE_CAST_VFX + APPROVED_REUSE_ICON
- 채택 승인 리소스: AnimationClip `f1fc98b763c24a0bb99d8ce8453a4c8f` / ICON `6e7da13ea5924763bebb7aa4b851eb96`
- 승인 규격: 8 frames / 256x256 RGBA / 0.1s per frame / total 0.8s
- 재사용 파일: `approved_reuse/AREA_00/` 아래 F00... 및 ICON. `AREA_00_REUSE_MANIFEST.md`의 SHA-256과 일치해야 한다.
- 호환 근거: 동일 monster_id + skill_id이며 Area 00 resource map·import report와 승인 파일 해시가 일치한다.
- 신규 생성 금지: VFX/ICON을 다시 생성하거나 다른 HEAD 시각 RUID로 되돌리지 않는다.
- 좌표·방향: 승인 반입값(scale 1, offset/drift 0, normalized pivot 0.5/0.5)과 승인 좌우/몬스터 재생 기록을 유지한다.

## V2.1 실제 동작·납품 동기화

- actual_motion: AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_01_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

