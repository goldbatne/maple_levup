# Runtime Role Map — m_blue_snail / s_mon_blue_snail

- 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 판정/재생: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 방향: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다.
- 현재 리소스: L1 ruid=566b0886b4cf4f3997a29ecd3a1954b5, type=animationclip, style=clip, delay=0s, duration=0.85s, scale=0.65, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.7s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 256×256 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## 런타임 역할·반입 계약

- 역할: APPROVED_REUSE_CAST_VFX + APPROVED_REUSE_ICON
- 채택 승인 리소스: AnimationClip `f1fc98b763c24a0bb99d8ce8453a4c8f` / ICON `6e7da13ea5924763bebb7aa4b851eb96`
- 승인 규격: 8 frames / 256x256 RGBA / 0.1s per frame / total 0.8s
- 재사용 파일: `approved_reuse/AREA_00/` 아래 F00... 및 ICON. `AREA_00_REUSE_MANIFEST.md`의 SHA-256과 일치해야 한다.
- 호환 근거: 동일 monster_id + skill_id이며 Area 00 resource map·import report와 승인 파일 해시가 일치한다.
- 신규 생성 금지: VFX/ICON을 다시 생성하거나 다른 HEAD 시각 RUID로 되돌리지 않는다.
- 좌표·방향: 승인 반입값(scale 1, offset/drift 0, normalized pivot 0.5/0.5)과 승인 좌우/몬스터 재생 기록을 유지한다.

## V2.1 실제 동작·납품 동기화

- actual_motion: AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_01_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

