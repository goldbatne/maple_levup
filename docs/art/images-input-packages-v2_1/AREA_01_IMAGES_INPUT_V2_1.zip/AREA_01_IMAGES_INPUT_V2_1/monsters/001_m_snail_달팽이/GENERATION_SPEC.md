# GENERATION SPEC — 달팽이 / 이슬 미끄럼길

## 확정 데이터

- 작업 순번: 001
- 레벨: 1
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_snail`
- 몬스터 이름: 달팽이
- monster image RUID: `2db94405cf0445f5be2b60a02c21dda5`
- skill_id: `s_mon_snail_dew_trail`
- 최종 스킬 이름: **이슬 미끄럼길**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.8초

## 원작/지역 연결

[P][A] 달팽이 점액 이동과는 자연스럽지만 ‘이슬’은 Images 2.5 파일럿에서 더한 창작 설정이다.

## 시각 번역

- 핵심 소재: 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울. ‘달팽이 / 이슬 미끄럼길’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 맑은 이슬 청록 #7EDFD1; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 연한 풀잎 연두 #B8E86A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 효과 발생 위치: 시전자 발밑 바로 앞에서 ‘이슬 미끄럼길’의 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울이 낮은 지면 접촉선으로 시작
- 진행 방향: 바닥을 얇게 타고 흐르는 이슬 점액 띠와 둥근 물방울의 긴 축이 오른쪽으로 미끄러지듯 늘어나고 끝부분 물방울만 뒤따라 소멸
- 대상 표현: 확정 효과 ‘ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8’의 반경 안 다중 대상을 낮은 점액 파문과 작은 접촉광으로 구분
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 준비(핵심 형상 출현) → 상승(형상 확대·보조 입자) → 절정(밝은 코어/타격광) → 소멸(형상 분해·알파 fade)
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘큰 이슬방울’, 보조 효과 1개는 ‘낮게 미끄러지는 점액 꼬리’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함


- 스타일 적용 우선순위: 시기 근거가 검증된 RECENT_PRIMARY만 최신 우선으로 사용한다. RECENT_SECONDARY는 최신 대체 세트가 아니며 UNKNOWN/LEGACY와 함께 보조 비교로만 사용한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: APPROVED_REUSE_CAST_VFX + APPROVED_REUSE_ICON
- 채택 승인 리소스: AnimationClip `6097484d513a4fde82ad15557fdc81d3` / ICON `c0699b32529049c68de3d13022479bf9`
- 승인 규격: 8 frames / 384x384 RGBA / 0.1s per frame / total 0.8s
- 재사용 파일: `approved_reuse/AREA_00/` 아래 F00... 및 ICON. `AREA_00_REUSE_MANIFEST.md`의 SHA-256과 일치해야 한다.
- 호환 근거: 동일 monster_id + skill_id이며 Area 00 resource map·import report와 승인 파일 해시가 일치한다.
- 신규 생성 금지: VFX/ICON을 다시 생성하거나 다른 HEAD 시각 RUID로 되돌리지 않는다.
- 좌표·방향: 승인 반입값(scale 1, offset/drift 0, normalized pivot 0.5/0.5)과 승인 좌우/몬스터 재생 기록을 유지한다.

## V2.1 실제 동작·납품 동기화

- actual_motion: AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_01_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

