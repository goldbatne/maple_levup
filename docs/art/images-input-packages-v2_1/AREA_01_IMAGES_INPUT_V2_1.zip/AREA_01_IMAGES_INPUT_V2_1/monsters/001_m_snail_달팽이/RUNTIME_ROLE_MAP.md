# Runtime Role Map — m_snail / s_mon_snail_dew_trail

- 역할: APPROVED_REUSE_CAST_VFX=AREA 00 승인 AnimationClip 재사용; ICON=AREA 00 승인 UI 아이콘 재사용
- 발생 위치: AREA 00 반입 보고서에서 플레이어 좌·우 방향 및 몬스터 시전자 재생을 검증했다. 현재 작업 트리의 SkillTable 원본 행이 삭제되어 세부 offset은 새 값으로 확정하지 않는다.
- 판정/재생: 승인 기록 기준 8프레임 × 0.1초, 총 0.8초 one-shot. 피해 판정 시점은 현재 삭제된 SkillTable 행을 추정하지 않는다.
- 방향: 승인 런타임 기록의 좌우 재생을 그대로 재사용한다. 새 이미지 내부 이동·recenter·Flip 규칙을 추가하지 않는다.
- 현재 승인 리소스: AnimationClip `6097484d513a4fde82ad15557fdc81d3` / ICON `c0699b32529049c68de3d13022479bf9`
- 필요 파일:
  - approved_reuse/AREA_00 아래에 포함된 승인 F00... 프레임과 ICON을 바이트 그대로 사용
  - 신규 VFX/ICON 생성 금지; AREA 00 승인 에셋과 해시가 다르면 재사용 중단
- 좌표 단위: 현재 삭제된 SkillTable 행 때문에 새 좌표·크기 값을 만들지 않는다. 승인 적용값을 유지한다.
- 반복: 승인 AnimationClip은 one-shot. 재사용 정책은 동일 monster_id + skill_id에만 적용한다.

## 런타임 역할·반입 계약

- 역할: APPROVED_REUSE_CAST_VFX + APPROVED_REUSE_ICON
- 채택 승인 리소스: AnimationClip `6097484d513a4fde82ad15557fdc81d3` / ICON `c0699b32529049c68de3d13022479bf9`
- 승인 규격: 8 frames / 384x384 RGBA / 0.1s per frame / total 0.8s
- 재사용 파일: `approved_reuse/AREA_00/` 아래 F00... 및 ICON. `AREA_00_REUSE_MANIFEST.md`의 SHA-256과 일치해야 한다.
- 호환 근거: 동일 monster_id + skill_id이며 Area 00 resource map·import report와 승인 파일 해시가 일치한다.
- 신규 생성 금지: VFX/ICON을 다시 생성하거나 다른 HEAD 시각 RUID로 되돌리지 않는다.
- 좌표·방향: 승인 반입값(scale 1, offset/drift 0, normalized pivot 0.5/0.5)과 승인 좌우/몬스터 재생 기록을 유지한다.

## V2.1 실제 동작·납품 동기화

- actual_motion: AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_01_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

