# AREA_01 Images Input Manifest — V2

- Area: `area_01` / 헤네시스 근교
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: m_adv_hero
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 1 | `m_snail` | 달팽이 | `s_mon_snail_dew_trail` | 이슬 미끄럼길 | 액티브 | N |
| 2 | 3 | `m_blue_snail` | 파란 달팽이 | `s_mon_blue_snail` | 푸른 껍질 | 버프 | N |
| 3 | 5 | `m_mushroom` | 주황 버섯 | `s_mon_mushroom` | 포자 살포 | 액티브 | N |
| 4 | 10 | `m_mushmom` | 머쉬맘 | `s_mon_mushmom` | 머쉬맘의 포자 충격 | 액티브 | Y |
| 5 | 12 | `m_horny_mushroom` | 뿔버섯 | `s_mon_horny_mushroom` | 단단한 뿔 | 패시브 | N |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_snail` | `s_mon_snail_dew_trail` | AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음 |
| `m_blue_snail` | `s_mon_blue_snail` | AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음 |
| `m_mushroom` | `s_mon_mushroom` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 9c927f6388e74628b1050dfc8490246c animationclip/clip delay=0s duration=0.55s scale=0.38 offset=(-0.28,0)wu drift=(-0.28,0.12)wu/s; L2 9c927f6388e74628b1050dfc8490246c animationclip/clip delay=0.08s duration=0.6s scale=0.36 offset=(0,0.04)wu drift=(0,0.18)wu/s; L3 9c927f6388e74628b1050dfc8490246c animationclip/clip delay=0.16s duration=0.65s scale=0.34 offset=(0.28,-0.04)wu drift=(0.28,0.12)wu/s |
| `m_mushmom` | `s_mon_mushmom` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 05113e9dc86448cb8581731824106d75 animationclip/clip delay=0s duration=0.75s scale=0.9 offset=(0,-0.08)wu drift=(0,0)wu/s; L2 86734a2715504c10b1e50ae810609e25 animationclip/clip delay=0.1s duration=0.72s scale=1.15 offset=(0,-0.08)wu drift=(0,0)wu/s; L3 9c927f6388e74628b1050dfc8490246c animationclip/clip delay=0.22s duration=0.7s scale=0.72 offset=(0,0)wu drift=(0,0.18)wu/s |
| `m_horny_mushroom` | `s_mon_horny_mushroom` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |

