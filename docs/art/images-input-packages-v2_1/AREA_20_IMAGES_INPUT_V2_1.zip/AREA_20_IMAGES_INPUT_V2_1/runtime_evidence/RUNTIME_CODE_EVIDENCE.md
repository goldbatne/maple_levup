# Runtime evidence summary

이 문서는 코드 읽기 근거이며 Maker 런타임 실행 결과가 아니다.

- 데이터 로딩: `GameData.mlua` 100~107, 114~142 — `_DataService:GetTable("SkillTable")`을 이름으로 조회해 `LoadSkills`가 캐시한다.
- 레이어: `GameData.mlua` 67~97, `SkillEffect.mlua` 47~121 — 파이프 배열을 순서대로 구성하고 시전자 좌표에 `offset`, `drift`, `FlipX`를 엔진이 적용한다.
- 일반 공격: `PlayerAttack.mlua` 225~269 / `MonsterAttack.mlua` 379~436 — 플레이어는 즉시 판정 뒤 CAST, 몬스터는 실제 명중 뒤 CAST.
- 투사체: `PlayerAttack.mlua` 277~337, `MonsterAttack.mlua` 450 이후, `SkillEffect.mlua` 149~200 — 엔진 이동과 데미지 타이머가 `0.35`초를 공유한다.
- 돌진: `PlayerAttack.mlua` 386~479 / `PlayerDash.mlua` 38~104 — 플레이어만 클라이언트 8방향 이동하며 `0.2`초 뒤 계산 도착점에 판정한다. 몬스터 CastSkill에는 dash 분기가 없다.
- 버프: `PlayerAttack.mlua` 213~220 / `MonsterAttack.mlua` 362~375 — 자기 효과가 성공한 뒤 방향 반전 없이 CAST.
- 패시브: `GameData.mlua` 201~215 / `PlayerStats.mlua`의 `skill_kind == "passive"` 분기 — 보유 수량으로 스탯을 적용하고 CAST VFX를 호출하지 않는다.
- Sprite 등록 pivot `(0.5,0.5)`은 AREA 00 승인 반입 보고서의 확인값이다. 다른 신규 에셋의 최종 scale/offset은 Preview 확인 전 확정하지 않는다.

## 확보한 현재 코드 SHA-256

- `RootDesk/MyDesk/GameData/GameData.mlua`: `01a908caeaa582d163d7240a5ec05adea260df342109a3a8360ce399efe3942f`
- `RootDesk/MyDesk/GameData/GameDataVerify.mlua`: `4cbd670cd67167a562a9f06629348662d69f3dced3e23413c3a71819da209328`
- `RootDesk/MyDesk/PlayerAttack.mlua`: `2e7c56864fe65d900f693a2979ef93d897217bd5110b83bbcdc4c18289b4a95b`
- `RootDesk/MyDesk/MonsterAttack.mlua`: `3586b4df5e134cbec724aefb0b9f25207c695de9d4a2fb6a1f3ce377f2dbf1fa`
- `RootDesk/MyDesk/Combat/SkillEffect.mlua`: `c1d373e2cbebc524a5c43c92441e6725778e69d86b22312a990b2f6b3b505e6d`
- `RootDesk/MyDesk/Combat/SkillCastEffect.mlua`: `8fbbd0023a8154dbb23c3dc99d2e0d4dc41a731b9de56b20d160ad3d30a17e0c`
- `RootDesk/MyDesk/Combat/SkillProjectile.mlua`: `db94b038c38e568942be36f6236dc51c6f3e290306a565c5b09ddd2283d6b90f`
- `RootDesk/MyDesk/Player/PlayerDash.mlua`: `1a901176d31c3d3faf0d2c81cdf9a658a0b67638e16f9838edfb4fe792cd67a0`
