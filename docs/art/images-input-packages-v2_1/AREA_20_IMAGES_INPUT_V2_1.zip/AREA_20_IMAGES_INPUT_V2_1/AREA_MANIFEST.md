# AREA_20 Images Input Manifest — V2

- Area: `area_20` / 황혼의 페리온
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 191 | `m_mutant_dark_stump` | 변형된 다크 스텀프 | `s_mon_mutant_dark_stump` | 뒤틀린 고목의 껍질 | 패시브 | N |
| 2 | 193 | `m_mutant_iron_hog` | 변형된 아이언호그 | `s_mon_mutant_iron_hog` | 황야의 철갑 돌진 | 액티브 | N |
| 3 | 195 | `m_mutant_stone_mask` | 변형된 스톤마스크 | `s_mon_mutant_stone_mask` | 발굴지의 석면 | 패시브 | N |
| 4 | 198 | `m_ancient_dark_golem` | 에인션트 다크골렘 | `s_mon_ancient_dark_golem` | 고대 암흑 지진 | 액티브 | N |
| 5 | 200 | `m_mutant_stumpy` | 변형된 스텀피 | `s_mon_mutant_stumpy` | 검은 뿌리의 묘지 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_mutant_dark_stump` | `s_mon_mutant_dark_stump` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_mutant_iron_hog` | `s_mon_mutant_iron_hog` | 플레이어: 8방향으로 6.8wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 9d71fbaf9b154c51bbdb481eaa2fc52f animationclip/clip delay=0s duration=.68s scale=1.02 offset=(0,0)wu drift=(0,0)wu/s; L2 a29334463fbf4a7bbc8e4cb7325229b7 animationclip/clip delay=.18s duration=.78s scale=1.12 offset=(0,0)wu drift=(0,0)wu/s |
| `m_mutant_stone_mask` | `s_mon_mutant_stone_mask` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_ancient_dark_golem` | `s_mon_ancient_dark_golem` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 3803b5c17bf04b56bef115b3afbf388b animationclip/clip delay=0s duration=.9s scale=1.14 offset=(0,0)wu drift=(0,0)wu/s; L2 6ad623bf86ad46f0ad423c10e383a28e animationclip/clip delay=.3s duration=1.0s scale=1.25 offset=(0,0)wu drift=(0,0)wu/s |
| `m_mutant_stumpy` | `s_mon_mutant_stumpy` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 e79a4d871f6a4cbdbf75a7126982013e animationclip/clip delay=0s duration=.88s scale=1.16 offset=(0,0)wu drift=(0,0)wu/s; L2 dfb0126bee6f48fb9bdb289bddef870b animationclip/clip delay=.24s duration=1.02s scale=1.3 offset=(0,0)wu drift=(0,0)wu/s |

