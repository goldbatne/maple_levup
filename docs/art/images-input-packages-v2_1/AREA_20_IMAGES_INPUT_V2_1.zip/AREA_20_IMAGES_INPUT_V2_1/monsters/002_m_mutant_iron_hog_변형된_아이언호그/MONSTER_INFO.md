# Monster Reference — 변형된 아이언호그

- 작업 순번: 002
- level: 193
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_iron_hog`
- model_id: `mutantironhog`
- image RUID: `cd613d0025674a6f8b1cc7211054eb41`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_iron_hog`
- skill name/type: 황야의 철갑 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MutantIronHog.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `d03e9d4e64b45908990e6e7ebaa7b0c774823968366b3dc9548e55d22f54e864`
- image: 320×240 RGBA / alpha 0~255 / bbox [57, 1, 261, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
