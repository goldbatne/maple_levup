# Monster Reference — 에인션트 다크골렘

- 작업 순번: 004
- level: 198
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_ancient_dark_golem`
- model_id: `ancientdarkgolem`
- image RUID: `f60c7188fcd544ef869845a34ff92b30`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ancient_dark_golem`
- skill name/type: 고대 암흑 지진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/AncientDarkGolem.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9caac00e345cd8f2aa0e039e94a39cb4a945f3304951a0b0354743d0220f23b4`
- image: 320×240 RGBA / alpha 0~255 / bbox [14, 2, 306, 239]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
