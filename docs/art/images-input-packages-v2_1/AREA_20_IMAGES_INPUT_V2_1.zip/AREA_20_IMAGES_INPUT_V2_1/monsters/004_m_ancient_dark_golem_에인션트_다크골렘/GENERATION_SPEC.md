# GENERATION SPEC — 에인션트 다크골렘 / 고대 암흑 지진

## 확정 데이터

- 작업 순번: 004
- 레벨: 198
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_ancient_dark_golem`
- 몬스터 이름: 에인션트 다크골렘
- monster image RUID: `f60c7188fcd544ef869845a34ff92b30`
- skill_id: `s_mon_ancient_dark_golem`
- 최종 스킬 이름: **고대 암흑 지진**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: ATK 계수 6.45로 반경 6.4 범위 최대 5대상 피해; 10초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/.3초; 지속 .9/1.0초

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 에인션트 다크골렘의 모델 ID·RUID와 황혼의 페리온 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 고대 암석 균열이 지면을 가로지르며 검은 돌기둥을 세우는 지진. ‘에인션트 다크골렘 / 고대 암흑 지진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 고대 흑암 #35343B; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 균열 적갈 #A55A43; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=3803b5c17bf04b56bef115b3afbf388b, type=animationclip, style=clip, delay=0s, duration=.9s, scale=1.14, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=6ad623bf86ad46f0ad423c10e383a28e, type=animationclip, style=clip, delay=.3s, duration=1.0s, scale=1.25, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간~높음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘균열 지면’, 보조 효과 1개는 ‘암흑 돌기둥’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 판정/재생: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 방향: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다.
- 현재 리소스: L1 ruid=3803b5c17bf04b56bef115b3afbf388b, type=animationclip, style=clip, delay=0s, duration=.9s, scale=1.14, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=6ad623bf86ad46f0ad423c10e383a28e, type=animationclip, style=clip, delay=.3s, duration=1.0s, scale=1.25, offset=(0,0) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## V2.1 실제 동작·납품 동기화

- actual_motion: 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 3803b5c17bf04b56bef115b3afbf388b animationclip/clip delay=0s duration=.9s scale=1.14 offset=(0,0)wu drift=(0,0)wu/s; L2 6ad623bf86ad46f0ad423c10e383a28e animationclip/clip delay=.3s duration=1.0s scale=1.25 offset=(0,0)wu drift=(0,0)wu/s
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_20_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

