# Monster Reference — 변형된 스톤마스크

- 작업 순번: 003
- level: 195
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_stone_mask`
- model_id: `mutantstonemask`
- image RUID: `f020a220a2ad40a28d4920b790b32f3c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_stone_mask`
- skill name/type: 발굴지의 석면 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MutantStoneMask.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a0576538e9bc2c98529995603b9260c7bee7dce3eb639aa440430ffe3df75594`
- image: 320×240 RGBA / alpha 0~255 / bbox [59, 4, 262, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
