# Monster Reference — 변형된 스텀피

- 작업 순번: 005
- level: 200
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_stumpy`
- model_id: `mutantstumpy`
- image RUID: `fe3077e91e5442579b6cfaa6b4c59469`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_stumpy`
- skill name/type: 검은 뿌리의 묘지 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MutantStumpy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `8f3a54507babc9b5252f8d7b8e94f04032df8ccd9bea21f4ad6756bcacd05e2d`
- image: 320×240 RGBA / alpha 0~255 / bbox [45, 0, 275, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
