# Monster Reference — 변형된 다크 스텀프

- 작업 순번: 001
- level: 191
- Area: `area_20` / 황혼의 페리온
- monster_id: `m_mutant_dark_stump`
- model_id: `mutantdarkstump`
- image RUID: `9b09382f4ba6483eb11a931f49a68f9b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_mutant_dark_stump`
- skill name/type: 뒤틀린 고목의 껍질 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MutantDarkStump.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `683913d349d659b469e53639b3fde78d4b26b8838eef1f04040eab6be068e8fe`
- image: 320×240 RGBA / alpha 0~255 / bbox [45, 0, 268, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
