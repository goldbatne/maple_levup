# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/t68/twilight`
- 합성 대상: 00_desolate_rock.png, 01_burnt_land.png, 02_excavation_mask.png, 03_black_magma.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
