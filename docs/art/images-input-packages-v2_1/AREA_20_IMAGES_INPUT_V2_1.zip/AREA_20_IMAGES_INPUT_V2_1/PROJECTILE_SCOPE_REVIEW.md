# PROJECTILE SCOPE REVIEW

코드 읽기 근거이며 런타임·아트 승인이 아니다. 엔진 이동 유지와 기존 투사체 그림 유지는 별도 판단이다.
스텀피는 CAST 리소스가 없으므로 필수 VFX를 PROJECTILE 역할로 교정한다. 나머지는 CAST+ICON 필수 범위를 유지하고 기존 projectile을 KEEP하되 별도 재제작 여부는 NEEDS_DECISION이다.

| Area | monster | skill | projectile RUID | preview | current cast | required V2.1 scope | 판정 |
|---|---|---|---|---|---|---|---|
| area_02 | `m_stumpy` | `s_mon_stumpy` | `c6b3f052e977479ea5ad5329ce0981ca` | SCENE; usable=true | no | PROJECTILE+ICON | REPLACE_PLANNED projectile |
| area_03 | `m_faust` | `s_mon_faust` | `49b21aaa1d574ba787149841a31bf1a5` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_08 | `m_star_pixie` | `s_mon_star_pixie` | `b61e7e2a50b2405794f88fdddf44b73a` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_08 | `m_lunar_pixie` | `s_mon_lunar_pixie` | `4f6509d9539f4d76a9bb4e8f17e12cc7` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_10 | `m_shark` | `s_mon_shark` | `209c4567073b424e8d445cea7efb80e3` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_11 | `m_king_bloctopus` | `s_mon_king_bloctopus` | `a2da67e687994755a8943c2bcf871902` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_14 | `m_roid` | `s_mon_roid` | `e51545cbf94349f59f4431e2e76d2cdc` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_14 | `m_chimera` | `s_mon_chimera` | `ab113d9a5ca5402d85ecc2ab7a4f51a1` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_15 | `m_peach_monkey` | `s_mon_peach_monkey` | `9ca14ee512b1489cbb54b2b9833388cd` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_15 | `m_tae_roon` | `s_mon_tae_roon` | `5328a3875a32437784c949579f259a00` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_17 | `m_dodo` | `s_mon_dodo` | `72e16f10f6ec4cf0a1fe3146e73f0856` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |
| area_18 | `m_mateon` | `s_mon_mateon` | `22db356cc60940089b7f5d592c7d5813` | VFX; usable=true | yes | CAST_VFX+ICON; existing PROJECTILE keep | NEEDS_DECISION optional projectile redraw |

## 공통 연결 주의

- 비행 시간은 GameBalance `projectile_seconds=0.35`초이며 이미지 프레임의 캔버스 이동으로 중복하지 않는다.
- projectile entity가 caster+h에서 target+h로 이동하고 spin을 적용한다.
- CAST의 절정과 착탄은 자동으로 같은 시점이 아니다. 착탄 전용 파일을 요구하려면 별도 데이터 필드/호출 경로 결정이 필요하다.
- 기존 projectile의 미술 적합성은 픽셀/메타데이터만으로 승인하지 않는다.
