# STYLE ATLAS — V2.1

- 전체 수집본: 183
- 역할: ICON 40 / MONSTER_CHARACTER 10 / SCENE 5 / UNCONFIRMED 23 / VFX 105
- 우선순위: EXCLUDE_STYLE 15 / LEGACY_REFERENCE 41 / RECENT_SECONDARY 19 / UNKNOWN 108
- preview_usable=false: 8
- RECENT_PRIMARY만 시기 근거가 검증된 경우 최신 우선으로 쓴다. RECENT_SECONDARY는 자동 대체 세트가 아니다.
- MONSTER_CHARACTER/SCENE/EXCLUDE_STYLE은 캐릭터·무기·장면 실루엣을 신규 VFX로 가져오지 않는다.
- 흰색 프리뷰는 효과를 판독할 수 없어 주 스타일 분석에서 제외한다. 파일과 RUID는 이력 보존을 위해 유지한다.

## 식별 불가 프리뷰

| index | name | RUID | 판정 |
|---:|---|---|---|
| 5 | 돌아온 머쉬맘 | `05113e9dc86448cb8581731824106d75` | exact opaque white; replacement unavailable |
| 34 | animationclip-657764 | `2643498ff2bb4b4a8a55c480f00373a4` | exact opaque white; replacement unavailable |
| 69 | animationclip-660656 | `566b0886b4cf4f3997a29ecd3a1954b5` | exact opaque white; replacement unavailable |
| 87 | 에인션트 다크골렘 | `6ad623bf86ad46f0ad423c10e383a28e` | exact opaque white; replacement unavailable |
| 110 | animationclip-663687 | `8b26a0cdb63d455e82d1ca0fddf5e139` | exact opaque white; replacement unavailable |
| 142 | animationclip-666784 | `beabe4fd1d6d442dafe41d0d086e622e` | exact opaque white; replacement unavailable |
| 154 | 도도 | `cf2fe8e1a8954e7099bd2243cfb908d7` | exact opaque white; replacement unavailable |
| 174 | 도도 | `ee1dc1a6f4e6452b860a43ce291c62a3` | exact opaque white; replacement unavailable |
