# 마뇽

- RUID: `b6b5849af24a416ab1680a1dced9697f`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: layered VFX
- 프리뷰: 확보
- 사용 연결: s_mon_manon:마뇽의 용화염:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `b6b5849af24a416ab1680a1dced9697f`
- reference_role: `VFX`
- style_priority: `UNKNOWN`
- role_basis: preview 시각 검수 + SkillTable 시각 필드 사용처
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

