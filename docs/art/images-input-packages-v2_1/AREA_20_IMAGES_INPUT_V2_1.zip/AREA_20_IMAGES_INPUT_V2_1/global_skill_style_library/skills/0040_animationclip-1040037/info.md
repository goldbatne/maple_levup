# animationclip-1040037

- RUID: `2f4311e974a44f218bedd1011a561310`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: mixed/unknown
- 프리뷰: 확보
- 사용 연결: -:공식 검색 후보: 초보자 스킬:supplementary_search

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `2f4311e974a44f218bedd1011a561310`
- reference_role: `SCENE`
- style_priority: `EXCLUDE_STYLE`
- role_basis: 183개 preview contact sheet 시각 검수: 본체/장면과 효과가 함께 있음
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

