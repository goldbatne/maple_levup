# sprite-8918337

- RUID: `644fc39bcc684c209264eb9d9a4cd6f8`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **LEGACY_REFERENCE**
- 시기 근거: 프로젝트 T16-3a의 모험가 계보 자료; 자산 자체 개정일 미확인
- 시기 확신도: MEDIUM
- 효과 계열: icon
- 프리뷰: 확보
- 사용 연결: s_hero_04:레이징 블로우:icon_ruid

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `644fc39bcc684c209264eb9d9a4cd6f8`
- reference_role: `ICON`
- style_priority: `LEGACY_REFERENCE`
- role_basis: SkillTable icon_ruid 사용처
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

