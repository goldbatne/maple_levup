# animationclip-1041550

- RUID: `057c2da13da2492c95cb92db424803db`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: dash
- 프리뷰: 확보
- 사용 연결: s_mon_red_snail:붉은 껍질 돌진:layer_ruids; s_mon_ribbon_pig:리본 돌진:layer_ruids; s_mon_wild_kargo:야수의 그림자 돌진:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `057c2da13da2492c95cb92db424803db`
- reference_role: `VFX`
- style_priority: `UNKNOWN`
- role_basis: preview 시각 검수 + SkillTable 시각 필드 사용처
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

