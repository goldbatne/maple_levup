# 저주의 인형

- RUID: `c07ed26000af460a8438a3486e16f3ec`
- 출처: 프로젝트 보존 원본/반입 프레임
- 스타일 우선순위: **LEGACY_REFERENCE**
- 시기 근거: 프로젝트 T20/T32/T37 직접 제작 아이콘 기록
- 시기 확신도: HIGH_PROJECT_ONLY
- 효과 계열: icon
- 프리뷰: 확보
- 사용 연결: s_mon_faust:저주의 인형:icon_ruid

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `c07ed26000af460a8438a3486e16f3ec`
- reference_role: `ICON`
- style_priority: `LEGACY_REFERENCE`
- role_basis: SkillTable icon_ruid 사용처
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

