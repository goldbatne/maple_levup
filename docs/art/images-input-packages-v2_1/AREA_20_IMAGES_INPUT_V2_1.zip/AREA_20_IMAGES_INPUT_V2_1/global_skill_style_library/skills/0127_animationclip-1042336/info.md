# animationclip-1042336

- RUID: `a610b14bbc55477cbc78777a5a2e7ed1`
- 출처: MSW 공식 리소스 검색 API thumbnail
- 스타일 우선순위: **UNKNOWN**
- 시기 근거: 리소스 API에 출시 시기 메타데이터 없음
- 시기 확신도: NONE
- 효과 계열: wave/area
- 프리뷰: 확보
- 사용 연결: s_mon_drake:동굴 용염:layer_ruids; s_mon_fire_boar:화염 돌풍:layer_ruids; s_mon_jr_balrog:발록의 화염 파동:layer_ruids

이 자료는 **시각 문법 분석용**이며 기능·무기·실루엣 복제용이 아니다.

## V2.1 synchronized classification

- RUID: `a610b14bbc55477cbc78777a5a2e7ed1`
- reference_role: `VFX`
- style_priority: `UNKNOWN`
- role_basis: preview 시각 검수 + SkillTable 시각 필드 사용처
- preview_usable: `true`
- preview_unusable_reason: 없음
- 적용 규칙: preview_usable=false이거나 style_priority=EXCLUDE_STYLE이면 주 스타일 판단에서 제외한다.

