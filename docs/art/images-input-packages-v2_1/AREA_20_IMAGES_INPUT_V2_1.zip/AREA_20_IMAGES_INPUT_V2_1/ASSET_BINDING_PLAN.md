# ASSET BINDING PLAN

CSV가 연결 계획의 원장이다. KEEP은 승인 전 현행 보존, REPLACE_PLANNED는 아트 승인 후 교체 계획, APPROVED_REUSE는 Area 00 승인본, REFERENCE_ONLY는 런타임 미사용이다. 신규 RUID 부재는 오류가 아니다.
