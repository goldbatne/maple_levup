# DATA SOURCE RESOLUTION

## 확인된 사실

- V2 기준 커밋: `3e052a2166fb7aa0cdf1e75e79266d54ff51b6e1`.
- 기준 커밋의 SkillTable SHA-256: `f0cb65e6390c3f154d91abbcc622b76c93aa1ca8bf0baf81d57bfe8f3b0f0d69` / 111행.
- 현재 정상 경로 `RootDesk/MyDesk/GameData/SkillTable.csv`와 `.userdataset`은 삭제 상태다. 삭제 의도는 기록이 없어 UNKNOWN이다.
- 실제 로더는 `GameData:GetDataSet("SkillTable")` → `_DataService:GetTable("SkillTable")`로 이름 기반 UserDataSet을 읽는다.
- 현재 파일시스템에는 `Mislocated/MyDesk/GameData/SkillTable.csv/.userdataset` 후보가 있으나, 정상 RootDesk 경로가 아니므로 Maker 등록·현재 실행 원본이라고 단정할 수 없다.
- Mislocated CSV는 기준 커밋과 비교해 변경 5행(s_mon_blue_snail, s_mon_mano, s_mon_red_snail, s_mon_slime, s_mon_snail_dew_trail), 총 112행이다. 나머지 행은 동일하다.
- 변경 5행은 Area 00 승인 리소스맵의 4개 교체 행과 신규 `s_mon_snail_dew_trail`로 설명되며 아래 값이 대응한다.

- `s_mon_snail_dew_trail`: MATCH (candidate icon/layer vs Area 00 resource map)
- `s_mon_blue_snail`: MATCH (candidate icon/layer vs Area 00 resource map)
- `s_mon_red_snail`: MATCH (candidate icon/layer vs Area 00 resource map)
- `s_mon_mano`: MATCH (candidate icon/layer vs Area 00 resource map)
- `s_mon_slime`: MATCH (candidate icon/layer vs Area 00 resource map)

## 판정

- Area 00 재사용 3종은 승인 resource map·import report·Mislocated 후보가 같은 RUID를 가리키므로 승인본을 사용한다.
- 나머지 대상 스킬은 기준 커밋과 Mislocated 후보의 값이 동일하므로 V2 확정 데이터 대조에 기준 커밋 사본을 사용한다.
- 현재 Maker가 어느 SkillTable UserDataSet을 실제 등록해 읽는지는 런타임 금지 범위와 정상 경로 삭제 때문에 UNRESOLVED다. HEAD라는 이유만으로 현재 실행 데이터라고 부르지 않는다.
- INPUT V2.1은 게임 파일을 복구·수정하지 않는다.

## git status 증거

```text
M .maplestory-skill-maker-ledger.md
 M RootDesk/MyDesk/GameData/MonsterTable.csv
 D RootDesk/MyDesk/GameData/SkillTable.csv
 D RootDesk/MyDesk/GameData/SkillTable.userdataset
 M map/map006.map
 M map/map205.map
 M ui/EquipWindow.ui
 M ui/Inventory.ui
?? Mislocated/
?? RootDesk/MyDesk/RootDesk.directory
?? RootDesk/MyDesk/RootDesk/
?? docs/art/AREA_01_DIRECT_GENERATION_PILOT/
?? docs/art/PILOT_SNAIL_SKILL_IMAGES25_IMPORT_REPORT.md
?? docs/art/PILOT_SNAIL_SKILL_IMAGES25_RUNBOOK.md
?? docs/art/area00-images-output/
?? docs/art/images-input-packages-v2/
?? docs/art/images-input-packages/
?? docs/art/pilot-snail-images25/
?? docs/design/
?? docs/tools/__pycache__/
?? docs/tools/audit-area-images-input-v2.py
?? docs/tools/build-area-images-input-packages.py
?? docs/tools/build-area-images-input-v2_1.py
?? docs/tools/correct-area-images-input-packages.py
?? docs/tools/fetch-images-input-resources.cjs
?? docs/tools/fix-area-package-monster-alpha.py
?? docs/tools/prepare-area01-direct-generation-pilot.py
?? docs/tools/prepare-snail-images25.py
?? docs/tools/sync-area-images-index.py
?? docs/tools/validate-area00-images-output.py
?? docs/tools/verify-area-images-input-packages.py
?? docs/tools/verify-area-images-input-v2.py
?? docs/tools/verify-area-images-input-v2_1.py
```
