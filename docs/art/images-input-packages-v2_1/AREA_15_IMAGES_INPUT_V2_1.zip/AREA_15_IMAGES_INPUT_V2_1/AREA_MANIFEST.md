# AREA_15 Images Input Manifest — V2

- Area: `area_15` / 무릉도원
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 141 | `m_straw_dummy` | 수련용 짚인형 | `s_mon_straw_dummy` | 짚단 균형감각 | 패시브 | N |
| 2 | 143 | `m_wooden_dummy` | 수련용 나무인형 | `s_mon_wooden_dummy` | 목인 회전타 | 액티브 | N |
| 3 | 145 | `m_peach_monkey` | 원공 | `s_mon_peach_monkey` | 천도 투척 | 액티브 | N |
| 4 | 148 | `m_blue_flower_serpent` | 청화사 | `s_mon_blue_flower_serpent` | 청화 비늘 | 패시브 | N |
| 5 | 150 | `m_tae_roon` | 태륜 | `s_mon_tae_roon` | 태륜의 쌍권풍 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_straw_dummy` | `s_mon_straw_dummy` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_wooden_dummy` | `s_mon_wooden_dummy` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 1ad77c5bc77f4ee3a7b212d6394f0b13 animationclip/clip delay=0s duration=0.7s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s; L2 7598c7485ce9483b8b1178386b7d8f73 animationclip/clip delay=0.22s duration=0.55s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s |
| `m_peach_monkey` | `s_mon_peach_monkey` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 9ca14ee512b1489cbb54b2b9833388cd는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 b22bb4955588482cbe450b97cff20c19 animationclip/clip delay=0s duration=0.65s scale=1 offset=(0,0)wu drift=(0,0)wu/s |
| `m_blue_flower_serpent` | `s_mon_blue_flower_serpent` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_tae_roon` | `s_mon_tae_roon` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 5328a3875a32437784c949579f259a00는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 353079a9d111455ab55d75577f9d7967 animationclip/clip delay=0s duration=0.75s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s; L2 8e38989c6f3d4f87876d37e431ee11c1 animationclip/clip delay=0.2s duration=0.85s scale=1.1 offset=(0,0)wu drift=(0,0)wu/s |

