# AREA_08 Images Input Manifest — V2

- Area: `area_08` / 오르비스
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 71 | `m_star_pixie` | 스타픽시 | `s_mon_star_pixie` | 별빛 탄환 | 액티브 | N |
| 2 | 73 | `m_jr_cellion` | 주니어 샐리온 | `s_mon_jr_cellion` | 붉은 뿔의 기백 | 패시브 | N |
| 3 | 75 | `m_lunar_pixie` | 루나픽시 | `s_mon_lunar_pixie` | 월광 구슬 | 액티브 | N |
| 4 | 78 | `m_luster_pixie` | 러스터픽시 | `s_mon_luster_pixie` | 태양빛 잔상 | 패시브 | N |
| 5 | 80 | `m_eliza` | 엘리쟈 | `s_mon_eliza` | 여신의 정원 폭풍 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_star_pixie` | `s_mon_star_pixie` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid b61e7e2a50b2405794f88fdddf44b73a는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 78e3188f0fc14797a8383658e626e3ea animationclip/clip delay=0s duration=0.62s scale=0.72 offset=(0,0)wu drift=(0,0)wu/s; L2 6ffbabe486c24e5ea6cda2c54022033b animationclip/clip delay=0.18s duration=0.58s scale=0.7 offset=(0,0)wu drift=(0,0)wu/s |
| `m_jr_cellion` | `s_mon_jr_cellion` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_lunar_pixie` | `s_mon_lunar_pixie` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 4f6509d9539f4d76a9bb4e8f17e12cc7는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 e7ee1a40564c43afbced2da544471266 animationclip/clip delay=0s duration=0.68s scale=0.8 offset=(0,0)wu drift=(0,0)wu/s; L2 6d96350411834e2b90a2fe18ff542159 animationclip/clip delay=0.2s duration=0.62s scale=0.75 offset=(0,0)wu drift=(0,0)wu/s |
| `m_luster_pixie` | `s_mon_luster_pixie` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_eliza` | `s_mon_eliza` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 b14b3dbca0504af28e8d085c12b22000 animationclip/clip delay=0s duration=0.72s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s; L2 1660382723ff40c296845e8ded7bbc86 animationclip/clip delay=0.22s duration=0.85s scale=1.25 offset=(0,0)wu drift=(0,0)wu/s |

