# AREA_04 Images Input Manifest — V2

- Area: `area_04` / 커닝시티
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 31 | `m_octopus` | 옥토퍼스 | `s_mon_octopus` | 먹물 폭발 | 액티브 | N |
| 2 | 33 | `m_stirge` | 스티지 | `s_mon_stirge` | 밤의 감각 | 패시브 | N |
| 3 | 35 | `m_jr_wraith` | 주니어 레이스 | `s_mon_jr_wraith` | 망령 충격 | 액티브 | N |
| 4 | 38 | `m_wraith` | 레이스 | `s_mon_wraith` | 원혼의 기운 | 패시브 | N |
| 5 | 40 | `m_shade` | 셰이드 | `s_mon_shade` | 심연의 장막 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_octopus` | `s_mon_octopus` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 69656381a8e04edcbb8a2c8599567ab3 animationclip/clip delay=0s duration=0.6s scale=0.62 offset=(0,0.02)wu drift=(0,0)wu/s; L2 544b4092b87a41948b74e6645d530b88 animationclip/clip delay=0.1s duration=0.75s scale=0.72 offset=(0,0.05)wu drift=(0,0)wu/s |
| `m_stirge` | `s_mon_stirge` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_jr_wraith` | `s_mon_jr_wraith` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 c4f8dce4ee2745cda0f211514605261b animationclip/clip delay=0s duration=0.62s scale=0.6 offset=(0,0.08)wu drift=(0,0)wu/s; L2 01dbde634dd944e685b45727289bd9b8 animationclip/clip delay=0.12s duration=0.75s scale=0.75 offset=(0,0.05)wu drift=(0,0)wu/s |
| `m_wraith` | `s_mon_wraith` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_shade` | `s_mon_shade` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 c4f8dce4ee2745cda0f211514605261b animationclip/clip delay=0s duration=0.65s scale=1 offset=(0,0.08)wu drift=(0,0)wu/s; L2 544b4092b87a41948b74e6645d530b88 animationclip/clip delay=0.12s duration=0.8s scale=0.9 offset=(0,0.05)wu drift=(0,0)wu/s |

