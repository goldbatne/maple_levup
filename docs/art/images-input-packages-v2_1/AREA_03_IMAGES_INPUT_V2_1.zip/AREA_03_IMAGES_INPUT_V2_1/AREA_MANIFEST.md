# AREA_03 Images Input Manifest — V2

- Area: `area_03` / 엘리니아
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: m_adv_bowmaster
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 11 | `m_slime` | 슬라임 | `s_mon_slime` | 끈적한 몸통 | 액티브 | N |
| 2 | 13 | `m_dark_stump` | 다크 스텀프 | `s_mon_dark_stump` | 단단한 밑동 | 버프 | N |
| 3 | 15 | `m_bubbling` | 버블링 | `s_mon_bubbling` | 물방울 마력 | 패시브 | N |
| 4 | 18 | `m_fairy` | 페어리 | `s_mon_fairy` | 요정의 마법가루 | 액티브 | N |
| 5 | 20 | `m_faust` | 파우스트 | `s_mon_faust` | 저주의 인형 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_slime` | `s_mon_slime` | AREA 00 승인 AnimationClip/ICON 바이트 재사용. 승인 보고서의 플레이어 좌우·몬스터 시전자 검증을 따르며 신규 생성하지 않음 |
| `m_dark_stump` | `s_mon_dark_stump` | 플레이어/몬스터 모두 자기 자신에게 효과 적용 성공 후 시전자 원점+h에 CAST 재생, FlipX 없음. L1 a77ea54c400e4b56a44ed05091a0ae53 animationclip/clip delay=0s duration=0.75s scale=0.7 offset=(0,0)wu drift=(0,0)wu/s; L2 566b0886b4cf4f3997a29ecd3a1954b5 animationclip/clip delay=0.1s duration=0.75s scale=0.55 offset=(0,0)wu drift=(0,0)wu/s |
| `m_bubbling` | `s_mon_bubbling` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_fairy` | `s_mon_fairy` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 9defa2b61ad94ae3bc50d707979770e6 animationclip/clip delay=0s duration=0.65s scale=0.42 offset=(-0.14,0.1)wu drift=(-0.12,0)wu/s; L2 9defa2b61ad94ae3bc50d707979770e6 animationclip/clip delay=0.12s duration=0.9s scale=0.7 offset=(0.14,0.15)wu drift=(0.12,0)wu/s |
| `m_faust` | `s_mon_faust` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 49b21aaa1d574ba787149841a31bf1a5는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 22444db0645d47f48f300f36b3d90e4b animationclip/clip delay=0s duration=0.9s scale=0.55 offset=(0,0.1)wu drift=(0,0)wu/s; L2 9051254fb84a4a898f3d99a213a896ec animationclip/clip delay=0.18s duration=0.75s scale=0.7 offset=(0,0.05)wu drift=(0,0)wu/s |

