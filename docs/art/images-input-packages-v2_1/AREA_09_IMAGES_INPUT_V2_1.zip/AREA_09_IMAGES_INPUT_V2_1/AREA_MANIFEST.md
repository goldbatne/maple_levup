# AREA_09 Images Input Manifest — V2

- Area: `area_09` / 엘나스 산맥
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 81 | `m_jr_yeti` | 주니어 예티 | `s_mon_jr_yeti` | 설인의 체온 | 패시브 | N |
| 2 | 83 | `m_dark_jr_yeti` | 다크 주니어 예티 | `s_mon_dark_jr_yeti` | 검은 설원의 은폐 | 패시브 | N |
| 3 | 85 | `m_hector` | 헥터 | `s_mon_hector` | 설원 늑대 발톱 | 액티브 | N |
| 4 | 88 | `m_white_fang` | 화이트팽 | `s_mon_white_fang` | 화이트팽의 빙설 송곳니 | 액티브 | N |
| 5 | 90 | `m_snow_witch` | 설산의 마녀 | `s_mon_snow_witch` | 추방자의 눈보라 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_jr_yeti` | `s_mon_jr_yeti` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_dark_jr_yeti` | `s_mon_dark_jr_yeti` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_hector` | `s_mon_hector` | 플레이어: 8방향으로 6.5wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 b9d0ab716c054c58a18c0c38b07695a5 animationclip/clip delay=0s duration=0.58s scale=0.82 offset=(0,0)wu drift=(1.0,0)wu/s; L2 7a41e40ee7d846908e29ec10b94630b0 animationclip/clip delay=0.12s duration=0.62s scale=0.78 offset=(0,0)wu drift=(0,0)wu/s |
| `m_white_fang` | `s_mon_white_fang` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 dd098279908940fa938d3c5cb3dda732 animationclip/clip delay=0s duration=0.65s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s; L2 9fae493a549a4396a2f1378c39f7386f animationclip/clip delay=0.15s duration=0.72s scale=0.85 offset=(0,0)wu drift=(0,0)wu/s |
| `m_snow_witch` | `s_mon_snow_witch` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 f55dd57a708e43238b64715c02bb06cc animationclip/clip delay=0s duration=0.72s scale=0.8 offset=(0,0)wu drift=(0,0)wu/s; L2 c5a807748e9443348e5b14162948f26b animationclip/clip delay=0.16s duration=0.8s scale=1.0 offset=(0,0)wu drift=(0,0)wu/s; L3 0719861214fa45578488a1083f49df5a animationclip/clip delay=0.3s duration=0.92s scale=1.2 offset=(0,0)wu drift=(0,0)wu/s |

