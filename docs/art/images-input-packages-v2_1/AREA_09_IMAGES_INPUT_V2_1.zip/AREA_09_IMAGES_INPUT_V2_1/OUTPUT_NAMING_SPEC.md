# Output Naming Spec

출력 루트: `AREA_09_IMAGES_OUTPUT/`

## 필수 규칙

- 기본 CAST/REFERENCE VFX: `NNN_[monster_id]_[skill_id]_F00.png`, `F01.png` ...
- 별도 PROJECTILE이 필요한 경우: `NNN_[monster_id]_[skill_id]_PROJECTILE.png` 또는 명세가 다프레임으로 확정한 경우 `_PROJECTILE_F00.png` ...
- 아이콘: `NNN_[monster_id]_[skill_id]_ICON.png`
- 선택 Preview: `NNN_[monster_id]_[skill_id]_CONTACT_PREVIEW.png`
- NNN은 AREA_MANIFEST의 3자리 작업 순번이며 monster_id/skill_id를 축약·번역하지 않는다.
- 원본 생성 시트가 있으면 `SOURCE_SHEET/`에 보존하고 `SHEET_SPLIT_MANIFEST.csv`에 source_file, role, frame_index, x, y, width, height 열로 분할 좌표를 기록한다.
- 결과 manifest 열은 work_order, area_id, monster_id, monster_name, skill_id, skill_name, skill_type, role, file, width, height, mode, sha256, auto_validation, user_art_approval 순서다.

```text
AREA_09_IMAGES_OUTPUT/
├─ OUTPUT_MANIFEST.md
├─ OUTPUT_MANIFEST.csv
├─ SOURCE_SHEET/                 # 원본 시트가 있을 때
├─ SHEET_SPLIT_MANIFEST.csv      # 분할했을 때
└─ monsters/
   └─ NNN_[monster_id]_[name]/
      ├─ VFX/
      ├─ PROJECTILE/             # 명세에 필요할 때만
      ├─ ICON/
      ├─ PREVIEW/                # 선택
      └─ RESULT_INFO.md
```

## V2.1 mandatory delivery contract

- 게임용 원본: 프레임 분리형 F00... RGBA PNG와 ICON 256×256 RGBA.
- 몬스터별 검수 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 MONSTER_IMAGE를 재생성·재해석하지 않고 그대로 합성한다.
- Area 검수 Preview: 출력 루트의 `AREA_OVERVIEW_PREVIEW.png` 필수.
- Preview는 검수 산출물이며 Resource Storage 반입 원본이 아니다.
- 원본 시트가 생성된 경우 시트와 분할 좌표를 보존하되 주 납품물은 분리 프레임이다.
- RGBA 표기뿐 아니라 실제 alpha, 잘림, 다른 셀 조각, 빈 프레임을 검사한다.
- 파일 검사 PASS와 사용자 아트 승인은 별도다. 도구 한도를 프롬프트로 해제하거나 무인 완주를 보장한다고 쓰지 않는다.
- 출력 루트는 `AREA_XX_IMAGES_OUTPUT`이며 ZIP 밖 절대경로에 의존하지 않는다.

