# AREA_18 Images Input Manifest — V2

- Area: `area_18` / 지구방위본부
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 171 | `m_mateon` | 마티안 | `s_mon_mateon` | 마티안 광선탄 | 액티브 | N |
| 2 | 173 | `m_plateon` | 플라티안 | `s_mon_plateon` | 외계 장갑 조종 | 패시브 | N |
| 3 | 175 | `m_mecateon` | 메카티안 | `s_mon_mecateon` | 기계화 레이저 | 액티브 | N |
| 4 | 178 | `m_chief_gray` | 원로 그레이 | `s_mon_chief_gray` | 원로의 정신연산 | 패시브 | N |
| 5 | 180 | `m_zeno` | 제노 | `s_mon_zeno` | 제노의 중력장 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_mateon` | `s_mon_mateon` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 22db356cc60940089b7f5d592c7d5813는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 70f170cb7f644da28dc93915a8e70dd9 animationclip/clip delay=0s duration=.65s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 e9d2e8cba2aa4245ae29cfb516746a04 animationclip/clip delay=.2s duration=.78s scale=1.08 offset=(0,0)wu drift=(0,0)wu/s |
| `m_plateon` | `s_mon_plateon` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_mecateon` | `s_mon_mecateon` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 50eff4b9b8064efa8db5246e7a912c4d animationclip/clip delay=0s duration=.72s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 1fe5c891382642d3aa35a89414f43fce animationclip/clip delay=.2s duration=.84s scale=1.12 offset=(0,0)wu drift=(0,0)wu/s |
| `m_chief_gray` | `s_mon_chief_gray` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_zeno` | `s_mon_zeno` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 908710847a0249c98cf8e935dfb1ddd8 animationclip/clip delay=0s duration=.82s scale=1.15 offset=(0,0)wu drift=(0,0)wu/s; L2 c68a17e01f83412882ac127cda104ee3 animationclip/clip delay=.24s duration=.96s scale=1.22 offset=(0,0)wu drift=(0,0)wu/s |

