# Runtime Role Map — m_plateon / s_mon_plateon

- 역할: ICON=런타임 필수; REFERENCE_VFX=기존 제작 범위에 포함된 비전투 참고 산출물(런타임 미사용·자동 반입 금지)
- 발생 위치: 런타임 시전자/발생점 없음. PlayerStats와 UI가 보유 수를 읽고 정액 스탯을 적용한다.
- 판정/재생: 피해 판정·시전·재생시간·반복 없음.
- 방향: 방향·FlipX·엔진 이동 없음.
- 현재 리소스: icon_ruid=thumbnail://e03cf5ce06784947b45ce95afb70927c
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - REFERENCE_VFX: 기존 명세 유지 6 frames × 256×256 RGBA; 런타임 미사용·자동 반입 금지
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## V2.1 실제 동작·납품 동기화

- actual_motion: 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_18_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

