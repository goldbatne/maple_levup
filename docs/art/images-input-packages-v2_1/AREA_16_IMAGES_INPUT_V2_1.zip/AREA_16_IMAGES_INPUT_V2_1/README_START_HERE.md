# START HERE — area_16 미나르숲 V2

1. PACKAGE_REVISION과 AREA_MANIFEST에서 범위와 보류를 확인한다.
2. 각 MONSTER_INFO/SOURCE_PROVENANCE/GENERATION_SPEC/RUNTIME_ROLE_MAP을 읽는다.
3. MASTER_PROMPT와 OUTPUT 규격을 따른다.
4. MONSTER_IMAGE는 재생성하지 않고 Preview에 그대로 합성한다.
5. STYLE_INDEX의 역할/시기 불확실성을 지키며 RECENT_SECONDARY를 최신으로 자동 승격하지 않는다.
6. 주 납품물은 역할별 개별 RGBA PNG이고 시트는 선택 Preview다.
7. 출력 루트는 `AREA_16_IMAGES_OUTPUT/`이다.

금지: 스킬 기획·게임 데이터 변경, 리소스 등록, AnimationClip 변경, 이미지 생성 완료를 파일 없이 선언.

## V2.1 mandatory delivery contract

- 게임용 원본: 프레임 분리형 F00... RGBA PNG와 ICON 256×256 RGBA.
- 몬스터별 검수 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 MONSTER_IMAGE를 재생성·재해석하지 않고 그대로 합성한다.
- Area 검수 Preview: 출력 루트의 `AREA_OVERVIEW_PREVIEW.png` 필수.
- Preview는 검수 산출물이며 Resource Storage 반입 원본이 아니다.
- 원본 시트가 생성된 경우 시트와 분할 좌표를 보존하되 주 납품물은 분리 프레임이다.
- RGBA 표기뿐 아니라 실제 alpha, 잘림, 다른 셀 조각, 빈 프레임을 검사한다.
- 파일 검사 PASS와 사용자 아트 승인은 별도다. 도구 한도를 프롬프트로 해제하거나 무인 완주를 보장한다고 쓰지 않는다.
- 출력 루트는 `AREA_XX_IMAGES_OUTPUT`이며 ZIP 밖 절대경로에 의존하지 않는다.

