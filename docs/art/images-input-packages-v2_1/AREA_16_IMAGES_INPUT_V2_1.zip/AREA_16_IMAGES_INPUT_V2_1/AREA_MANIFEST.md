# AREA_16 Images Input Manifest — V2

- Area: `area_16` / 미나르숲
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 151 | `m_harp` | 하프 | `s_mon_harp` | 하늘 둥지의 날갯결 | 패시브 | N |
| 2 | 153 | `m_blood_harp` | 블러드 하프 | `s_mon_blood_harp` | 핏빛 깃울림 | 액티브 | N |
| 3 | 155 | `m_blue_wyvern` | 블루 와이번 | `s_mon_blue_wyvern` | 빙룡 숨결 | 액티브 | N |
| 4 | 158 | `m_dark_wyvern` | 다크 와이번 | `s_mon_dark_wyvern` | 검은 비늘의 근력 | 패시브 | N |
| 5 | 160 | `m_manon` | 마뇽 | `s_mon_manon` | 마뇽의 용화염 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_harp` | `s_mon_harp` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_blood_harp` | `s_mon_blood_harp` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 1f2bdb3b15a145ea8f3db3fbfb61296b animationclip/clip delay=0s duration=0.68s scale=.95 offset=(0,0)wu drift=(0,0)wu/s; L2 518e72a0592d48b3b3e451be46a4f39e animationclip/clip delay=0.18s duration=0.78s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s |
| `m_blue_wyvern` | `s_mon_blue_wyvern` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 01663ed8b2a94562956e8029a79c03b5 animationclip/clip delay=0s duration=0.72s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 1215ca4153664cb18a207cddcc5ab22c animationclip/clip delay=0.2s duration=0.82s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s |
| `m_dark_wyvern` | `s_mon_dark_wyvern` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_manon` | `s_mon_manon` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 5ac6554c0ea94009bbd9389df0542339 animationclip/clip delay=0s duration=.72s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 b6b5849af24a416ab1680a1dced9697f animationclip/clip delay=0.17s duration=.76s scale=1.08 offset=(0,0)wu drift=(0,0)wu/s; L3 128fe611ea9347aab589c5b5d4d8fc5b animationclip/clip delay=0.34s duration=.82s scale=1.16 offset=(0,0)wu drift=(0,0)wu/s |

