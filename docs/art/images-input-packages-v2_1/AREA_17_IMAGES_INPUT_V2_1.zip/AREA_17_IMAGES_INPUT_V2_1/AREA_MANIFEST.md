# AREA_17 Images Input Manifest — V2

- Area: `area_17` / 시간의 신전
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 161 | `m_memory_monk` | 추억의 사제 | `s_mon_memory_monk` | 추억의 묵상 | 패시브 | N |
| 2 | 163 | `m_memory_monk_trainee` | 추억의 신관 | `s_mon_memory_monk_trainee` | 추억의 기도파 | 액티브 | N |
| 3 | 165 | `m_memory_guardian` | 추억의 수호병 | `s_mon_memory_guardian` | 수호병의 기억갑주 | 패시브 | N |
| 4 | 168 | `m_chief_memory_guardian` | 추억의 수호대장 | `s_mon_chief_memory_guardian` | 시간 수호진 | 액티브 | N |
| 5 | 170 | `m_dodo` | 도도 | `s_mon_dodo` | 기억 포식 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_memory_monk` | `s_mon_memory_monk` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_memory_monk_trainee` | `s_mon_memory_monk_trainee` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 1ea2d50c388645df9502190ef8092d94 animationclip/clip delay=0s duration=.72s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 c25e7243baaf4b21bb70ee10dcd33890 animationclip/clip delay=0.2s duration=.82s scale=1.08 offset=(0,0)wu drift=(0,0)wu/s |
| `m_memory_guardian` | `s_mon_memory_guardian` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_chief_memory_guardian` | `s_mon_chief_memory_guardian` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 4147dea424e9475ca1a61773421a3397 animationclip/clip delay=0s duration=.74s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 aa3d9ed3c4a3435298afcb494ac7fcac animationclip/clip delay=.22s duration=.86s scale=1.12 offset=(0,0)wu drift=(0,0)wu/s |
| `m_dodo` | `s_mon_dodo` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 72e16f10f6ec4cf0a1fe3146e73f0856는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 ee1dc1a6f4e6452b860a43ce291c62a3 animationclip/clip delay=0s duration=.8s scale=1.1 offset=(0,0)wu drift=(0,0)wu/s; L2 cf2fe8e1a8954e7099bd2243cfb908d7 animationclip/clip delay=.22s duration=.92s scale=1.18 offset=(0,0)wu drift=(0,0)wu/s |

