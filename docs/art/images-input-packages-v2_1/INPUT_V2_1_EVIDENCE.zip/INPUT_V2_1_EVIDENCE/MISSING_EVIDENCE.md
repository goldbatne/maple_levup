# MISSING EVIDENCE

| 자료 | 상태 | 이유 | 영향 |
|---|---|---|---|
| INPUT_V2_REVIEW_RESULTS.zip | 미확보 | 첨부 저장소·프로젝트·Downloads에 실제 파일 없음 | 검수 주장 자체는 적용하지 않고 독립 검사 수행 |
| 원 리소스 다운로드 바이트/cache | 미확보 | V2 provenance에도 원 cache가 보존되지 않음 | model RUID·현재 PNG SHA·육안 대조까지만 확인 |
| 대표 프레임 index | 미확보 | 기존 추출기가 max alpha bbox를 골랐으나 index를 기록하지 않음 | 선택 프레임을 확인했다고 주장하지 않음 |
| 현재 Maker 등록 SkillTable | 미확인 | 정상 경로 userdataset 삭제, Mislocated 후보의 등록 여부 불명 | 기준 commit+승인 map+후보 일치로 INPUT 데이터는 해소; 실제 런타임 등록은 미확인 |
| 11개 projectile 별도 신규 아트 승인 | 미확인 | V2는 CAST+ICON 범위였고 별도 승인 기록 없음 | 기존 projectile KEEP, 선택적 재제작은 NEEDS_DECISION; 필수 INPUT 제작은 가능 |
| 6개 dash의 계산 도착점과 CAST 부착점 일치 | 불일치 가능 | 피해는 계산 도착점, CAST는 서버가 보는 caster 위치 | INPUT에는 실제 코드대로 명시; 게임 코드 변경은 이번 범위 밖 |
