# INPUT V2.1 VALIDATION

- Area: 19
- monster placements: 99
- READY/BLOCKED: 19/0
- style resources: 183
- exact white unusable previews: 8
- projectile skills reviewed: 12
- dash target skills reviewed: 6

이 파일은 빌드 단계 결과다. 별도 `verify-area-images-input-v2_1.py`가 완성 ZIP을 다시 열어 독립 검증한다.
