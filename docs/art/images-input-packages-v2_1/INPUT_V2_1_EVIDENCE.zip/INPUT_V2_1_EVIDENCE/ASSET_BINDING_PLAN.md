# ASSET BINDING PLAN

99개 배치의 현행 필드·레이어와 신규 파일 연결 계획이다. 기존 레이어는 승인 전 KEEP하며, REPLACE_PLANNED는 게임 변경이 아니라 이후 반입 계획이다. 같은 RUID 반복은 BuildEffectLayers가 허용하지만 명세 근거 없이 새 클립을 모든 L1/L2에 복제하지 않는다.
