# INPUT V2.1 ADDITIONAL FINDINGS

## 확인된 INPUT 오류 — 보정

1. style index와 개별 info.md의 제외 역할/우선순위가 동기화되지 않음 → 183개 전부 동기화.
2. exact opaque-white preview는 실제 파일 검사상 8개로 감사 후보 8개와 일치 → usable=false, 분석 제외.
3. 돌진 actual_motion이 플레이어 동작만 기술 → 몬스터는 dash 분기가 없음을 분리 기재.
4. 돌진 충돌 VFX가 계산 도착점에 뜬다고 단정 → 실제로는 PlayCast 시점의 caster 서버 위치에 부착됨을 정정.
5. 스텀피는 CAST 필드가 없는데 generic CAST VFX로 기술 → PROJECTILE replacement 역할로 정정.
6. Preview가 선택 산출물처럼 남은 문서 → monster labeled preview와 Area overview preview를 필수 검수물로 통일.

## 게임 동작·기획 변경 필요 — 미변경

- 돌진 피해 좌표와 CAST 부착 좌표의 일치 보장은 코드 변경이 필요하다.
- 11개 복합 projectile 스킬의 비행체까지 새로 그릴지는 승인 근거가 없어 NEEDS_DECISION이다.

## 자료 부족

- 검수 ZIP, 원 다운로드 cache, 대표 프레임 index, 현재 Maker 등록 SkillTable은 미확보다.
