# INPUT V2.1 INDEPENDENT VALIDATION

- Area ZIP: 19/19 PASS
- placements/specs: 99/99
- style common hash: 1
- exact-white excluded: 8
- Area00 frozen: True
- V2 frozen: True
- errors: 0

이 검사는 ZIP 재개봉·CRC·고정 필드·style/info 동기화·alpha 프리뷰 판정·재사용 해시·증빙 manifest를 확인했다. 파일 검증은 사용자 아트 승인이 아니다.
