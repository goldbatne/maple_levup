# INPUT V2.1 CHANGELOG

- V2 19개 Area/99개 배치를 보존하고 별도 V2.1로 재패키징.
- 기준 커밋 `3e052a2166fb7aa0cdf1e75e79266d54ff51b6e1`의 SkillTable/UserDataSet 및 관련 데이터 증빙 확보.
- 정상 SkillTable 삭제와 Mislocated 후보를 분리하고 Area 00 승인 RUID 일치 근거 기록.
- 183개 style index와 모든 `skills/*/info.md`의 role/priority/preview usable 상태 동기화.
- exact opaque-white preview 8개를 `preview_usable=false`로 표시하고 주 스타일 분석에서 제외.
- 돌진 6종의 플레이어/몬스터 actual_motion 차이와 CAST 부착점 한계를 manifest/spec/runtime map에 동기화.
- 투사체 12종 검토: 스텀피 VFX를 PROJECTILE 역할로 교정, 나머지 기존 projectile은 KEEP+선택적 재제작 NEEDS_DECISION.
- 몬스터별 labeled preview와 AREA_OVERVIEW_PREVIEW를 필수 검수 납품물로 통일.
- 99개 배치에 대한 ASSET_BINDING_PLAN 작성. 게임·Area00·V2·OUTPUT 수정 없음.
