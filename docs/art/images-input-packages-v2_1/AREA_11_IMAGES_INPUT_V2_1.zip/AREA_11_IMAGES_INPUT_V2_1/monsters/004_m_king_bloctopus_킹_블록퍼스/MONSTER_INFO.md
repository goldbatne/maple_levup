# Monster Reference — 킹 블록퍼스

- 작업 순번: 004
- level: 108
- Area: `area_11` / 루더스 호수
- monster_id: `m_king_bloctopus`
- model_id: `kingbloctopus`
- image RUID: `cb5eb9faaf68477292af0b710e383c9d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_king_bloctopus`
- skill name/type: 왕관 블록탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/KingBloctopus.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `5731ea4edfeec3c35c94df1dcf03ad846b98f392ee907a128678c5cb0ffb16a1`
- image: 320×240 RGBA / alpha 0~255 / bbox [84, 21, 236, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
