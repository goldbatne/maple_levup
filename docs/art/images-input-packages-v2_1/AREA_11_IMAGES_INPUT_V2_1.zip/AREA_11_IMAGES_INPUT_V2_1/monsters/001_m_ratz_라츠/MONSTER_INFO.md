# Monster Reference — 라츠

- 작업 순번: 001
- level: 101
- Area: `area_11` / 루더스 호수
- monster_id: `m_ratz`
- model_id: `ratz`
- image RUID: `383e34f2a8584a96a01b80a8fadbb813`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ratz`
- skill name/type: 태엽쥐의 민첩 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Ratz.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `404956db2e27e394fa02a28b4bc7ce8665cdf998a8c055f4c11eac24403a547c`
- image: 320×240 RGBA / alpha 0~255 / bbox [10, 2, 309, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
