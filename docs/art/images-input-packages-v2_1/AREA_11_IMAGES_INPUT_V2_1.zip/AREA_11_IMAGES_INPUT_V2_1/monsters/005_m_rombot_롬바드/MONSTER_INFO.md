# Monster Reference — 롬바드

- 작업 순번: 005
- level: 110
- Area: `area_11` / 루더스 호수
- monster_id: `m_rombot`
- model_id: `rombot`
- image RUID: `b41def4288404055b3b8850daa99cfbf`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_rombot`
- skill name/type: 에오스 중력파 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Rombot.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `0e9f0f6821a216dffd2098cab78adc60b1a12337834ec8b6ea72827182f67d20`
- image: 320×240 RGBA / alpha 0~255 / bbox [64, 10, 257, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
