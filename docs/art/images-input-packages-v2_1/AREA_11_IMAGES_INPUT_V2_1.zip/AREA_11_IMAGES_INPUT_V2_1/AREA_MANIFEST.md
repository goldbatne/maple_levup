# AREA_11 Images Input Manifest — V2

- Area: `area_11` / 루더스 호수
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 101 | `m_ratz` | 라츠 | `s_mon_ratz` | 태엽쥐의 민첩 | 패시브 | N |
| 2 | 103 | `m_drumming_bunny` | 북치는 토끼 | `s_mon_drumming_bunny` | 태엽 북진동 | 액티브 | N |
| 3 | 105 | `m_bloctopus` | 블록퍼스 | `s_mon_bloctopus` | 블록 위장 | 패시브 | N |
| 4 | 108 | `m_king_bloctopus` | 킹 블록퍼스 | `s_mon_king_bloctopus` | 왕관 블록탄 | 액티브 | N |
| 5 | 110 | `m_rombot` | 롬바드 | `s_mon_rombot` | 에오스 중력파 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_ratz` | `s_mon_ratz` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_drumming_bunny` | `s_mon_drumming_bunny` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 91c5d5dd661e4e079271b4446f7eb262 animationclip/clip delay=0s duration=0.75s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_bloctopus` | `s_mon_bloctopus` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_king_bloctopus` | `s_mon_king_bloctopus` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid a2da67e687994755a8943c2bcf871902는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 e53471f0f7114343907be7beb520751f animationclip/clip delay=0.22s duration=0.65s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_rombot` | `s_mon_rombot` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 91c5d5dd661e4e079271b4446f7eb262 animationclip/clip delay=0s duration=0.72s scale=1.1 offset=(0,0)wu drift=(0,0)wu/s; L2 06bbe7d534094761b54b147f3a79ca38 animationclip/clip delay=0.18s duration=0.8s scale=0.8 offset=(0,0)wu drift=(0,0)wu/s |

