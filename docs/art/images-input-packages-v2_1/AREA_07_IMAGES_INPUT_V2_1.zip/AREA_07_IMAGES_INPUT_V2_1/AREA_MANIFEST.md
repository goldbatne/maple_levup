# AREA_07 Images Input Manifest — V2

- Area: `area_07` / 슬리피우드
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 6종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 61 | `m_zombie_mushroom` | 좀비버섯 | `s_mon_zombie_mushroom` | 죽은 포자의 끈기 | 패시브 | N |
| 2 | 63 | `m_copper_drake` | 카파 드레이크 | `s_mon_copper_drake` | 청동 비늘 | 패시브 | N |
| 3 | 65 | `m_drake` | 드레이크 | `s_mon_drake` | 동굴 용염 | 액티브 | N |
| 4 | 68 | `m_wild_kargo` | 와일드카고 | `s_mon_wild_kargo` | 야수의 그림자 돌진 | 액티브 | N |
| 5 | 70 | `m_jr_balrog` | 주니어 발록 | `s_mon_jr_balrog` | 발록의 화염 파동 | 액티브 | Y |
| 6 | 70 | `m_tauromacis` | 타우로마시스 | `s_mon_tauromacis` | 수문장의 낙뢰 | 액티브 | N |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_zombie_mushroom` | `s_mon_zombie_mushroom` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_copper_drake` | `s_mon_copper_drake` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_drake` | `s_mon_drake` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 5638984319fd476ca3d89e2aaca7f32a animationclip/clip delay=0s duration=0.65s scale=0.8 offset=(0,0)wu drift=(0,0)wu/s; L2 a610b14bbc55477cbc78777a5a2e7ed1 animationclip/clip delay=0.12s duration=0.78s scale=0.95 offset=(0,0)wu drift=(0,0)wu/s |
| `m_wild_kargo` | `s_mon_wild_kargo` | 플레이어: 8방향으로 6.2wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.52s scale=0.65 offset=(0,0)wu drift=(1.0,0)wu/s; L2 057c2da13da2492c95cb92db424803db animationclip/clip delay=0.04s duration=0.65s scale=0.72 offset=(0,0)wu drift=(0,0)wu/s |
| `m_jr_balrog` | `s_mon_jr_balrog` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 5638984319fd476ca3d89e2aaca7f32a animationclip/clip delay=0s duration=0.85s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 a610b14bbc55477cbc78777a5a2e7ed1 animationclip/clip delay=0.15s duration=0.7s scale=1.15 offset=(0,0)wu drift=(0,0)wu/s |
| `m_tauromacis` | `s_mon_tauromacis` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 3cbd85dcfe3c41c4989adec59385c257 animationclip/clip delay=0.08s duration=0.82s scale=1.2 offset=(0,0)wu drift=(0,0)wu/s |

