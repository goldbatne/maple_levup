# AREA_13 Images Input Manifest — V2

- Area: `area_13` / 니할 사막
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 121 | `m_white_sand_rabbit` | 흰 모래토끼 | `s_mon_white_sand_rabbit` | 사막 굴착탄 | 액티브 | N |
| 2 | 123 | `m_scarf_plead` | 목도리 프릴드 | `s_mon_scarf_plead` | 목도리의 사막감각 | 패시브 | N |
| 3 | 125 | `m_meercat` | 미요캐츠 | `s_mon_meercat` | 미요캐츠의 모래매복 | 액티브 | N |
| 4 | 128 | `m_sand_dwarf` | 모래난쟁이 | `s_mon_sand_dwarf` | 사막 대장장이의 체력 | 패시브 | N |
| 5 | 130 | `m_deo` | 데우 | `s_mon_deo` | 잠든 선인장의 폭발 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_white_sand_rabbit` | `s_mon_white_sand_rabbit` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 201c4ae9d7c24438b56fb4d731ed9245 animationclip/clip delay=0.12s duration=0.72s scale=0.85 offset=(0,0)wu drift=(0,0)wu/s |
| `m_scarf_plead` | `s_mon_scarf_plead` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_meercat` | `s_mon_meercat` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 412bce166c844b07ba1b4aa3ddcd53fa animationclip/clip delay=0s duration=0.74s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_sand_dwarf` | `s_mon_sand_dwarf` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_deo` | `s_mon_deo` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 98cd61bf1b2c4ff496455ad956cd95d5 animationclip/clip delay=0s duration=0.78s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s; L2 9af96df994cf4794882fec71c027da2b animationclip/clip delay=0.2s duration=0.9s scale=0.85 offset=(0,0)wu drift=(0,0)wu/s |

