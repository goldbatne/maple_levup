# AREA_14 Images Input Manifest — V2

- Area: `area_14` / 마가티아
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 131 | `m_cube_slime` | 큐브슬라임 | `s_mon_cube_slime` | 연금 큐브막 | 패시브 | N |
| 2 | 133 | `m_mithril_mutae` | 미스릴 뮤테 | `s_mon_mithril_mutae` | 미스릴 외피 | 패시브 | N |
| 3 | 135 | `m_homun` | 호문 | `s_mon_homun` | 플라스크 독무 | 액티브 | N |
| 4 | 138 | `m_roid` | 로이드 | `s_mon_roid` | 알카드노 에너지탄 | 액티브 | N |
| 5 | 140 | `m_chimera` | 키메라 | `s_mon_chimera` | 융합체의 산성 포격 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_cube_slime` | `s_mon_cube_slime` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_mithril_mutae` | `s_mon_mithril_mutae` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_homun` | `s_mon_homun` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 127defcb953144368b79da1417f8b4b4 animationclip/clip delay=0s duration=0.82s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_roid` | `s_mon_roid` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid e51545cbf94349f59f4431e2e76d2cdc는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 3ff44a80daba4bb4a903778e036f551d animationclip/clip delay=0.2s duration=0.72s scale=0.9 offset=(0,0)wu drift=(0,0)wu/s |
| `m_chimera` | `s_mon_chimera` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid ab113d9a5ca5402d85ecc2ab7a4f51a1는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 127defcb953144368b79da1417f8b4b4 animationclip/clip delay=0.2s duration=0.8s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s; L2 ec7b571a85244965b296d26e6511e06d animationclip/clip delay=0s duration=0.9s scale=0.85 offset=(0,0)wu drift=(0,0)wu/s |

