# AREA_10 Images Input Manifest — V2

- Area: `area_10` / 아쿠아로드
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 91 | `m_bubble_fish` | 버블피쉬 | `s_mon_bubble_fish` | 기포막 | 패시브 | N |
| 2 | 93 | `m_mask_fish` | 마스크피쉬 | `s_mon_mask_fish` | 가면 아래의 감각 | 패시브 | N |
| 3 | 95 | `m_squid` | 스퀴드 | `s_mon_squid` | 심해 먹물 폭발 | 액티브 | N |
| 4 | 98 | `m_shark` | 샤크 | `s_mon_shark` | 포식자의 수류탄 | 액티브 | N |
| 5 | 100 | `m_pianus` | 피아누스 | `s_mon_pianus` | 심해왕의 광선 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_bubble_fish` | `s_mon_bubble_fish` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_mask_fish` | `s_mon_mask_fish` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_squid` | `s_mon_squid` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 0906c3a7455940ce9e9db0b0f0278741 animationclip/clip delay=0.12s duration=0.82s scale=1.15 offset=(0,0)wu drift=(0,0)wu/s |
| `m_shark` | `s_mon_shark` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid 209c4567073b424e8d445cea7efb80e3는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. L1 a6ab8a49e4174a29bd45a835ed6d3460 animationclip/clip delay=0.22s duration=0.72s scale=1.0 offset=(0,0)wu drift=(0,0)wu/s |
| `m_pianus` | `s_mon_pianus` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 3822f5bc47af488585cef2f0929ec811 animationclip/clip delay=0s duration=0.82s scale=1.2 offset=(0,0)wu drift=(0,0)wu/s; L2 306a9aafa3fb43498f1b783b85512305 animationclip/clip delay=0.25s duration=0.95s scale=1.35 offset=(0,0)wu drift=(0,0)wu/s |

