# AREA_02 Images Input Manifest — V2

- Area: `area_02` / 페리온
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 8종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 10 | `m_stone_golem` | 스톤골렘 | `s_mon_stone` | 암석 피부 | 버프 | N |
| 2 | 18 | `m_axe_stump` | 엑스텀프 | `s_mon_axe_stump` | 도끼 휘두르기 | 액티브 | N |
| 3 | 22 | `m_dark_axe_stump` | 다크 엑스텀프 | `s_mon_dark_axe_stump` | 어둠의 뿌리 | 액티브 | N |
| 4 | 26 | `m_wild_boar` | 와일드보어 | `s_mon_wild_boar` | 저돌 맹진 | 액티브 | N |
| 5 | 28 | `m_iron_hog` | 아이언 호그 | `s_mon_iron_hog` | 강철 발굽 | 패시브 | N |
| 6 | 30 | `m_skeleton_commander` | 스켈레톤 지휘관 | `s_mon_skeleton_commander` | 뼈 무덤 | 액티브 | N |
| 7 | 32 | `m_fire_boar` | 파이어보어 | `s_mon_fire_boar` | 화염 돌풍 | 액티브 | N |
| 8 | 42 | `m_stumpy` | 스텀피 | `s_mon_stumpy` | 고목의 생기탄 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_stone_golem` | `s_mon_stone` | 플레이어/몬스터 모두 자기 자신에게 효과 적용 성공 후 시전자 원점+h에 CAST 재생, FlipX 없음. L1 05113e9dc86448cb8581731824106d75 animationclip/clip delay=0s duration=0.65s scale=0.8 offset=(0,-0.06)wu drift=(0,0)wu/s; L2 86734a2715504c10b1e50ae810609e25 animationclip/clip delay=0.12s duration=0.72s scale=0.9 offset=(0,-0.06)wu drift=(0,0)wu/s |
| `m_axe_stump` | `s_mon_axe_stump` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.55s scale=0.7 offset=(0.05,0)wu drift=(0.3,0)wu/s; L2 997628810df4448f9e534bc426d6794a animationclip/clip delay=0.14s duration=0.48s scale=0.62 offset=(0.65,0)wu drift=(0,0)wu/s |
| `m_dark_axe_stump` | `s_mon_dark_axe_stump` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 a77ea54c400e4b56a44ed05091a0ae53 animationclip/clip delay=0s duration=0.82s scale=0.82 offset=(-0.28,-0.12)wu drift=(0,0)wu/s; L2 a77ea54c400e4b56a44ed05091a0ae53 animationclip/clip delay=0.12s duration=0.82s scale=0.82 offset=(0.28,-0.12)wu drift=(0,0)wu/s |
| `m_wild_boar` | `s_mon_wild_boar` | 플레이어: 8방향으로 5.0wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.55s scale=0.75 offset=(-0.15,-0.15)wu drift=(0,0)wu/s; L2 79c9b3b094dd49eda90e80d178f0ff28 animationclip/clip delay=0.16s duration=0.65s scale=0.7 offset=(0.55,-0.12)wu drift=(0,0)wu/s |
| `m_iron_hog` | `s_mon_iron_hog` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_skeleton_commander` | `s_mon_skeleton_commander` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 db2b67de20f5418cb7b5050ce0641df1 animationclip/clip delay=0s duration=0.58s scale=0.55 offset=(0,-0.08)wu drift=(0,0)wu/s; L2 05113e9dc86448cb8581731824106d75 animationclip/clip delay=0.1s duration=0.62s scale=0.75 offset=(-0.25,-0.05)wu drift=(0,0)wu/s; L3 997628810df4448f9e534bc426d6794a animationclip/clip delay=0.18s duration=0.5s scale=0.6 offset=(0.25,0)wu drift=(0,0)wu/s |
| `m_fire_boar` | `s_mon_fire_boar` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.52s scale=0.45 offset=(-0.15,-0.15)wu drift=(0,0)wu/s; L2 a610b14bbc55477cbc78777a5a2e7ed1 animationclip/clip delay=0.1s duration=0.7s scale=0.95 offset=(0.25,0)wu drift=(0,0)wu/s |
| `m_stumpy` | `s_mon_stumpy` | CAST는 시전자 원점+h에서 재생하고 projectile_ruid c6b3f052e977479ea5ad5329ce0981ca는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. CAST 레이어 없음 |

