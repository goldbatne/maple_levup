# GENERATION SPEC — 스텀피 / 고목의 생기탄

## 확정 데이터

- 작업 순번: 008
- 레벨: 42
- Area: `area_02` / 페리온
- monster_id: `m_stumpy`
- 몬스터 이름: 스텀피
- monster image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- skill_id: `s_mon_stumpy`
- 최종 스킬 이름: **고목의 생기탄**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 실제 현재 효과: INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- 실제 현재 동작: 투사체 c6b3f052e977479ea5ad5329ce0981ca가 목표 방향으로 이동

## 원작/지역 연결

[P][A] 고목형 몬스터와 생기는 연결 가능하나 ‘빼앗은 생기’와 생기탄은 확인되지 않았다.

## 시각 번역

- 핵심 소재: 고목 나이테에서 싹이 돋아 에너지 씨앗으로 압축되는 탄. ‘스텀피 / 고목의 생기탄’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 고목 갈색 #75533A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 생기 연두 #8ED35B; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 효과 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지). layer drift는 엔진 적용: 현행 레이어 없음
- 대상 표현: 조준 지점은 그림에 캐릭터로 표시하지 않는다. 현재 전용 IMPACT 출력은 요구하지 않는다.
- 화면 점유율: 큼(캐릭터 2~3배, 화면을 가리지 않음); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 높음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: CAST는 발사 준비 → 방출 섬광 → 짧은 잔광. PROJECTILE은 동일 중심축에서 자체 회전/맥동만 하며 위치 이동은 엔진에 맡긴다.
- 판정 정렬: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘싹튼 나이테’, 보조 효과 1개는 ‘생기탄’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BOSS_ACTIVE`
- VFX: 12 frames, 각 512×512 RGBA PNG, 약 0.08 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 판정/재생: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 방향: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지).
- 현재 리소스: ; projectile_ruid=c6b3f052e977479ea5ad5329ce0981ca
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 12 frames × 512×512 RGBA, 0.08s/frame
  - PROJECTILE: 현행 projectile_ruid를 그대로 유지하며 이번 V2 신규 생성 범위에는 포함하지 않음
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## V2.1 실제 동작·납품 동기화

- actual_motion: CAST는 시전자 원점+h에서 재생하고 projectile_ruid c6b3f052e977479ea5ad5329ce0981ca는 엔진이 목표까지 0.35초 이동·회전. 피해는 도착 타이머 뒤 착탄점에서 판정. CAST 레이어 없음
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_02_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

