# GENERATION SPEC — 와일드보어 / 저돌 맹진

## 확정 데이터

- 작업 순번: 004
- 레벨: 26
- Area: `area_02` / 페리온
- monster_id: `m_wild_boar`
- 몬스터 이름: 와일드보어
- monster image RUID: `af64c62c1dcf427998c3c52f0a060fec`
- skill_id: `s_mon_wild_boar`
- 최종 스킬 이름: **저돌 맹진**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 실제 현재 효과: ATK 계수 1.5로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5 거리 돌진
- 실제 현재 동작: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.55/0.65초; 시전자가 목표 방향으로 돌진

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 와일드보어의 모델 ID·RUID와 페리온 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 멧돼지 어금니를 닮은 두 갈래 전방 압축선과 흙먼지. ‘와일드보어 / 저돌 맹진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 황토 갈색 #9B633D; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 먼지 금갈 #D6A65D; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 조준 8방향으로 5 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다. layer drift는 엔진 적용: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.55s, scale=0.75, offset=(-0.15,-0.15) world unit, drift=(0,0) world unit/s; L2 ruid=79c9b3b094dd49eda90e80d178f0ff28, type=animationclip, style=clip, delay=0.16s, duration=0.65s, scale=0.7, offset=(0.55,-0.12) world unit, drift=(0,0) world unit/s
- 대상 표현: 도착점 주변 피격 범위만 읽히게 하고 이동 경로 전체를 범위로 오인시키지 않는다.
- 화면 점유율: 작음(캐릭터 0.7~1.1배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 도착점 압축 → 충돌 절정 → 파편/잔상 소멸. 출발부터 도착까지의 전신 이동을 시트 안에서 반복하지 않는다.
- 판정 정렬: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘쌍 어금니’, 보조 효과 1개는 ‘돌진 흙먼지’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `LOW_ACTIVE`
- VFX: 8 frames, 각 256×256 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 런타임 역할·반입 계약

- 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 발생 위치: 플레이어는 조준 8방향으로 5 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 판정/재생: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 방향: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다.
- 현재 리소스: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.55s, scale=0.75, offset=(-0.15,-0.15) world unit, drift=(0,0) world unit/s; L2 ruid=79c9b3b094dd49eda90e80d178f0ff28, type=animationclip, style=clip, delay=0.16s, duration=0.65s, scale=0.7, offset=(0.55,-0.12) world unit, drift=(0,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 256×256 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## V2.1 실제 동작·납품 동기화

- actual_motion: 플레이어: 8방향으로 5.0wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.55s scale=0.75 offset=(-0.15,-0.15)wu drift=(0,0)wu/s; L2 79c9b3b094dd49eda90e80d178f0ff28 animationclip/clip delay=0.16s duration=0.65s scale=0.7 offset=(0.55,-0.12)wu drift=(0,0)wu/s
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_02_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

