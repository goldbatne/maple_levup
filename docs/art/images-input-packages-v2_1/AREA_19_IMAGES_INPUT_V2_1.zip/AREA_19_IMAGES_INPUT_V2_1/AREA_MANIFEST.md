# AREA_19 Images Input Manifest — V2

- Area: `area_19` / 미래의 문
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 181 | `m_official_knight_c` | 정식기사 C | `s_mon_official_knight_c` | 기사단 뇌전 연각 | 액티브 | N |
| 2 | 183 | `m_official_knight_d` | 정식기사 D | `s_mon_official_knight_d` | 기사단의 바람 조준 | 패시브 | N |
| 3 | 185 | `m_advanced_knight_a` | 상급기사 A | `s_mon_advanced_knight_a` | 그림자 기사의 민첩 | 패시브 | N |
| 4 | 188 | `m_advanced_knight_b` | 상급기사 B | `s_mon_advanced_knight_b` | 상급기사의 이프리트 화염 | 액티브 | N |
| 5 | 190 | `m_cygnus` | 시그너스 | `s_mon_cygnus` | 타락한 여제의 정원 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_official_knight_c` | `s_mon_official_knight_c` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 1a648542a3b447f594b5c331cf44503f animationclip/clip delay=0s duration=.7s scale=1 offset=(0,0)wu drift=(0,0)wu/s; L2 439308ddd0bf4405a8463340c67a464b animationclip/clip delay=.17s duration=.78s scale=1.1 offset=(0,0)wu drift=(0,0)wu/s |
| `m_official_knight_d` | `s_mon_official_knight_d` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_advanced_knight_a` | `s_mon_advanced_knight_a` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_advanced_knight_b` | `s_mon_advanced_knight_b` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 89e2fa1739754ade99ddca6ca3653182 animationclip/clip delay=0s duration=.78s scale=1.05 offset=(0,0)wu drift=(0,0)wu/s; L2 8a8c83af487246b89a8f4e4ff92edd66 animationclip/clip delay=.2s duration=.88s scale=1.14 offset=(0,0)wu drift=(0,0)wu/s |
| `m_cygnus` | `s_mon_cygnus` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 1c8327eff1fa4321bef0fe5410a6ddef animationclip/clip delay=0s duration=.9s scale=1.18 offset=(0,0)wu drift=(0,0)wu/s; L2 875053c636494f6d807b803dd95bc3eb animationclip/clip delay=.28s duration=1.02s scale=1.28 offset=(0,0)wu drift=(0,0)wu/s |

