# Package Revision V2

```json
{
  "revision": "V2",
  "base_zip": "docs/art/images-input-packages/AREA_05_IMAGES_INPUT.zip",
  "base_zip_sha256": "c0b71e676137787cc9380f9dbc2e6cad21f34655fec55d0c8bcf8e9199166242",
  "area_id": "area_05",
  "area_name": "노틸러스",
  "scope": "INPUT 문서·검증·재사용 파일 보정만; 게임 데이터/아트/리소스 미변경",
  "skill_table_source": {
    "source": "git:HEAD:RootDesk/MyDesk/GameData/SkillTable.csv",
    "state": "HEAD_fallback_working_file_missing",
    "sha256": "f0cb65e6390c3f154d91abbcc622b76c93aa1ca8bf0baf81d57bfe8f3b0f0d69"
  },
  "status": "READY",
  "unresolved": []
}
```
