# Area 분위기 자료

- 상태: 확보
- 프로젝트 타일 원본: `docs/art/tiles/nautilus`
- 합성 대상: 00_sand_1.png, 01_sand_2.png, 02_deck.png, 03_water.png
- 용도: 색감·바닥 대비 참고만 사용. 타일을 VFX에 직접 복제하지 않는다.
