# Monster Reference — 파란 리본돼지

- 작업 순번: 002
- level: 43
- Area: `area_05` / 노틸러스
- monster_id: `m_blue_pig`
- model_id: `bluepig`
- image RUID: `cba2695db0034210a59cd88b5894457b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_pig`
- skill name/type: 푸른 리본 매듭 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BluePig.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `536e87c0262b9684422acfed020bb857a8ba27c9bc193b4ba98a2696d27ee7e1`
- image: 320×240 RGBA / alpha 0~255 / bbox [15, 0, 304, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
