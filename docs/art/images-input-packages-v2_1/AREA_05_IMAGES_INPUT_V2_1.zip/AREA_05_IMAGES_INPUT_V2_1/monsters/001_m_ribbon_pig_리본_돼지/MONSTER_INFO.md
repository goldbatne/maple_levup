# Monster Reference — 리본 돼지

- 작업 순번: 001
- level: 41
- Area: `area_05` / 노틸러스
- monster_id: `m_ribbon_pig`
- model_id: `ribbonpig`
- image RUID: `6a699b8c31b94474bb795c7394c3af3b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_ribbon_pig`
- skill name/type: 리본 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/RibbonPig.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `5e7217c47490fd759c3cd29e7a011a2f15cd5d54855fc893ac7e3d851500287a`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 23, 320, 234]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
