# Runtime Role Map — m_ribbon_pig / s_mon_ribbon_pig

- 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 발생 위치: 플레이어는 조준 8방향으로 5.5 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 판정/재생: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 방향: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다.
- 현재 리소스: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.52s, scale=0.55, offset=(-0.1,-0.05) world unit, drift=(0,0) world unit/s; L2 ruid=057c2da13da2492c95cb92db424803db, type=animationclip, style=clip, delay=0.04s, duration=0.65s, scale=0.58, offset=(0.2,0) world unit, drift=(0.9,0) world unit/s
- 필요 파일:
  - ICON: 256×256 RGBA 1장
  - CAST_VFX: 8 frames × 384×384 RGBA, 0.10s/frame
- 좌표 단위: layer offset은 world unit, drift는 world unit/s. 픽셀 피봇/최종 Resource Storage offset은 이번 INPUT 단계에서 확정하지 않는다.
- 반복: 현행 CAST 레이어는 one-shot. 지속 버프 시간과 VFX 재생 수명은 별개.

## V2.1 실제 동작·납품 동기화

- actual_motion: 플레이어: 8방향으로 5.5wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.52s scale=0.55 offset=(-0.1,-0.05)wu drift=(0,0)wu/s; L2 057c2da13da2492c95cb92db424803db animationclip/clip delay=0.04s duration=0.65s scale=0.58 offset=(0.2,0)wu drift=(0.9,0)wu/s
- 몬스터별 Preview: `PREVIEW/labeled_preview.png` 필수. INPUT의 `MONSTER_IMAGE.png`를 변형 없이 합성한다.
- Area Preview: `AREA_05_IMAGES_OUTPUT/AREA_OVERVIEW_PREVIEW.png` 필수.
- 아트 캔버스: 기존 출력 프로필의 프레임 수·픽셀 크기를 유지하고 모든 프레임 동일 캔버스·동일 중심축·실제 alpha로 만든다.
- 기준점: 등록 계획 pivot은 normalized `(0.5,0.5)`이며 autocrop/recenter 금지. 최종 world scale/offset은 labeled preview 확인 전 임의 확정하지 않는다.
- 이미지 내부 변화와 엔진 이동: 준비·형성·충돌·소멸 같은 국소 변화만 프레임 안에서 표현한다. projectile 이동, dash 이동, layer drift, FlipX는 엔진 역할과 중복하지 않는다.

