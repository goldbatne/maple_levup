# AREA_05 Images Input Manifest — V2

- Area: `area_05` / 노틸러스
- 대상: 실제 방 배치 중 drop_skill_id가 있는 포획 가능 몬스터 5종
- 제외된 비포획 방 배치: 없음
- READY는 제작 INPUT 준비 상태이며 아트 승인/게임 반입 성공을 뜻하지 않는다.

| 순번 | Lv | monster_id | 몬스터 | skill_id | 스킬 | 타입 | 보스 |
|---:|---:|---|---|---|---|---|:---:|
| 1 | 41 | `m_ribbon_pig` | 리본 돼지 | `s_mon_ribbon_pig` | 리본 돌진 | 액티브 | N |
| 2 | 43 | `m_blue_pig` | 파란 리본돼지 | `s_mon_blue_pig` | 푸른 리본 매듭 | 패시브 | N |
| 3 | 45 | `m_starfish` | 불가사리 | `s_mon_starfish` | 별가시 회전 | 액티브 | N |
| 4 | 48 | `m_jellyfish` | 쿨 젤리피쉬 | `s_mon_jellyfish` | 차가운 젤리 | 패시브 | N |
| 5 | 60 | `m_king_clang` | 킹크랑 | `s_mon_king_clang` | 왕게의 집게 파도 | 액티브 | Y |

## V2.1 actual_motion sync

| monster_id | skill_id | actual_motion |
|---|---|---|
| `m_ribbon_pig` | `s_mon_ribbon_pig` | 플레이어: 8방향으로 5.5wu를 0.2초 이동하고 계산 도착점에서 피해 판정; 직후 CAST는 서버가 보는 시전자 위치에 부착되어 계산 도착점과 일치가 보장되지 않음. 몬스터: dash_distance 분기 없이 즉시 시전자 중심 원형 판정 후 명중 시 CAST. L1 0207c85c05dd4c4eac12f9ee735d0545 animationclip/clip delay=0s duration=0.52s scale=0.55 offset=(-0.1,-0.05)wu drift=(0,0)wu/s; L2 057c2da13da2492c95cb92db424803db animationclip/clip delay=0.04s duration=0.65s scale=0.58 offset=(0.2,0)wu drift=(0.9,0)wu/s |
| `m_blue_pig` | `s_mon_blue_pig` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_starfish` | `s_mon_starfish` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 69656381a8e04edcbb8a2c8599567ab3 animationclip/clip delay=0s duration=0.55s scale=0.55 offset=(0,0)wu drift=(0,0)wu/s; L2 2c12c1e835a04c2a9ec1c5724846a7b6 animationclip/clip delay=0.06s duration=0.68s scale=0.72 offset=(0,0)wu drift=(0,0)wu/s |
| `m_jellyfish` | `s_mon_jellyfish` | 런타임 VFX 없음. 보유 효과는 PlayerStats가 적용하며 REFERENCE_VFX는 제작 검수용·자동 반입 금지 |
| `m_king_clang` | `s_mon_king_clang` | 플레이어: 즉시 시전자 중심 원형 피해 판정 후 CAST. 몬스터: 축소 반경의 시전자 중심 원형 판정이 실제 명중한 경우에만 CAST. CAST는 시전자 원점+h, 좌측 대상/시선이면 FlipX. L1 c57b15ccc8dd408b98c627617144d3cd animationclip/clip delay=0s duration=0.64s scale=1.0 offset=(0,0)wu drift=(0,0)wu/s; L2 8394705c13394b78a8b9a38e1313cb22 animationclip/clip delay=0.16s duration=0.78s scale=1.3 offset=(0,0)wu drift=(0,0)wu/s |

