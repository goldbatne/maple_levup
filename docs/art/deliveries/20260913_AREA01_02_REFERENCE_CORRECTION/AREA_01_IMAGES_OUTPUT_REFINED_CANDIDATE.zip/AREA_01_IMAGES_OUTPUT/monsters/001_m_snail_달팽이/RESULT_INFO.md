# 이슬 미끄럼길

Status: REVIEW_CANDIDATE
monster_id: m_snail
skill_id: s_mon_snail_dew_trail
type: 액티브
actual_effect: ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: layer_ruids 1개; 타입 animationclip; 스타일 clip; 지연 0초; 지속 0.8초
Method: 00 동일 스킬 보정 후보 재사용
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
