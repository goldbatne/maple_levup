# 단단한 뿔

Status: REVIEW_CANDIDATE
monster_id: m_horny_mushroom
skill_id: s_mon_horny_mushroom
type: 패시브
actual_effect: 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2
actual_motion: 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시
Method: native 신규 제작 (기존 아트 마감 미달)
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
