# 푸른 껍질

Status: REVIEW_CANDIDATE
monster_id: m_blue_snail
skill_id: s_mon_blue_snail
type: 버프
actual_effect: 자신에게 3초 동안 피해 40% 감소
actual_motion: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.85/0.7초
Method: 00 동일 스킬 보정 후보 재사용
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
