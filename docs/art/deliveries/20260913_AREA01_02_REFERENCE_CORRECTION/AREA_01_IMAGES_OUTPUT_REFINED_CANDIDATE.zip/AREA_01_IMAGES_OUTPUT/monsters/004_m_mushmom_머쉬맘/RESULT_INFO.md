# 머쉬맘의 포자 충격

Status: REVIEW_CANDIDATE
monster_id: m_mushmom
skill_id: s_mon_mushmom
type: 액티브
actual_effect: ATK 계수 1.35로 반경 4.2 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.22초; 지속 0.75/0.72/0.7초
Method: native 신규 제작 (기존 아트 마감 미달)
Timing: 80ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
