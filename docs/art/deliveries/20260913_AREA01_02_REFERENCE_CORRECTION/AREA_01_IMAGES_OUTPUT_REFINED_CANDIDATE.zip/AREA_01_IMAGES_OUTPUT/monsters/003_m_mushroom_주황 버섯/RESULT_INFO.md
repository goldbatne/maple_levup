# 포자 살포

Status: REVIEW_CANDIDATE
monster_id: m_mushroom
skill_id: s_mon_mushroom
type: 액티브
actual_effect: INT 계수 1.1로 반경 2.5 범위 대상 제한 없음 피해; 4초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.08/0.16초; 지속 0.55/0.6/0.65초
Method: native 신규 제작 (기존 아트 마감 미달)
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
