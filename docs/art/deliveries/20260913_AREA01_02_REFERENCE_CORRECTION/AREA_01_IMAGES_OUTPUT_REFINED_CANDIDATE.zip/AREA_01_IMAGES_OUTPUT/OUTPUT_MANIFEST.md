# AREA 01 corrected candidate

REVIEW_CANDIDATE / NOT USER_APPROVED
5 skills. See OUTPUT_MANIFEST.csv for exact files and checksums.
Passive: ICON is runtime deliverable; optional old VFX only for reference.
