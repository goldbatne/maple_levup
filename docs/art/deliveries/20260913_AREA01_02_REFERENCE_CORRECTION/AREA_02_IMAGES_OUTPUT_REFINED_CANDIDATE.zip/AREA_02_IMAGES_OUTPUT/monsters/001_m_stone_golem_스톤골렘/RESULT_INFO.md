# 암석 피부

Status: REVIEW_CANDIDATE
monster_id: m_stone_golem
skill_id: s_mon_stone
type: 버프
actual_effect: 자신에게 5초 동안 피해 50% 감소
actual_motion: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.65/0.72초
Method: 원화 보존·마지막 두 프레임 alpha fade
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
