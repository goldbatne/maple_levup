# 고목의 생기탄

Status: REVIEW_CANDIDATE
monster_id: m_stumpy
skill_id: s_mon_stumpy
type: 액티브
actual_effect: INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: 투사체 c6b3f052e977479ea5ad5329ce0981ca가 목표 방향으로 이동
Method: 원화 보존·마지막 두 프레임 alpha fade
Timing: 80ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
