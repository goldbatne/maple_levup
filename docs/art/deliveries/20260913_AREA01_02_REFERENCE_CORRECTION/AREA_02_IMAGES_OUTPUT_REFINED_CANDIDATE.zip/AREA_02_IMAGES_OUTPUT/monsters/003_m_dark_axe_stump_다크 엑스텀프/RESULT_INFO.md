# 어둠의 뿌리

Status: REVIEW_CANDIDATE
monster_id: m_dark_axe_stump
skill_id: s_mon_dark_axe_stump
type: 액티브
actual_effect: INT 계수 1.5로 반경 4 범위 대상 제한 없음 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.12초; 지속 0.82/0.82초
Method: 원화 보존·마지막 두 프레임 alpha fade
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
