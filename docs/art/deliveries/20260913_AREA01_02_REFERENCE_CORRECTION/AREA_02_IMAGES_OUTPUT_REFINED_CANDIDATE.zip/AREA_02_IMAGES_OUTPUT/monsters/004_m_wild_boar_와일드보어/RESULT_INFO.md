# 저돌 맹진

Status: REVIEW_CANDIDATE
monster_id: m_wild_boar
skill_id: s_mon_wild_boar
type: 액티브
actual_effect: ATK 계수 1.5로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5 거리 돌진
actual_motion: layer_ruids 2개; 타입 animationclip/animationclip; 스타일 clip/clip; 지연 0/0.16초; 지속 0.55/0.65초; 시전자가 목표 방향으로 돌진
Method: 원화 보존·마지막 두 프레임 alpha fade
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
