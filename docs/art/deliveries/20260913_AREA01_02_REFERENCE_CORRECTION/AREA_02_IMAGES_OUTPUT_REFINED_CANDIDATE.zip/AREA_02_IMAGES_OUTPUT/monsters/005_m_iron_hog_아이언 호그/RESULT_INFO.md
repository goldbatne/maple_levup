# 강철 발굽

Status: REVIEW_CANDIDATE
monster_id: m_iron_hog
skill_id: s_mon_iron_hog
type: 패시브
actual_effect: 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2
actual_motion: 현행 런타임 VFX 없음; 인벤토리/스킬 UI 아이콘으로만 표시
Method: 미변경, 비런타임 참고 VFX 6장 보존
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
