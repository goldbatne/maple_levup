# 뼈 무덤

Status: REVIEW_CANDIDATE
monster_id: m_skeleton_commander
skill_id: s_mon_skeleton_commander
type: 액티브
actual_effect: ATK 계수 2로 반경 5 범위 최대 2대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
actual_motion: layer_ruids 3개; 타입 animationclip/animationclip/animationclip; 스타일 clip/clip/clip; 지연 0/0.1/0.18초; 지속 0.58/0.62/0.5초
Method: 원화 보존·마지막 두 프레임 alpha fade·상단 조각 제거
Timing: 100ms
Runtime validation: NOT_CHECKED
Model: native image generation/editing — version/model unverified
