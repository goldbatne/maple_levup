# AREA 02 corrected candidate

REVIEW_CANDIDATE / NOT USER_APPROVED
8 skills. See OUTPUT_MANIFEST.csv for exact files and checksums.
Passive: ICON is runtime deliverable; optional old VFX only for reference.
