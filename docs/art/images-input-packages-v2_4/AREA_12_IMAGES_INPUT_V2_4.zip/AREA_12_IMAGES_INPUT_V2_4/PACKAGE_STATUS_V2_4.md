# Package status — area_12 / V2.4

| Axis | Status |
|---|---|
| PACKAGE_VALIDATION | PASS_BUILD; see global independent validation |
| GENERATION_READY | READY |
| IMPORT_VALIDATION | NOT_READY_ASSETS_NOT_GENERATED |
| RUNTIME_VALIDATION | NOT_RUN |
| ART_APPROVAL | NOT_REVIEWED |
