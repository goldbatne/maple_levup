# AREA MANIFEST — V2.3

FULL_ART_SCOPE.csv와 OUTPUT_REQUIREMENTS.csv가 역할별 제작 범위 원장이다. 확정 기획/런타임 수치는 V2.2에서 변경하지 않았다.

| order | monster | skill | roles | decisions | production | import | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_brown_teddy` | `s_mon_brown_teddy` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 2 | `m_toy_trojan` | `s_mon_toy_trojan` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 3 | `m_master_robo` | `s_mon_master_robo` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 4 | `m_chronos` | `s_mon_chronos` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 5 | `m_timer` | `s_mon_timer` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
