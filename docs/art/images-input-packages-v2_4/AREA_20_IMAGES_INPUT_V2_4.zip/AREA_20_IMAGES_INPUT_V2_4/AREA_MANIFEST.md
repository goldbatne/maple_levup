# AREA MANIFEST — V2.3

FULL_ART_SCOPE.csv와 OUTPUT_REQUIREMENTS.csv가 역할별 제작 범위 원장이다. 확정 기획/런타임 수치는 V2.2에서 변경하지 않았다.

| order | monster | skill | roles | decisions | production | import | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_mutant_dark_stump` | `s_mon_mutant_dark_stump` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 2 | `m_mutant_iron_hog` | `s_mon_mutant_iron_hog` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 3 | `m_mutant_stone_mask` | `s_mon_mutant_stone_mask` | ICON|REFERENCE_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | UNRESOLVED |
| 4 | `m_ancient_dark_golem` | `s_mon_ancient_dark_golem` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
| 5 | `m_mutant_stumpy` | `s_mon_mutant_stumpy` | ICON|CAST_VFX | NEW_ART|NEW_ART | READY | NOT_READY_ASSETS_NOT_GENERATED | NOT_RUN |
