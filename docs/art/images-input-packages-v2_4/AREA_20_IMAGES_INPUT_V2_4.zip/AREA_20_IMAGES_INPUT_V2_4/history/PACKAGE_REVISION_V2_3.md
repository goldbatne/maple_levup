# PACKAGE REVISION — V2.3

- source: `AREA_20_IMAGES_INPUT_V2_2.zip`
- source_sha256: `42390d854ca31fd9b022adc3bdf41a832667038eb96ffb08b7f609c2b66b2517`
- built_utc: `2026-09-12T02:28:54.043642+00:00`
- scope change: full actual visual-asset production coverage
- images/OUTPUT/resources/game files changed: `false`
