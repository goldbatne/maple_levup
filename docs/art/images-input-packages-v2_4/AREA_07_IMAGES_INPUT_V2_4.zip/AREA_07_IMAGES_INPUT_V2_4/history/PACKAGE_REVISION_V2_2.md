# PACKAGE REVISION — V2.2

- source: `AREA_07_IMAGES_INPUT_V2_1.zip`
- source_sha256: `e880bd8b425333195c78b95b1b0045252b2e5ad289bc3d20f7cd80679e1c25ef`
- built_utc: `2026-09-12T01:40:25.405586+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
