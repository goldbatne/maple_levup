# Monster Reference — 좀비버섯

- 작업 순번: 001
- level: 61
- Area: `area_07` / 슬리피우드
- monster_id: `m_zombie_mushroom`
- model_id: `zombiemushroom`
- image RUID: `3ee3fc0f4d2e443cbb9ec424dd2c012f`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_zombie_mushroom`
- skill name/type: 죽은 포자의 끈기 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/ZombieMushroom.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9325d54b671ddc5204146a4d3572e7a16a45ccce8c5e30c23727efd7a7fc1f69`
- image: 320×240 RGBA / alpha 0~255 / bbox [47, 0, 273, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
