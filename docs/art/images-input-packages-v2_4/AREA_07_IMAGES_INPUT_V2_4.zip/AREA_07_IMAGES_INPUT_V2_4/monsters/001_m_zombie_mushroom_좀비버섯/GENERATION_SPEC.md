# GENERATION SPEC — 좀비버섯 / 죽은 포자의 끈기

## 확정 데이터

- 작업 순번: 001
- 레벨: 61
- Area: `area_07` / 슬리피우드
- monster_id: `m_zombie_mushroom`
- 몬스터 이름: 좀비버섯
- monster image RUID: `3ee3fc0f4d2e443cbb9ec424dd2c012f`
- skill_id: `s_mon_zombie_mushroom`
- 최종 스킬 이름: **죽은 포자의 끈기**
- 스킬 타입: **패시브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): 보유만 해도 INT +1; 중복 1장당 +0.25, 5장 최대 +2
- 확인된 런타임 효과: 보유 수량 기반 INT 컬렉션 포인트 계산 후보. GameDataVerify/PlayerStats 지원 여부는 별도 런타임 상태를 따른다.
- 확인된 런타임 동작: CAST 호출 없음. PlayerStats가 보유 수량을 읽어 스탯을 계산한다. REFERENCE_VFX는 제작 검수용이며 runtime_use=false다.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 좀비버섯의 모델 ID·RUID와 슬리피우드 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 마른 포자 덩이가 꺼지지 않고 다시 붙는 탁한 생기. ‘좀비버섯 / 죽은 포자의 끈기’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 죽은 포자 회갈 #827768; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 병든 녹색 #7E9A58; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: ICON=런타임 필수; REFERENCE_VFX=기존 제작 범위에 포함된 비전투 참고 산출물(런타임 미사용·자동 반입 금지)
- 효과 발생 위치: 런타임 시전자/발생점 없음. PlayerStats와 UI가 보유 수를 읽고 정액 스탯을 적용한다.
- 진행 방향·엔진 이동: 방향·FlipX·엔진 이동 없음. 없음
- 대상 표현: 런타임 대상 없음. 아이콘은 보유 효과를 식별하는 UI 자산이며 몬스터 본체 전체를 넣지 않는다.
- 화면 점유율: 작음(캐릭터 몸통의 0.5~0.8배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: REFERENCE_VFX를 만들 경우 정지 모티브의 짧은 호흡만 표현한다. 공격 준비·타격광·투사체·폭발 단계는 넣지 않는다.
- 판정 정렬: 피해 판정·시전·재생시간·반복 없음.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘갈라진 포자핵’, 보조 효과 1개는 ‘되붙는 점’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.
- 현행 패시브에는 런타임 VFX가 없다. VFX 결과는 비전투 참고 모티브로 표시하고 자동 반입하지 않는다.

## 출력 프로필

- ICON: NEW_ART / ICON/001_m_zombie_mushroom_s_mon_zombie_mushroom_ICON.png / 256x256 RGBA
- REFERENCE_VFX: NEW_ART / REFERENCE/001_m_zombie_mushroom_s_mon_zombie_mushroom_REFERENCE_F00.png..._REFERENCE_F05.png / 6 frames × 256x256 RGBA / 0.10s per frame / preview-only non-loop
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.4 전체 아트 제작 계약

- required_roles: `ICON|REFERENCE_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|none`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=NEW_ART; field=icon_ruid; files=ICON/001_m_zombie_mushroom_s_mon_zombie_mushroom_ICON.png; target=icon_ruid
- CAST_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PROJECTILE: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=input_reference_only; decision=NEW_ART; field=reference source; not runtime field; files=REFERENCE/001_m_zombie_mushroom_s_mon_zombie_mushroom_REFERENCE_F00.png..._REFERENCE_F05.png; target=none

### Shared constraints

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
