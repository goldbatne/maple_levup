# Monster Reference — 타우로마시스

- 작업 순번: 006
- level: 70
- Area: `area_07` / 슬리피우드
- monster_id: `m_tauromacis`
- model_id: `tauromacis`
- image RUID: `5ef751fd743e41609bf98e03de4df51c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_tauromacis`
- skill name/type: 수문장의 낙뢰 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Tauromacis.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `61330eb0e3a6da6846d833e72dbaa4561f3dd00733f4fd34f59826e03b579657`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 1, 320, 238]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
