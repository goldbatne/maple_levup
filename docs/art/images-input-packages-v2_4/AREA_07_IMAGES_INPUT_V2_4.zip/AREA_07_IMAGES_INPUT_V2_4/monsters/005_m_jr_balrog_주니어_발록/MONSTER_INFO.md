# Monster Reference — 주니어 발록

- 작업 순번: 005
- level: 70
- Area: `area_07` / 슬리피우드
- monster_id: `m_jr_balrog`
- model_id: `jrbalrog`
- image RUID: `4b3ad414c1184c02b5eb459b29ee8ece`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_jr_balrog`
- skill name/type: 발록의 화염 파동 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/JrBalrog.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `e9aebccdeeddb2512027a9d74fcab0cba94f6b1aa5ed2f76b6d988025c17356c`
- image: 320×240 RGBA / alpha 0~255 / bbox [37, 0, 283, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
