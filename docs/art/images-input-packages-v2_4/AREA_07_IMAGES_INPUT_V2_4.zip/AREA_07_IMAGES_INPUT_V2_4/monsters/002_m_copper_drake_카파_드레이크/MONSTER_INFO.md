# Monster Reference — 카파 드레이크

- 작업 순번: 002
- level: 63
- Area: `area_07` / 슬리피우드
- monster_id: `m_copper_drake`
- model_id: `copperdrake`
- image RUID: `da160cd4b78c479ab8dfaa225b2dcd47`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_copper_drake`
- skill name/type: 청동 비늘 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/CopperDrake.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a59b934824fc81a8ab2e38e430edaaf8269eae45c443d1652c5bc2ca692884c7`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 17, 320, 223]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
