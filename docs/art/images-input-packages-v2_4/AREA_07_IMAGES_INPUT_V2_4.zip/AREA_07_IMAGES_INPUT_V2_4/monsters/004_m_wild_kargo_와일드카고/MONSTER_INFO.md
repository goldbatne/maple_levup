# Monster Reference — 와일드카고

- 작업 순번: 004
- level: 68
- Area: `area_07` / 슬리피우드
- monster_id: `m_wild_kargo`
- model_id: `wildkargo`
- image RUID: `7d1c1d17eff44687b35ca0d5108084dc`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wild_kargo`
- skill name/type: 야수의 그림자 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/WildKargo.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `5c97846d841cb41ca40c11a705bdecea46a02562297f65eff1b4190eb651da8f`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 29, 320, 212]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
