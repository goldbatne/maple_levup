# Monster Reference — 드레이크

- 작업 순번: 003
- level: 65
- Area: `area_07` / 슬리피우드
- monster_id: `m_drake`
- model_id: `drake`
- image RUID: `f8cfac4e30394735861603f6bfcb1932`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_drake`
- skill name/type: 동굴 용염 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Drake.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `746a1d598523bcd13b041d931244179a187bcedebacd295f67f69d39c421522d`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 17, 320, 223]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
