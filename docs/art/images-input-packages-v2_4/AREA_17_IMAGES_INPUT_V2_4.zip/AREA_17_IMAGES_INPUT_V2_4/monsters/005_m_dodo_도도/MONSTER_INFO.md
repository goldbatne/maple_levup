# Monster Reference — 도도

- 작업 순번: 005
- level: 170
- Area: `area_17` / 시간의 신전
- monster_id: `m_dodo`
- model_id: `dodo`
- image RUID: `2d63f90f9d464f7192713ad9209e9e63`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dodo`
- skill name/type: 기억 포식 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Dodo.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `6833204e847f7adc339c56e264abbb6d18bda6ae746fd5d3733eceab28fffa2d`
- image: 320×240 RGBA / alpha 0~255 / bbox [23, 3, 288, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
