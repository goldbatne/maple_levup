# Monster Reference — 추억의 신관

- 작업 순번: 002
- level: 163
- Area: `area_17` / 시간의 신전
- monster_id: `m_memory_monk_trainee`
- model_id: `memorymonktrainee`
- image RUID: `699e78db5d3a48578388d33dc333258a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_memory_monk_trainee`
- skill name/type: 추억의 기도파 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MemoryMonkTrainee.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `0d4ad6317b9fdb870ca9d9ce473431b3b9200e018cc8ccf837ffdc831016febe`
- image: 320×240 RGBA / alpha 0~255 / bbox [88, 1, 232, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
