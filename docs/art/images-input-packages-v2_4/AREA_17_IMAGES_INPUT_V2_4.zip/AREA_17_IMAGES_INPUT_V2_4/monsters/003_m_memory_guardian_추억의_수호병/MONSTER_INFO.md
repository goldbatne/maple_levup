# Monster Reference — 추억의 수호병

- 작업 순번: 003
- level: 165
- Area: `area_17` / 시간의 신전
- monster_id: `m_memory_guardian`
- model_id: `memoryguardian`
- image RUID: `0b258556de2e401e97014ae48fe96b7a`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_memory_guardian`
- skill name/type: 수호병의 기억갑주 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MemoryGuardian.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `56ccd51c51ef311e705c92242aa4315cc287a48ef063639d5c4993e69f43cbc6`
- image: 320×240 RGBA / alpha 0~255 / bbox [79, 10, 241, 232]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
