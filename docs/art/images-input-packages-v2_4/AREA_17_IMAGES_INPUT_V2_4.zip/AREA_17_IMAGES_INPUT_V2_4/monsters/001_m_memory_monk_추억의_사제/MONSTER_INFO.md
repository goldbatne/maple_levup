# Monster Reference — 추억의 사제

- 작업 순번: 001
- level: 161
- Area: `area_17` / 시간의 신전
- monster_id: `m_memory_monk`
- model_id: `memorymonk`
- image RUID: `36ff7a667243465caef855b4fb7b9f84`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_memory_monk`
- skill name/type: 추억의 묵상 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MemoryMonk.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `343e1bdd7b13d2a81b58e8bf12d7ea0e604a4841968653cbcdd10ca58d27739d`
- image: 320×240 RGBA / alpha 0~255 / bbox [117, 1, 203, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
