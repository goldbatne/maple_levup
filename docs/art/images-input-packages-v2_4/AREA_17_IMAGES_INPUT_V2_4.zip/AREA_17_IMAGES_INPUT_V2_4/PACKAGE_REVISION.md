# Package Revision V2

```json
{
  "revision": "V2",
  "base_zip": "docs/art/images-input-packages/AREA_17_IMAGES_INPUT.zip",
  "base_zip_sha256": "dfa211c9e2bfcb307ccd58448dc0133c8569cd2f60227470aab114509117a0ee",
  "area_id": "area_17",
  "area_name": "시간의 신전",
  "scope": "INPUT 문서·검증·재사용 파일 보정만; 게임 데이터/아트/리소스 미변경",
  "skill_table_source": {
    "source": "git:HEAD:RootDesk/MyDesk/GameData/SkillTable.csv",
    "state": "HEAD_fallback_working_file_missing",
    "sha256": "f0cb65e6390c3f154d91abbcc622b76c93aa1ca8bf0baf81d57bfe8f3b0f0d69"
  },
  "status": "READY",
  "unresolved": []
}
```
