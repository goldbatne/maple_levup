# PACKAGE REVISION — V2.3

- source: `AREA_17_IMAGES_INPUT_V2_2.zip`
- source_sha256: `1d4353b23314972ed1c94205abb67995409b2503b2b0e67769bb9b93db70c669`
- built_utc: `2026-09-12T02:28:34.733218+00:00`
- scope change: full actual visual-asset production coverage
- images/OUTPUT/resources/game files changed: `false`
