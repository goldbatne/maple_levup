# PACKAGE REVISION — V2.2

- source: `AREA_17_IMAGES_INPUT_V2_1.zip`
- source_sha256: `e6228d31fb29a9088c738cd35cdf7edc7cd0f6c61ef1dd3c0fe4d21895c3c803`
- built_utc: `2026-09-12T01:41:25.795105+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
