# GENERATION SPEC — 파란 달팽이 / 푸른 껍질

## 확정 데이터

- 작업 순번: 002
- 레벨: 3
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_blue_snail`
- 몬스터 이름: 파란 달팽이
- monster image RUID: `0c69164656d24f64bd1a1f6ee4019dff`
- skill_id: `s_mon_blue_snail`
- 최종 스킬 이름: **푸른 껍질**
- 스킬 타입: **버프**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): 자신에게 3초 동안 피해 40% 감소
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어/몬스터 모두 자기 효과 적용 성공 후 시전자 위치에서 방향 반전 없이 CAST한다. L1 delay=0s duration=0.85s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.12s duration=0.7s offset=(0,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 파란 달팽이의 모델 ID·RUID와 메이플 아일랜드·리스항구 | 헤네시스 근교 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 겹친 껍질 결을 닮은 반원형 보호막과 짧은 반사광. ‘파란 달팽이 / 푸른 껍질’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 푸른 껍질 청색 #4E9EDB; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 물빛 백청 #C9F4FF; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=자기 몸에 붙는 버프 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어/몬스터 시전자 원점에 붙여 재생. 방향 반전하지 않는다.
- 진행 방향·엔진 이동: 무방향. 닫힌 보호 윤곽과 자기 중심 맥동만 사용한다. layer drift는 엔진 적용: L1 ruid=566b0886b4cf4f3997a29ecd3a1954b5, type=animationclip, style=clip, delay=0s, duration=0.85s, scale=0.65, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.12s, duration=0.7s, scale=0.75, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 자신만 감싼다. 다른 대상, 타격점, 공격 폭발은 표시하지 않는다.
- 화면 점유율: 중소형(캐릭터 중심 0.8~1.2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음~중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 시전자 둘레 윤곽 출현 → 보호 구조 닫힘 → 반사광 절정 → 실드 지속과 혼동되지 않게 짧게 페이드.
- 판정 정렬: 실드 적용 성공 뒤 CAST_VFX가 시작되며, 지속 효과 시간과 VFX 수명은 별도 값이다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘푸른 껍질 아치’, 보조 효과 1개는 ‘흰 반사광’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 출력 프로필

- ICON: AREA00_APPROVED_REUSE / approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png / 256x256 RGBA
- CAST_VFX: AREA00_APPROVED_REUSE / approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png / 8 frames × 256x256 RGBA / 0.1s per frame / approved existing
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.4 전체 아트 제작 계약

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid|approved existing layer_ruids`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=AREA00_APPROVED_REUSE; field=icon_ruid; files=approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png; target=icon_ruid -> approved_icon_ruid=6e7da13ea5924763bebb7aa4b851eb96
- CAST_VFX: current=true; decision=AREA00_APPROVED_REUSE; field=layer_ruids; files=approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png; target=layer_ruids -> approved_animationclip_ruid=f1fc98b763c24a0bb99d8ce8453a4c8f
- PROJECTILE: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none

### Area 00 approved reuse evidence

- ICON baseline/current evidence: `73c1bdafcb7e42bc8db0041883226449`
- ICON approved target RUID: `6e7da13ea5924763bebb7aa4b851eb96`
- ICON source_path: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png`
- ICON output_path: `AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png`
- ICON preview_reference_files: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/labeled_preview.png`
- CAST_VFX baseline/current evidence: `L1:566b0886b4cf4f3997a29ecd3a1954b5 animationclip/clip delay=0s duration=0.85s scale=0.65 offset=(0,0)wu drift=(0,0)wu/s; L2:86734a2715504c10b1e50ae810609e25 animationclip/clip delay=0.12s duration=0.7s scale=0.75 offset=(0,0)wu drift=(0,0)wu/s`
- CAST_VFX approved target RUID: `f1fc98b763c24a0bb99d8ce8453a4c8f`
- CAST_VFX source_path: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png`
- CAST_VFX output_path: `AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F00.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F01.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F02.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F03.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F04.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F05.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F06.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F07.png`
- CAST_VFX preview_reference_files: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/labeled_preview.png`
- 승인 근거: Area 00 resource map과 V2.2 approved binding 값이 일치함. 게임 RUID는 이 INPUT revision에서 변경하지 않는다.

### Shared constraints

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
