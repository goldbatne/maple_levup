# Runtime Role Map — m_blue_snail / s_mon_blue_snail — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png` | 1f / 256x256 RGBA / static / static | `73c1bdafcb7e42bc8db0041883226449` | `6e7da13ea5924763bebb7aa4b851eb96` | `icon_ruid -> approved_icon_ruid=6e7da13ea5924763bebb7aa4b851eb96` | none |
| CAST_VFX | true · layer_ruids | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png` | 8f / 256x256 RGBA / 0.1 / approved existing | `L1:566b0886b4cf4f3997a29ecd3a1954b5 animationclip/clip delay=0s duration=0.85s scale=0.65 offset=(0,0)wu drift=(0,0)wu/s; L2:86734a2715504c10b1e50ae810609e25 animationclip/clip delay=0.12s duration=0.7s scale=0.75 offset=(0,0)wu drift=(0,0)wu/s` | `f1fc98b763c24a0bb99d8ce8453a4c8f` | `layer_ruids -> approved_animationclip_ruid=f1fc98b763c24a0bb99d8ce8453a4c8f` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid -> approved_icon_ruid=6e7da13ea5924763bebb7aa4b851eb96|layer_ruids -> approved_animationclip_ruid=f1fc98b763c24a0bb99d8ce8453a4c8f`
- confirmed design effect preserved: 자신에게 3초 동안 피해 40% 감소
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어/몬스터 모두 자기 효과 적용 성공 후 시전자 위치에서 방향 반전 없이 CAST한다. L1 delay=0s duration=0.85s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.12s duration=0.7s offset=(0,0)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

## Area 00 approved reuse

- ICON baseline/current evidence: `73c1bdafcb7e42bc8db0041883226449`
- ICON approved target RUID: `6e7da13ea5924763bebb7aa4b851eb96`
- source_path: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png`
- output_path: `AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/ICON/002_m_blue_snail_s_mon_blue_snail_ICON.png`
- preview_reference_files: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/labeled_preview.png`
- CAST_VFX baseline/current evidence: `L1:566b0886b4cf4f3997a29ecd3a1954b5 animationclip/clip delay=0s duration=0.85s scale=0.65 offset=(0,0)wu drift=(0,0)wu/s; L2:86734a2715504c10b1e50ae810609e25 animationclip/clip delay=0.12s duration=0.7s scale=0.75 offset=(0,0)wu drift=(0,0)wu/s`
- CAST_VFX approved target RUID: `f1fc98b763c24a0bb99d8ce8453a4c8f`
- source_path: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F00.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F01.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F02.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F03.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F04.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F05.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F06.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/VFX/002_m_blue_snail_s_mon_blue_snail_F07.png`
- output_path: `AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F00.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F01.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F02.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F03.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F04.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F05.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F06.png|AREA_01_IMAGES_OUTPUT/monsters/002_m_blue_snail_파란_달팽이/CAST/002_m_blue_snail_s_mon_blue_snail_CAST_F07.png`
- preview_reference_files: `approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/002_m_blue_snail_s_mon_blue_snail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/002_m_blue_snail_파란_달팽이/PREVIEW/labeled_preview.png`

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
