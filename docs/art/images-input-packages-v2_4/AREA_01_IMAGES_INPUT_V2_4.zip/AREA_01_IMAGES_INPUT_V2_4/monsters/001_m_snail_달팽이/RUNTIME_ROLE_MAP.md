# Runtime Role Map — m_snail / s_mon_snail_dew_trail — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png` | 1f / 256x256 RGBA / static / static | `c0699b32529049c68de3d13022479bf9` | `c0699b32529049c68de3d13022479bf9` | `icon_ruid -> approved_icon_ruid=c0699b32529049c68de3d13022479bf9` | none |
| CAST_VFX | true · layer_ruids | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png` | 8f / 384x384 RGBA / 0.1 / approved existing | `L1:6097484d513a4fde82ad15557fdc81d3 animationclip/clip delay=0s duration=0.8s scale=1 offset=(0,0)wu drift=(0,0)wu/s` | `6097484d513a4fde82ad15557fdc81d3` | `layer_ruids -> approved_animationclip_ruid=6097484d513a4fde82ad15557fdc81d3` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid -> approved_icon_ruid=c0699b32529049c68de3d13022479bf9|layer_ruids -> approved_animationclip_ruid=6097484d513a4fde82ad15557fdc81d3`
- confirmed design effect preserved: ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.8s offset=(0,0)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

## Area 00 approved reuse

- ICON baseline/current evidence: `c0699b32529049c68de3d13022479bf9`
- ICON approved target RUID: `c0699b32529049c68de3d13022479bf9`
- source_path: `approved_reuse/AREA_00/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png`
- output_path: `AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/ICON/001_m_snail_s_mon_snail_dew_trail_ICON.png`
- preview_reference_files: `approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/labeled_preview.png`
- CAST_VFX baseline/current evidence: `L1:6097484d513a4fde82ad15557fdc81d3 animationclip/clip delay=0s duration=0.8s scale=1 offset=(0,0)wu drift=(0,0)wu/s`
- CAST_VFX approved target RUID: `6097484d513a4fde82ad15557fdc81d3`
- source_path: `approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F00.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F01.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F02.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F03.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F04.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F05.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F06.png|approved_reuse/AREA_00/001_m_snail_달팽이/VFX/001_m_snail_s_mon_snail_dew_trail_F07.png`
- output_path: `AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F00.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F01.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F02.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F03.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F04.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F05.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F06.png|AREA_01_IMAGES_OUTPUT/monsters/001_m_snail_달팽이/CAST/001_m_snail_s_mon_snail_dew_trail_CAST_F07.png`
- preview_reference_files: `approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/001_m_snail_s_mon_snail_dew_trail_CONTACT_PREVIEW.png|approved_reuse/AREA_00/001_m_snail_달팽이/PREVIEW/labeled_preview.png`

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
