# PACKAGE REVISION — V2.2

- source: `AREA_04_IMAGES_INPUT_V2_1.zip`
- source_sha256: `6c756421be26db6941046a4665e02c14ef64cd836d744c2985e002316626ceb2`
- built_utc: `2026-09-12T01:40:13.496568+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
