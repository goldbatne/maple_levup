# Output Naming Spec — V2.3

Output root: `AREA_04_IMAGES_OUTPUT/`

- CAST: `NNN_[monster_id]_[skill_id]_CAST_F00.png` ...
- PROJECTILE: `NNN_[monster_id]_[skill_id]_PROJECTILE_F00.png` ...
- REFERENCE: `NNN_[monster_id]_[skill_id]_REFERENCE_F00.png` ...
- ICON: `NNN_[monster_id]_[skill_id]_ICON.png`
- HIT/PERSISTENT files are forbidden unless FULL_ART_SCOPE marks the role NEW_ART. Current V2.3 marks none.
- Each role uses a separate folder and frame sequence. CAST and PROJECTILE must not share a generic VFX filename.
- `PREVIEW/labeled_preview.png` and root `AREA_OVERVIEW_PREVIEW.png` are mandatory review files.
- A separate contact sheet is optional and cannot replace mandatory previews or frame-separated PNGs.
- SOURCE_SHEET and split coordinates are retained if a source sheet was used; no autocrop/recenter.
