# Runtime Role Map — m_ribbon_pig / s_mon_ribbon_pig — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/001_m_ribbon_pig_s_mon_ribbon_pig_ICON.png` | 1f / 256x256 RGBA / static / static | `n/a` | `n/a` | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/001_m_ribbon_pig_s_mon_ribbon_pig_CAST_F00.png..._CAST_F07.png` | 8f / 384x384 RGBA / 0.10 / non-loop one-shot | `n/a` | `n/a` | `layer_ruids` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids`
- confirmed design effect preserved: ATK 계수 1.8로 단일 대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8; 5.5 거리 돌진
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어는 8방향으로 5.5wu를 0.2초 이동하고 계산 도착점에서 피해를 판정한다. PlayCast는 직후 서버가 보는 시전자 위치를 사용하므로 CAST 위치와 계산 피해점의 일치는 보장되지 않는다. 몬스터는 dash 분기 없이 시전자 중심 원형 판정 후 명중 시 CAST한다. L1 delay=0s duration=0.52s offset=(-0.1,-0.05)wu drift=(0,0)wu/s; L2 delay=0.04s duration=0.65s offset=(0.2,0)wu drift=(0.9,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
