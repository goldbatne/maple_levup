# PACKAGE REVISION — V2.4

- source: `AREA_14_IMAGES_INPUT_V2_3.zip`
- source_sha256: `3235f0fa792bee4aa45e2de3954101a3affd5a91b88425d13e9e3337503ff70f`
- review_source: `INPUT_V2_3_REVIEW_RESULTS.zip` / `490f14c6f6dada8d23c9c5036a5c009d7e6f848f0fe5d3adaf2b2fc413c59bb2`
- built_utc: `2026-09-12T03:21:52.745808+00:00`
- scope: limited current-document, projectile role wording, and Area 00 approved-reuse contract correction
- production scope reduced: `false`
- images/OUTPUT/resources/game files changed: `false`
