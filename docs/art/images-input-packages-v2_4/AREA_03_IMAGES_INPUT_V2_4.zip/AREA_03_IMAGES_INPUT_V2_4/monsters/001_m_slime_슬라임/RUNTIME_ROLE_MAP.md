# Runtime Role Map — m_slime / s_mon_slime — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/005_m_slime_슬라임/ICON/005_m_slime_s_mon_slime_ICON.png` | 1f / 256x256 RGBA / static / static | `72d1dd0939714240bddc0b6865eb93ce` | `79543e5ad88d423ba676e55d69aa432c` | `icon_ruid -> approved_icon_ruid=79543e5ad88d423ba676e55d69aa432c` | none |
| CAST_VFX | true · layer_ruids | AREA00_APPROVED_REUSE | `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F00.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F01.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F02.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F03.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F04.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F05.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F06.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F07.png` | 8f / 256x256 RGBA / 0.1 / approved existing | `L1:2c12c1e835a04c2a9ec1c5724846a7b6 animationclip/clip delay=0s duration=0.62s scale=0.48 offset=(0.18,0)wu drift=(0.35,0)wu/s; L2:69656381a8e04edcbb8a2c8599567ab3 animationclip/clip delay=0.12s duration=0.52s scale=0.55 offset=(0.5,0)wu drift=(0,0)wu/s` | `0ea4bec10d4c43f3aaded74dec60ca44` | `layer_ruids -> approved_animationclip_ruid=0ea4bec10d4c43f3aaded74dec60ca44` | none |
| PROJECTILE | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX`
- production_decisions: `AREA00_APPROVED_REUSE|AREA00_APPROVED_REUSE`
- future_targets: `icon_ruid -> approved_icon_ruid=79543e5ad88d423ba676e55d69aa432c|layer_ruids -> approved_animationclip_ruid=0ea4bec10d4c43f3aaded74dec60ca44`
- confirmed design effect preserved: ATK 계수 1.15로 단일 대상 피해; 4초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- runtime_motion preserved: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.62s offset=(0.18,0)wu drift=(0.35,0)wu/s; L2 delay=0.12s duration=0.52s offset=(0.5,0)wu drift=(0,0)wu/s.
- targeting_range=n/a / impact_radius=n/a / impact_delay=n/a / max_targets=n/a

## Area 00 approved reuse

- ICON baseline/current evidence: `72d1dd0939714240bddc0b6865eb93ce`
- ICON approved target RUID: `79543e5ad88d423ba676e55d69aa432c`
- source_path: `approved_reuse/AREA_00/005_m_slime_슬라임/ICON/005_m_slime_s_mon_slime_ICON.png`
- output_path: `AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/ICON/001_m_slime_s_mon_slime_ICON.png`
- preview_reference_files: `approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/005_m_slime_s_mon_slime_CONTACT_PREVIEW.png|approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/labeled_preview.png`
- CAST_VFX baseline/current evidence: `L1:2c12c1e835a04c2a9ec1c5724846a7b6 animationclip/clip delay=0s duration=0.62s scale=0.48 offset=(0.18,0)wu drift=(0.35,0)wu/s; L2:69656381a8e04edcbb8a2c8599567ab3 animationclip/clip delay=0.12s duration=0.52s scale=0.55 offset=(0.5,0)wu drift=(0,0)wu/s`
- CAST_VFX approved target RUID: `0ea4bec10d4c43f3aaded74dec60ca44`
- source_path: `approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F00.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F01.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F02.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F03.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F04.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F05.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F06.png|approved_reuse/AREA_00/005_m_slime_슬라임/VFX/005_m_slime_s_mon_slime_F07.png`
- output_path: `AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F00.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F01.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F02.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F03.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F04.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F05.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F06.png|AREA_03_IMAGES_OUTPUT/monsters/001_m_slime_슬라임/CAST/001_m_slime_s_mon_slime_CAST_F07.png`
- preview_reference_files: `approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/005_m_slime_s_mon_slime_CONTACT_PREVIEW.png|approved_reuse/AREA_00/005_m_slime_슬라임/PREVIEW/labeled_preview.png`

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
