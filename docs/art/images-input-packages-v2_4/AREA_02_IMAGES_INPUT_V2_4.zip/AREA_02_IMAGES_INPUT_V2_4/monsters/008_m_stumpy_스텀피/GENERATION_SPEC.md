# GENERATION SPEC — 스텀피 / 고목의 생기탄

## 확정 데이터

- 작업 순번: 008
- 레벨: 42
- Area: `area_02` / 페리온
- monster_id: `m_stumpy`
- 몬스터 이름: 스텀피
- monster image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- skill_id: `s_mon_stumpy`
- 최종 스킬 이름: **고목의 생기탄**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 확정 기획 효과(보존 원문): INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: INT 계수 1.9; skill.range=5wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- 확인된 런타임 동작: skill.range=5wu는 플레이어 조준 거리이며 몬스터 사용 시 3.335wu로 대상 탐색한다. projectile_ruid c6b3f052e977479ea5ad5329ce0981ca를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. CAST 레이어 없음.

## 원작/지역 연결

[P][A] 고목형 몬스터와 생기는 연결 가능하나 ‘빼앗은 생기’와 생기탄은 확인되지 않았다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 시각 번역

- 핵심 소재: 고목 나이테에서 싹이 돋아 응축된 생기탄. 몬스터 본체는 넣지 않는다.
- 주 색상: 고목 갈색 #75533A / 보조 색상: 생기 연두 #8ED35B.
- 효과 발생 위치: 움직이는 projectile entity의 로컬 중심.
- PROJECTILE 역할 구분: CAST_VFX는 현재 실행 역할이 없다. 생기탄 중심의 나이테·새싹·입자만 로컬에서 맥동하며, 캔버스 전체 이동·전체 스프라이트 회전은 엔진 이동/ZRotation과 중복하지 않는다.
- 진행 방향: 원화 자체는 방향 중립. 엔진은 위치 보간과 Z축 회전만 하며 FlipX·진행 방향 자동 정렬은 하지 않는다.
- 대상 표현: 타깃 캐릭터와 조준 범위를 이미지에 넣지 않는다. 전용 IMPACT VFX도 만들지 않는다.
- 화면 점유율: 핵심 소재 70%, 외곽 파편 85% 이내. 이펙트 밀도는 보스 체급이되 투사체 실루엣을 흐리지 않는다.
- 시간 흐름: F00 응축 → F01 발광 상승 → F02 절정 → F03 안정/잔광. 0.32초 안에 한 번 완결된다.
- 아이콘 핵심 모티브: 싹튼 나이테 + 작은 생기 코어. 64px에서도 두 형상이 읽혀야 한다.

## 출력 프로필

- ICON: NEW_ART / ICON/008_m_stumpy_s_mon_stumpy_ICON.png / 256x256 RGBA
- PROJECTILE: NEW_ART / PROJECTILE/008_m_stumpy_s_mon_stumpy_PROJECTILE_F00.png..._PROJECTILE_F03.png / 4 frames × 512x512 RGBA / 0.08s per frame / non-loop complete playback within 0.35s entity lifetime
- 역할별 파일을 섞지 않는다. HIT/PERSISTENT 역할 없음 행은 신규 제작하지 않는다.

## V2.4 전체 아트 제작 계약

- required_roles: `ICON|PROJECTILE`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|projectile_ruid`
- production_ready: `READY`
- import_ready: `NOT_READY_ASSETS_NOT_GENERATED`

### Role inventory

- ICON: current=true; decision=NEW_ART; field=icon_ruid; files=ICON/008_m_stumpy_s_mon_stumpy_ICON.png; target=icon_ruid
- CAST_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PROJECTILE: current=true; decision=NEW_ART; field=projectile_ruid; files=PROJECTILE/008_m_stumpy_s_mon_stumpy_PROJECTILE_F00.png..._PROJECTILE_F03.png; target=projectile_ruid
- HIT_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- PERSISTENT_BUFF_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none
- REFERENCE_VFX: current=false; decision=NO_RUNTIME_ROLE; field=none; files=none; target=none

### Shared constraints

- PROJECTILE 제작 계약: 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주한다. targeting_range와 현재 착탄 피해 반경 0.8wu를 구분하며 게임 수치는 변경하지 않는다.

- CAST와 PROJECTILE은 독립 파일 세트다. 같은 VFX 한 세트로 합치지 않는다.
- PROJECTILE은 4×0.08=0.32초 non-loop로 0.35초 수명 안에 완주하며 엔진 이동·ZRotation을 이미지 안에서 중복하지 않는다.
- 전용 HIT/PERSISTENT 시각 호출이 없으므로 해당 파일을 만들지 않는다.
- 복수 CAST 레이어 통합은 기존 delay/offset/drift의 상대 리듬을 한 로컬 캔버스 clip에 베이크한다. 원본 레이어 정보는 ASSET_BINDING_PLAN에 남긴다.
- targeting_range와 impact_radius는 별개이며 이미지로 조준 거리 전체를 피해 범위처럼 표현하지 않는다.
- PREVIEW/labeled_preview.png와 Area overview는 필수 검수물이고 별도 contact sheet만 선택이다.
