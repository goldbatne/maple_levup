# Runtime Role Map — m_stumpy / s_mon_stumpy — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/008_m_stumpy_s_mon_stumpy_ICON.png` | 1f / 256x256 RGBA / static / static | `n/a` | `n/a` | `icon_ruid` | none |
| CAST_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |
| PROJECTILE | true · projectile_ruid | NEW_ART | `PROJECTILE/008_m_stumpy_s_mon_stumpy_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4f / 512x512 RGBA / 0.08 / non-loop complete playback within 0.35s entity lifetime | `n/a` | `n/a` | `projectile_ruid` | import must author AnimationClip non-loop at 0.08s/frame; Maker runtime not run |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|PROJECTILE`
- production_decisions: `NEW_ART|NEW_ART`
- future_targets: `icon_ruid|projectile_ruid`
- confirmed design effect preserved: INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: INT 계수 1.9; skill.range=5wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- runtime_motion preserved: skill.range=5wu는 플레이어 조준 거리이며 몬스터 사용 시 3.335wu로 대상 탐색한다. projectile_ruid c6b3f052e977479ea5ad5329ce0981ca를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. CAST 레이어 없음.
- targeting_range=5 / impact_radius=0.8 / impact_delay=0.35 / max_targets=unlimited

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
