# Runtime Role Map — m_peach_monkey / s_mon_peach_monkey — V2.4

| role | current | production | files | timing | baseline/current evidence | approved target | future target | unresolved |
|---|---|---|---|---|---|---|---|---|
| ICON | true · icon_ruid | NEW_ART | `ICON/003_m_peach_monkey_s_mon_peach_monkey_ICON.png` | 1f / 256x256 RGBA / static / static | `n/a` | `n/a` | `icon_ruid` | none |
| CAST_VFX | true · layer_ruids | NEW_ART | `CAST/003_m_peach_monkey_s_mon_peach_monkey_CAST_F00.png..._CAST_F07.png` | 8f / 384x384 RGBA / 0.10 / non-loop one-shot | `n/a` | `n/a` | `layer_ruids` | none |
| PROJECTILE | true · projectile_ruid | NEW_ART | `PROJECTILE/003_m_peach_monkey_s_mon_peach_monkey_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4f / 384x384 RGBA / 0.08 / non-loop complete playback within 0.35s entity lifetime | `n/a` | `n/a` | `projectile_ruid` | import must author AnimationClip non-loop at 0.08s/frame; Maker runtime not run |
| HIT_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; no dedicated hit/impact visual field or Spawn call in current common projectile path |
| PERSISTENT_BUFF_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none; defense mechanics may persist but current visual is one-shot CAST only |
| REFERENCE_VFX | false · none | NO_RUNTIME_ROLE | `none` | 0f / n/a / n/a / n/a | `n/a` | `n/a` | `none` | none |

## Authoritative contract

- required_roles: `ICON|CAST_VFX|PROJECTILE`
- production_decisions: `NEW_ART|NEW_ART|NEW_ART`
- future_targets: `icon_ruid|layer_ruids|projectile_ruid`
- confirmed design effect preserved: DEX 계수 4.6로 단일 대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect preserved: DEX 계수 4.6; skill.range=7wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 최대 1대상 피해 판정.
- runtime_motion preserved: skill.range=7wu는 플레이어 조준 거리이며 몬스터 사용 시 4.6690000000000005wu로 대상 탐색한다. projectile_ruid 9ca14ee512b1489cbb54b2b9833388cd를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 1대상 피해를 판정한다. L1 delay=0s duration=0.65s offset=(0,0)wu drift=(0,0)wu/s.
- targeting_range=7 / impact_radius=0.8 / impact_delay=0.35 / max_targets=1

No role marked `NO_RUNTIME_ROLE` may be generated merely because it appears in the inventory. Runtime import remains separate from production readiness.
