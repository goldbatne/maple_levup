# PACKAGE REVISION — V2.2

- source: `AREA_08_IMAGES_INPUT_V2_1.zip`
- source_sha256: `6eac48affd2ac52976683d8acb82cd7d6f3e7faa8475a620824055e1c4893c4b`
- built_utc: `2026-09-12T01:40:31.891829+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
