# PROJECTILE SCOPE REVIEW — V2.3

All 12 actual monster projectile visual roles are NEW_ART. Engine movement is unchanged; existing projectile RUIDs remain evidence only until approved import.

| Area | monster | skill | current RUID | new files | timing | targeting | impact | future target |
|---|---|---|---|---|---|---|---|---|
| area_08 | `m_star_pixie` | `s_mon_star_pixie` | `b61e7e2a50b2405794f88fdddf44b73a` | `PROJECTILE/001_m_star_pixie_s_mon_star_pixie_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 6 | 0.8 after 0.35s | `projectile_ruid` |
| area_08 | `m_lunar_pixie` | `s_mon_lunar_pixie` | `4f6509d9539f4d76a9bb4e8f17e12cc7` | `PROJECTILE/003_m_lunar_pixie_s_mon_lunar_pixie_PROJECTILE_F00.png..._PROJECTILE_F03.png` | 4×0.08=0.32s / non-loop complete playback within 0.35s entity lifetime | 6.4 | 0.8 after 0.35s | `projectile_ruid` |

- Stumpy has no CAST and remains PROJECTILE+ICON only.
- The other 11 keep their CAST requirement and add an independent PROJECTILE requirement.
- No HIT role is added because ResolveThrowHit has no visual asset field or effect spawn call.
