# ASSET BINDING PLAN — V2.4

`ASSET_BINDING_PLAN.csv`가 현행 연결 계획 원장이다. decision 값은 다음 세 가지만 사용한다.

- `NEW_ART`: 해당 역할의 새 아트를 제작한다. 현재 RUID는 baseline/current evidence일 뿐 유지 지시가 아니다.
- `AREA00_APPROVED_REUSE`: 정확히 확인된 Area 00 승인 파일과 승인 RUID를 재사용한다. `baseline_current_evidence`와 `approved_target_ruid`를 구분해서 읽는다.
- `NO_RUNTIME_ROLE`: 현재 실행 경로에 해당 시각 역할이 없으므로 파일을 만들거나 연결하지 않는다.

`source_path`는 INPUT에 포함된 원본 또는 승인 재사용 파일이고 `output_path`는 향후 OUTPUT에 둘 최종 경로다. Preview는 `preview_reference_files`에만 기록하며 게임 반입 원본과 `required_file_set`에 섞지 않는다.

이 문서는 제작·향후 연결 계획이며 실제 리소스 업로드, AnimationClip 생성, SkillTable RUID 변경이 완료됐다는 뜻이 아니다.
