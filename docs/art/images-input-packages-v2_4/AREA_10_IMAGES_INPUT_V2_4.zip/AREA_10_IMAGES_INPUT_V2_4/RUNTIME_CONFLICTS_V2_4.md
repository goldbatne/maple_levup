# Runtime and design conflicts — V2.4

## AREA 20 / s_mon_mutant_stone_mask

- 확정 데이터: passive_stat=DEF (변경하지 않음).
- GameDataVerify는 STR/DEX/INT/LUK만 허용해 DEF를 오류로 기록한다 (`GameDataVerify.mlua:188-200`).
- PlayerStats.GetCollectionPoints는 전달받은 이름과 passive_stat이 같은 항목을 합산하지만, GetCollectionBonus("DEF")는 DEX 포인트만 사용한다 (`PlayerStats.mlua:527-576`). DEF collection point를 파생 방어력에 더하는 호출은 확인되지 않았다.
- 결론: 현행 계산에서 스킬 passive_stat=DEF는 방어력 보너스로 소비되지 않는 기획/실행 충돌이다. 게임 데이터·검증·계산 코드는 V2.4에서 변경하지 않았다.
- GENERATION_READY는 아트 입력 기준 READY, RUNTIME_VALIDATION은 UNRESOLVED다.

## Current Maker SkillTable

- 정상 경로 SkillTable 파일은 삭제 상태이며 Mislocated 후보가 있다. `_DataService:GetTable("SkillTable")` 이름 조회만으로 현재 Maker 등록 EntryKey를 식별할 수 없다.
- V2.4는 기준 커밋 데이터와 V2.1 확정 패키지를 사용하지만 현재 Maker 등록 테이블과 같다고 단정하지 않는다. RUNTIME_VALIDATION=NOT_RUN.

## Six dash skills

- 플레이어 피해점은 계산 도착점, PlayCast는 호출 뒤 서버가 보는 caster 위치를 사용하므로 일치가 보장되지 않는다.
- 지연 CAST는 Timer 후 SpawnLayer 실행 시점의 caster 좌표를 읽고, 스폰 뒤 맵 엔티티에 drift가 적용된다.
- 몬스터 공통 CastSkill에는 dash_distance 이동 분기가 없다. 경고를 유지하며 이번에 코드를 바꾸지 않는다.

## Projectile scope

- 실제 PROJECTILE 역할 12종은 모두 `NEW_ART`다. 기존 `projectile_ruid`는 현재 연결과 출처를 확인하기 위한 baseline evidence일 뿐 기존 비행체 아트를 유지하라는 지시가 아니다.
- 스텀피를 포함한 12종 모두 4프레임 × 0.08초 = 0.32초 non-loop로 제작하고, 0.35초 엔티티 수명 안에서 완주한다.
- `skill.range`는 targeting_range이며 착탄 피해 반경은 현재 코드의 `projectile_hit_radius=0.8wu`다. 두 값을 이미지 범위로 합치지 않는다.
- PROJECTILE 원화는 로컬 중심·방향 중립이다. 엔진이 시전자+h에서 목표+h까지 이동시키고 ZRotation을 적용하므로 캔버스 전체 이동·전체 스프라이트 회전을 프레임에 중복하지 않는다. PROJECTILE FlipX나 진행 방향 자동 정렬은 현재 경로에 없다.
- 이번 revision은 문서·재사용 계약 보완이다. 게임의 실제 RUID 연결은 변경하지 않는다.
