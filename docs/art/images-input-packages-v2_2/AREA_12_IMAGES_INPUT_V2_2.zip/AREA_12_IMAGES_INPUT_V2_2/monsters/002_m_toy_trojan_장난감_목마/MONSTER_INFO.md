# Monster Reference — 장난감 목마

- 작업 순번: 002
- level: 113
- Area: `area_12` / 루디브리엄
- monster_id: `m_toy_trojan`
- model_id: `toytrojan`
- image RUID: `f9a2d6e8feaf4c90a3e00d022932fdaa`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_toy_trojan`
- skill name/type: 태엽 목마 돌진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/ToyTrojan.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `202c9f16bce2352d89fe5ab2079ebb187f7ad2f4422a9b6e66eb9086b08f3f42`
- image: 320×240 RGBA / alpha 0~255 / bbox [81, 3, 265, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
