# Monster Reference — 타이머

- 작업 순번: 005
- level: 120
- Area: `area_12` / 루디브리엄
- monster_id: `m_timer`
- model_id: `timer`
- image RUID: `cbdd230e5cd34b7b9eeb1cd206d19f34`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_timer`
- skill name/type: 시간 정지 충격 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Timer.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `d9033742dff66df4a43ce397c99323c1fa95bbc23af9039573aaa2aa5a6e2b64`
- image: 320×240 RGBA / alpha 0~255 / bbox [42, 2, 279, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
