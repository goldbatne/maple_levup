# Monster Reference — 크로노스

- 작업 순번: 004
- level: 118
- Area: `area_12` / 루디브리엄
- monster_id: `m_chronos`
- model_id: `chronos`
- image RUID: `1356c7ad27254459aaf789b51a75875c`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_chronos`
- skill name/type: 크로노스의 시간편린 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Chronos.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `b9cea89686a2b0958426f11dfd700fe3edea727a7a22654010603c735a47e1f2`
- image: 320×240 RGBA / alpha 0~255 / bbox [59, 36, 267, 231]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
