# Monster Reference — 마스터 로보

- 작업 순번: 003
- level: 115
- Area: `area_12` / 루디브리엄
- monster_id: `m_master_robo`
- model_id: `masterrobo`
- image RUID: `f5d65e28cb0e4990bf5727015f22e0f1`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_master_robo`
- skill name/type: 정밀 태엽회로 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/MasterRobo.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `55f24bf615c3201f367a784eb07103d85d434fc5c2526568c8f93ff13d1618d1`
- image: 320×240 RGBA / alpha 0~255 / bbox [67, 24, 261, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
