# Monster Reference — 브라운테니

- 작업 순번: 001
- level: 111
- Area: `area_12` / 루디브리엄
- monster_id: `m_brown_teddy`
- model_id: `brownteddy`
- image RUID: `46fd51a318b64738a36beeb3db02a970`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_brown_teddy`
- skill name/type: 솜인형 완충 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BrownTeddy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `a76ae4d9dc46f0ac657a72f1fb19cd79677ec989134b319c96e539bdf7dde393`
- image: 320×240 RGBA / alpha 0~255 / bbox [105, 23, 288, 217]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
