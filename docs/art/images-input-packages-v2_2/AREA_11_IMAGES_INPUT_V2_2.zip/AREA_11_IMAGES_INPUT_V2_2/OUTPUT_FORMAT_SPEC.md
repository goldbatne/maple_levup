# Output Format Spec — V2.2

- 출력 루트: `AREA_11_IMAGES_OUTPUT/`
- 모든 VFX/PROJECTILE 프레임은 frame-separated RGBA PNG이며 같은 역할 안에서 캔버스·피봇·스케일이 같아야 한다.
- ICON은 256×256 RGBA 1장이다.
- 실제 alpha, 빈 프레임, 잘림, 다른 셀 조각, 프레임 누락을 검사한다.
- `skill.range`를 이미지상의 피해 반경으로 그리지 않는다. 투사체의 targeting_range와 impact_radius는 별도다.
- 엔진 이동(projectile 위치 보간·ZRotation, dash, layer drift)을 이미지 안의 캔버스 이동으로 중복하지 않는다.
- 패시브 REFERENCE_VFX는 runtime_use=false이며 Preview 전용이다. CAST 납품물로 취급하지 않는다.
- 스텀피는 PROJECTILE 4프레임+ICON만 요구하며 CAST_VFX를 요구하지 않는다.
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수다. 별도 contact sheet는 선택이다.
- 파일 검사, 제작 준비, Maker 런타임, 사용자 아트 승인은 서로 다른 상태로 기록한다.
