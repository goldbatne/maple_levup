# Runtime Role Map — m_drumming_bunny / s_mon_drumming_bunny

## Current V2.2 contract

- confirmed design effect (preserved): INT 계수 3.35로 반경 5.2 범위 최대 4대상 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- actual_motion: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.75s offset=(0,0)wu drift=(0,0)wu/s.
- required_roles: `CAST_VFX|ICON`
- replacement_target_fields: `layer_ruids|icon_ruid`
- generation_ready: `READY`

- 역할: CAST_VFX + ICON
- runtime_use: true (CAST) / ui (ICON)
- CAST 필요 파일: `VFX/F00...F07.png`, 8장 × 384×384 RGBA, 0.10s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- target_field: `layer_ruids` (아트 승인 후 기존 visual stack을 승인된 primary clip 하나로 교체하는 계획)
- 기존 레이어와 projectile_ruid는 승인 전 KEEP한다. projectile_ruid가 있는 11종은 이번 필수 범위에서 비행체 아트를 교체하지 않는다.
- 지연 CAST 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift를 적용한다.
- 엔진 이동(projectile/dash/drift)과 이미지 내부 연출을 중복하지 않는다.

## Coordinate and timing evidence

- CAST delay가 0보다 크면 Timer가 끝난 뒤 SpawnLayer가 그 순간의 caster.WorldPosition을 읽는다 (`SkillEffect.mlua:55-60,83-94`).
- 스폰된 CAST는 맵 엔티티이며 이후 SkillCastEffect가 drift를 적용한다. 시전자 추적 부착물이 아니다.
- PROJECTILE은 `SkillProjectile`이 위치 보간과 ZRotation을 수행한다. PROJECTILE 경로에는 FlipX 또는 진행 방향 자동 정렬 코드가 없다.
- `skill.range`는 targeting 거리이고 투사체 착탄 피해 반경은 GameBalance `projectile_hit_radius=0.8`다.
