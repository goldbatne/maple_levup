# GENERATION SPEC — 태륜 / 태륜의 쌍권풍

## 확정 데이터

- 작업 순번: 005
- 레벨: 150
- Area: `area_15` / 무릉도원
- monster_id: `m_tae_roon`
- 몬스터 이름: 태륜
- monster image RUID: `0e1e782401624d7693959777c0b16ebe`
- skill_id: `s_mon_tae_roon`
- 최종 스킬 이름: **태륜의 쌍권풍**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 확정 기획 효과(보존 원문): STR 계수 4.9로 반경 6.6 범위 대상 제한 없음 피해; 10초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: STR 계수 4.9; skill.range=6.6wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- 확인된 런타임 동작: skill.range=6.6wu는 플레이어 조준 거리이며 몬스터 사용 시 4.4022wu로 대상 탐색한다. projectile_ruid 5328a3875a32437784c949579f259a00를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. L1 delay=0s duration=0.75s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.2s duration=0.85s offset=(0,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 태륜의 모델 ID·RUID와 무릉도원 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 두 권격이 마주 회전해 만드는 쌍둥이 바람 소용돌이. ‘태륜 / 태륜의 쌍권풍’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 권풍 청록 #53B9AA; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 도원 금빛 #E3C66B; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=발사/준비 연출; PROJECTILE=엔진이 이동시키는 비행체; ICON=UI 식별
- 효과 발생 위치: CAST_VFX는 시전자 원점. PROJECTILE은 시전자에서 조준 위치로 이동한다. 전용 IMPACT VFX 필드는 현재 없다.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. PROJECTILE 그림 안에서 캔버스 전체를 좌→우로 이동시키지 않는다(엔진 이동과 중복 금지). layer drift는 엔진 적용: L1 ruid=353079a9d111455ab55d75577f9d7967, type=animationclip, style=clip, delay=0s, duration=0.75s, scale=1.05, offset=(0,0) world unit, drift=(0,0) world unit/s; L2 ruid=8e38989c6f3d4f87876d37e431ee11c1, type=animationclip, style=clip, delay=0.2s, duration=0.85s, scale=1.1, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 조준 지점은 그림에 캐릭터로 표시하지 않는다. 현재 전용 IMPACT 출력은 요구하지 않는다.
- 화면 점유율: 큼(캐릭터 2~3배, 화면을 가리지 않음); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 높음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: CAST는 발사 준비 → 방출 섬광 → 짧은 잔광. PROJECTILE은 동일 중심축에서 자체 회전/맥동만 하며 위치 이동은 엔진에 맡긴다.
- 판정 정렬: 투사체가 0.35초 뒤 도착할 때 피해 판정. CAST_VFX는 발사 시점에 시작한다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘쌍 주먹 바람눈’, 보조 효과 1개는 ‘회전선’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BOSS_ACTIVE`
- VFX: 12 frames, 각 512×512 RGBA PNG, 약 0.08 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## V2.2 현행 런타임·납품 계약

- actual_motion: skill.range=6.6wu는 플레이어 조준 거리이며 몬스터 사용 시 4.4022wu로 대상 탐색한다. projectile_ruid 5328a3875a32437784c949579f259a00를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. L1 delay=0s duration=0.75s offset=(0,0)wu drift=(0,0)wu/s; L2 delay=0.2s duration=0.85s offset=(0,0)wu drift=(0,0)wu/s.
- runtime_effect: STR 계수 4.9; skill.range=6.6wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- required_roles: `CAST_VFX|ICON`
- replacement_target_fields: `layer_ruids|icon_ruid`
- generation_ready: `READY`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: CAST_VFX + ICON
- runtime_use: true (CAST) / ui (ICON)
- CAST 필요 파일: `VFX/F00...F11.png`, 12장 × 512×512 RGBA, 0.08s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- target_field: `layer_ruids` (아트 승인 후 기존 visual stack을 승인된 primary clip 하나로 교체하는 계획)
- 기존 레이어와 projectile_ruid는 승인 전 KEEP한다. projectile_ruid가 있는 11종은 이번 필수 범위에서 비행체 아트를 교체하지 않는다.
- 지연 CAST 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift를 적용한다.
- 엔진 이동(projectile/dash/drift)과 이미지 내부 연출을 중복하지 않는다.
