# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_straw_dummy` | `s_mon_straw_dummy` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 2 | `m_wooden_dummy` | `s_mon_wooden_dummy` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 3 | `m_peach_monkey` | `s_mon_peach_monkey` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_blue_flower_serpent` | `s_mon_blue_flower_serpent` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 5 | `m_tae_roon` | `s_mon_tae_roon` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
| `m_peach_monkey` | `s_mon_peach_monkey` | 7 | 7 | 4.6690000000000005 | 0.8 | 0.35 | 1 |
| `m_tae_roon` | `s_mon_tae_roon` | 6.6 | 6.6 | 4.4022 | 0.8 | 0.35 | unlimited |
