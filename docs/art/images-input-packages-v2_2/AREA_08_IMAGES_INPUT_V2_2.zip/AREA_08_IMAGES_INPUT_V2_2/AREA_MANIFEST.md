# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_star_pixie` | `s_mon_star_pixie` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 2 | `m_jr_cellion` | `s_mon_jr_cellion` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 3 | `m_lunar_pixie` | `s_mon_lunar_pixie` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_luster_pixie` | `s_mon_luster_pixie` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 5 | `m_eliza` | `s_mon_eliza` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
| `m_star_pixie` | `s_mon_star_pixie` | 6 | 6 | 4.002000000000001 | 0.8 | 0.35 | 1 |
| `m_lunar_pixie` | `s_mon_lunar_pixie` | 6.4 | 6.4 | 4.268800000000001 | 0.8 | 0.35 | 1 |
