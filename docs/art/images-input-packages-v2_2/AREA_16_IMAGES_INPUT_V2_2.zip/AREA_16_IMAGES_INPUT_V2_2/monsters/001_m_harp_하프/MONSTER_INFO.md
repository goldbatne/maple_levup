# Monster Reference — 하프

- 작업 순번: 001
- level: 151
- Area: `area_16` / 미나르숲
- monster_id: `m_harp`
- model_id: `harp`
- image RUID: `96bd8dd2077844d1a0e5ce6b956d94ef`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_harp`
- skill name/type: 하늘 둥지의 날갯결 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Harp.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `7fc5dab6c20f85a4e2c4aa05f009bca8365aa12ee4c3e1d21cf1d82d2be4f8d5`
- image: 320×240 RGBA / alpha 0~255 / bbox [80, 0, 240, 236]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
