# Monster Reference — 블러드 하프

- 작업 순번: 002
- level: 153
- Area: `area_16` / 미나르숲
- monster_id: `m_blood_harp`
- model_id: `bloodharp`
- image RUID: `8c2ec5bf58894061a19479ed7545637b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blood_harp`
- skill name/type: 핏빛 깃울림 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BloodHarp.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9796964fc17b12de569d125c2bae796cff97b9ee2b092f3af4c52090891a12cf`
- image: 320×240 RGBA / alpha 0~255 / bbox [80, 0, 240, 236]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
