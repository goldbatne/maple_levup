# Monster Reference — 마뇽

- 작업 순번: 005
- level: 160
- Area: `area_16` / 미나르숲
- monster_id: `m_manon`
- model_id: `manon`
- image RUID: `b8cdd7920392456f99272649c7cb7c2d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_manon`
- skill name/type: 마뇽의 용화염 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Manon.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9f2d56a3392ee1ca48b28c8012e7af6d1700930d23377b7ae195353e30ecc271`
- image: 320×240 RGBA / alpha 0~255 / bbox [78, 1, 262, 237]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
