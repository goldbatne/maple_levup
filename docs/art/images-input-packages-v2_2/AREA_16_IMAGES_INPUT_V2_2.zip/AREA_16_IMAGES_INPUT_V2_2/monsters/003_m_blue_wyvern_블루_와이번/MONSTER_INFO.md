# Monster Reference — 블루 와이번

- 작업 순번: 003
- level: 155
- Area: `area_16` / 미나르숲
- monster_id: `m_blue_wyvern`
- model_id: `bluewyvern`
- image RUID: `07bc82953fca4677bc00f74680ec337b`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_blue_wyvern`
- skill name/type: 빙룡 숨결 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/BlueWyvern.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `f92376059afd06b522d5c127ce3453b7a1501aeaf583b4c94c611778668e2587`
- image: 320×240 RGBA / alpha 0~255 / bbox [57, 22, 292, 218]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
