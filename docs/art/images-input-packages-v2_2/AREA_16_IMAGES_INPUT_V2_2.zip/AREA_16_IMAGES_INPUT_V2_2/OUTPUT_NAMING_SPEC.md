# Output Naming Spec — V2.2

출력 루트: `AREA_16_IMAGES_OUTPUT/`

## 필수 구조

```text
AREA_16_IMAGES_OUTPUT/
├─ OUTPUT_MANIFEST.csv
├─ OUTPUT_MANIFEST.md
├─ AREA_OVERVIEW_PREVIEW.png        # 필수
├─ SOURCE_SHEET/                    # 원본 시트가 있을 때만
├─ SHEET_SPLIT_MANIFEST.csv         # 시트를 분할했을 때만
└─ monsters/
   └─ NNN_[monster_id]_[name]/
      ├─ VFX/                       # CAST_VFX 또는 REFERENCE_VFX
      ├─ PROJECTILE/                # OUTPUT_REQUIREMENTS가 요구할 때만
      ├─ ICON/icon.png
      ├─ PREVIEW/labeled_preview.png # 필수
      ├─ CONTACT_PREVIEW.png        # 선택 검수물
      └─ RESULT_INFO.md
```

- `PREVIEW/labeled_preview.png`와 `AREA_OVERVIEW_PREVIEW.png`는 필수다.
- 별도 contact sheet는 선택 검수물이며 필수 Preview를 대체하지 않는다.
- 주 게임용 납품물은 역할별 F00... 개별 RGBA PNG다. sprite/contact sheet는 주 납품물이 아니다.
- 정확한 역할·프레임 수·target_field는 `OUTPUT_REQUIREMENTS.csv`를 단일 원장으로 따른다.
- 원본 시트가 있으면 분할 좌표와 시트 원본을 보존한다. autocrop/recenter 금지.
