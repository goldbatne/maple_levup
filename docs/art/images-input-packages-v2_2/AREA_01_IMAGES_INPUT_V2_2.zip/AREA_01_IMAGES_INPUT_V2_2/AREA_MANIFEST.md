# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_snail` | `s_mon_snail_dew_trail` | 액티브 | APPROVED_REUSE | none | READY_REUSE | AREA00_APPROVED_NOT_RERUN |
| 2 | `m_blue_snail` | `s_mon_blue_snail` | 버프 | APPROVED_REUSE | none | READY_REUSE | AREA00_APPROVED_NOT_RERUN |
| 3 | `m_mushroom` | `s_mon_mushroom` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_mushmom` | `s_mon_mushmom` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 5 | `m_horny_mushroom` | `s_mon_horny_mushroom` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
