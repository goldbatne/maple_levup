# Runtime Role Map — m_snail / s_mon_snail_dew_trail

## Current V2.2 contract

- confirmed design effect (preserved): ATK 계수 0.9로 반경 2.5 범위 최대 3대상 피해; 5초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- actual_motion: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.8s offset=(0,0)wu drift=(0,0)wu/s.
- required_roles: `APPROVED_REUSE`
- replacement_target_fields: `none`
- generation_ready: `READY_REUSE`

- 역할: AREA 00 승인 VFX/ICON 바이트 재사용
- generation_required: false
- runtime_use: approved_existing
- 새 그림 생성·교체 금지. approved_reuse/AREA_00의 파일과 해시를 유지한다.
- RUNTIME_VALIDATION과 ART_APPROVAL은 AREA 00 승인 기록을 인용하며 V2.2에서 재실행하지 않는다.

## Coordinate and timing evidence

- CAST delay가 0보다 크면 Timer가 끝난 뒤 SpawnLayer가 그 순간의 caster.WorldPosition을 읽는다 (`SkillEffect.mlua:55-60,83-94`).
- 스폰된 CAST는 맵 엔티티이며 이후 SkillCastEffect가 drift를 적용한다. 시전자 추적 부착물이 아니다.
- PROJECTILE은 `SkillProjectile`이 위치 보간과 ZRotation을 수행한다. PROJECTILE 경로에는 FlipX 또는 진행 방향 자동 정렬 코드가 없다.
- `skill.range`는 targeting 거리이고 투사체 착탄 피해 반경은 GameBalance `projectile_hit_radius=0.8`다.
