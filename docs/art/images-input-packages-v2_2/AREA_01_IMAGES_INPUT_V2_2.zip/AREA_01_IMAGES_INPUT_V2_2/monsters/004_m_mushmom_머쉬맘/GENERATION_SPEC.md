# GENERATION SPEC — 머쉬맘 / 머쉬맘의 포자 충격

## 확정 데이터

- 작업 순번: 004
- 레벨: 10
- Area: `area_01` / 헤네시스 근교
- monster_id: `m_mushmom`
- 몬스터 이름: 머쉬맘
- monster image RUID: `86015373d23b4b05bb8fcc6086354652`
- skill_id: `s_mon_mushmom`
- 최종 스킬 이름: **머쉬맘의 포자 충격**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 확정 기획 효과(보존 원문): ATK 계수 1.35로 반경 4.2 범위 대상 제한 없음 피해; 6초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.75s offset=(0,-0.08)wu drift=(0,0)wu/s; L2 delay=0.1s duration=0.72s offset=(0,-0.08)wu drift=(0,0)wu/s; L3 delay=0.22s duration=0.7s offset=(0,0)wu drift=(0,0.18)wu/s.

## 원작/지역 연결

[P][A] 거대 버섯 보스와 포자는 연결되나 ‘포자 충격’의 공식 고유 근거는 확인되지 않았다.

## 시각 번역

- 핵심 소재: 굵은 포자 핵이 지면에 닿아 버섯갓 모양으로 터지는 충격. ‘머쉬맘 / 머쉬맘의 포자 충격’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 황갈 포자색 #B77A3A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 황금 충격광 #FFD66B; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=05113e9dc86448cb8581731824106d75, type=animationclip, style=clip, delay=0s, duration=0.75s, scale=0.9, offset=(0,-0.08) world unit, drift=(0,0) world unit/s; L2 ruid=86734a2715504c10b1e50ae810609e25, type=animationclip, style=clip, delay=0.1s, duration=0.72s, scale=1.15, offset=(0,-0.08) world unit, drift=(0,0) world unit/s; L3 ruid=9c927f6388e74628b1050dfc8490246c, type=animationclip, style=clip, delay=0.22s, duration=0.7s, scale=0.72, offset=(0,0) world unit, drift=(0,0.18) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 큼(캐릭터 2~3배, 화면을 가리지 않음); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 높음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘버섯갓 충격파’, 보조 효과 1개는 ‘굵은 포자 파편’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `BOSS_ACTIVE`
- VFX: 12 frames, 각 512×512 RGBA PNG, 약 0.08 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## V2.2 현행 런타임·납품 계약

- actual_motion: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.75s offset=(0,-0.08)wu drift=(0,0)wu/s; L2 delay=0.1s duration=0.72s offset=(0,-0.08)wu drift=(0,0)wu/s; L3 delay=0.22s duration=0.7s offset=(0,0)wu drift=(0,0.18)wu/s.
- runtime_effect: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- required_roles: `CAST_VFX|ICON`
- replacement_target_fields: `layer_ruids|icon_ruid`
- generation_ready: `READY`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: CAST_VFX + ICON
- runtime_use: true (CAST) / ui (ICON)
- CAST 필요 파일: `VFX/F00...F11.png`, 12장 × 512×512 RGBA, 0.08s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- target_field: `layer_ruids` (아트 승인 후 기존 visual stack을 승인된 primary clip 하나로 교체하는 계획)
- 기존 레이어와 projectile_ruid는 승인 전 KEEP한다. projectile_ruid가 있는 11종은 이번 필수 범위에서 비행체 아트를 교체하지 않는다.
- 지연 CAST 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift를 적용한다.
- 엔진 이동(projectile/dash/drift)과 이미지 내부 연출을 중복하지 않는다.
