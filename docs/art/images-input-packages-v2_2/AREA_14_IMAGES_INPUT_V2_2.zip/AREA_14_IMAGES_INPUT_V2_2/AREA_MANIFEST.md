# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_cube_slime` | `s_mon_cube_slime` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 2 | `m_mithril_mutae` | `s_mon_mithril_mutae` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 3 | `m_homun` | `s_mon_homun` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_roid` | `s_mon_roid` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 5 | `m_chimera` | `s_mon_chimera` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
| `m_roid` | `s_mon_roid` | 7 | 7 | 4.6690000000000005 | 0.8 | 0.35 | 1 |
| `m_chimera` | `s_mon_chimera` | 6.8 | 6.8 | 4.5356000000000005 | 0.8 | 0.35 | unlimited |
