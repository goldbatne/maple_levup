# PACKAGE REVISION — V2.2

- source: `AREA_05_IMAGES_INPUT_V2_1.zip`
- source_sha256: `7cdc09226dd80d71c77f2a409f38c1007f8d741f2ee33e35b09ea581b1468674`
- built_utc: `2026-09-12T01:40:19.252728+00:00`
- game data/code changed: `false`
- Area 00 changed: `false`
- art generated: `false`
- scope: V2.1 evidence crosscheck confirmed corrections only
