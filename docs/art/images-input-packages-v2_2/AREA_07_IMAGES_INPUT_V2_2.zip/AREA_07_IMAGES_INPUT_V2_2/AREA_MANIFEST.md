# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_zombie_mushroom` | `s_mon_zombie_mushroom` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 2 | `m_copper_drake` | `s_mon_copper_drake` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 3 | `m_drake` | `s_mon_drake` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_wild_kargo` | `s_mon_wild_kargo` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 5 | `m_jr_balrog` | `s_mon_jr_balrog` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 6 | `m_tauromacis` | `s_mon_tauromacis` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
