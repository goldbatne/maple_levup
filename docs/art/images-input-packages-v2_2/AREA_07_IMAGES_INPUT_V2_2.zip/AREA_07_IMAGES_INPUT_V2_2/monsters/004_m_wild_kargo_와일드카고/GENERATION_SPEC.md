# GENERATION SPEC — 와일드카고 / 야수의 그림자 돌진

## 확정 데이터

- 작업 순번: 004
- 레벨: 68
- Area: `area_07` / 슬리피우드
- monster_id: `m_wild_kargo`
- 몬스터 이름: 와일드카고
- monster image RUID: `7d1c1d17eff44687b35ca0d5108084dc`
- skill_id: `s_mon_wild_kargo`
- 최종 스킬 이름: **야수의 그림자 돌진**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): ATK 계수 2.55로 단일 대상 피해; 6초 재사용; 5장 보유 시 계수 ×1.8; 6.2 거리 돌진
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어는 8방향으로 6.2wu를 0.2초 이동하고 계산 도착점에서 피해를 판정한다. PlayCast는 직후 서버가 보는 시전자 위치를 사용하므로 CAST 위치와 계산 피해점의 일치는 보장되지 않는다. 몬스터는 dash 분기 없이 시전자 중심 원형 판정 후 명중 시 CAST한다. L1 delay=0s duration=0.52s offset=(0,0)wu drift=(1.0,0)wu/s; L2 delay=0.04s duration=0.65s offset=(0,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 와일드카고의 야수성은 연결되나 ‘그림자’ 속성은 확인되지 않았다.

## 시각 번역

- 핵심 소재: 검은 야수 발톱 세 줄과 몸을 낮춘 전방 그림자 잔상. ‘와일드카고 / 야수의 그림자 돌진’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 그림자 남흑 #252A3B; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 발톱 자주 #765378; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=플레이어 돌진 도착점의 충돌 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 조준 8방향으로 6.2 world unit 이동하고 도착 예정점에서 피해·VFX 발생. 일반 몬스터 자동 시전 정책은 없음.
- 진행 방향·엔진 이동: 우측 기준 제작 후 FlipX. 이동 궤적 전체를 한 프레임 안에서 재현하지 않는다. layer drift는 엔진 적용: L1 ruid=0207c85c05dd4c4eac12f9ee735d0545, type=animationclip, style=clip, delay=0s, duration=0.52s, scale=0.65, offset=(0,0) world unit, drift=(1.0,0) world unit/s; L2 ruid=057c2da13da2492c95cb92db424803db, type=animationclip, style=clip, delay=0.04s, duration=0.65s, scale=0.72, offset=(0,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 도착점 주변 피격 범위만 읽히게 하고 이동 경로 전체를 범위로 오인시키지 않는다.
- 화면 점유율: 중간(캐릭터 1.2~2배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 중간; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 도착점 압축 → 충돌 절정 → 파편/잔상 소멸. 출발부터 도착까지의 전신 이동을 시트 안에서 반복하지 않는다.
- 판정 정렬: 0.2초 이동 뒤 판정과 CAST_VFX가 시작된다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘세 줄 발톱’, 보조 효과 1개는 ‘낮은 돌진 그림자’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `MID_AREA_ACTIVE`
- VFX: 8 frames, 각 384×384 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## V2.2 현행 런타임·납품 계약

- actual_motion: 플레이어는 8방향으로 6.2wu를 0.2초 이동하고 계산 도착점에서 피해를 판정한다. PlayCast는 직후 서버가 보는 시전자 위치를 사용하므로 CAST 위치와 계산 피해점의 일치는 보장되지 않는다. 몬스터는 dash 분기 없이 시전자 중심 원형 판정 후 명중 시 CAST한다. L1 delay=0s duration=0.52s offset=(0,0)wu drift=(1.0,0)wu/s; L2 delay=0.04s duration=0.65s offset=(0,0)wu drift=(0,0)wu/s.
- runtime_effect: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- required_roles: `CAST_VFX|ICON`
- replacement_target_fields: `layer_ruids|icon_ruid`
- generation_ready: `READY`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: CAST_VFX + ICON
- runtime_use: true (CAST) / ui (ICON)
- CAST 필요 파일: `VFX/F00...F07.png`, 8장 × 384×384 RGBA, 0.10s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- target_field: `layer_ruids` (아트 승인 후 기존 visual stack을 승인된 primary clip 하나로 교체하는 계획)
- 기존 레이어와 projectile_ruid는 승인 전 KEEP한다. projectile_ruid가 있는 11종은 이번 필수 범위에서 비행체 아트를 교체하지 않는다.
- 지연 CAST 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift를 적용한다.
- 엔진 이동(projectile/dash/drift)과 이미지 내부 연출을 중복하지 않는다.
