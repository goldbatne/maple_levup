# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_slime` | `s_mon_slime` | 액티브 | APPROVED_REUSE | none | READY_REUSE | AREA00_APPROVED_NOT_RERUN |
| 2 | `m_dark_stump` | `s_mon_dark_stump` | 버프 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 3 | `m_bubbling` | `s_mon_bubbling` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 4 | `m_fairy` | `s_mon_fairy` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 5 | `m_faust` | `s_mon_faust` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
| `m_faust` | `s_mon_faust` | 4 | 4 | 2.668 | 0.8 | 0.35 | unlimited |
