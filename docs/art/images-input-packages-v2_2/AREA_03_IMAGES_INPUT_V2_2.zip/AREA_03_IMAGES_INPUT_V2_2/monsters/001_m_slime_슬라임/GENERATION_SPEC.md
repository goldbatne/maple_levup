# GENERATION SPEC — 슬라임 / 끈적한 몸통

## 확정 데이터

- 작업 순번: 001
- 레벨: 11
- Area: `area_03` / 엘리니아
- monster_id: `m_slime`
- 몬스터 이름: 슬라임
- monster image RUID: `50faf654ee5d479cb2958edce9feaef0`
- skill_id: `s_mon_slime`
- 최종 스킬 이름: **끈적한 몸통**
- 스킬 타입: **액티브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): ATK 계수 1.15로 단일 대상 피해; 4초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- 확인된 런타임 동작: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.62s offset=(0.18,0)wu drift=(0.35,0)wu/s; L2 delay=0.12s duration=0.52s offset=(0.5,0)wu drift=(0,0)wu/s.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 슬라임의 모델 ID·RUID와 메이플 아일랜드·리스항구 | 엘리니아 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 탄성 있는 점액 방울과 눌렸다 되튀는 젤리 테두리. ‘슬라임 / 끈적한 몸통’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 슬라임 연두 #79D56B; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 투명 민트 #C7FFE0; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: CAST_VFX=시전자 중심 공격 연출; ICON=UI 식별
- 효과 발생 위치: 플레이어는 시전자 중심 원형 판정 뒤 CAST_VFX 재생. 보스 사용 시 명중한 경우에만 시전자 중심에서 재생한다.
- 진행 방향·엔진 이동: 자원은 우측 기준이며 대상이 왼쪽이면 FlipX. 판정 자체는 방향성 부채꼴이 아니라 시전자 중심 원형이다. layer drift는 엔진 적용: L1 ruid=2c12c1e835a04c2a9ec1c5724846a7b6, type=animationclip, style=clip, delay=0s, duration=0.62s, scale=0.48, offset=(0.18,0) world unit, drift=(0.35,0) world unit/s; L2 ruid=69656381a8e04edcbb8a2c8599567ab3, type=animationclip, style=clip, delay=0.12s, duration=0.52s, scale=0.55, offset=(0.5,0) world unit, drift=(0,0) world unit/s
- 대상 표현: 시전자 중심 원형 범위를 표현한다. 데이터가 단일/최대 대상 제한이면 시각 밀도만 줄이고 허구의 부채꼴·지정 지점을 만들지 않는다.
- 화면 점유율: 작음(캐릭터 0.7~1.1배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: 핵심 형상 준비 → 시전자 중심 확장 → 피해 판정과 가까운 절정 프레임 → 잔광/파편 소멸.
- 판정 정렬: 피해 판정 직후 CAST_VFX 시작. 별도 지연 피해나 전용 피격 VFX 필드는 현재 없다.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘점액 방울’, 보조 효과 1개는 ‘탄성 튐선’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 출력 프로필

- profile: `LOW_ACTIVE`
- VFX: 8 frames, 각 256×256 RGBA PNG, 약 0.10 sec/frame
- 동일 캔버스·동일 기준축·우측 기준·one-shot
- ICON: 256×256 RGBA PNG 1장


- 주 VFX 납품물: F00, F01, F02 ... 순서의 프레임 분리형 개별 RGBA PNG가 필수다.
- contact sheet 또는 sprite sheet는 선택적 검수 미리보기일 뿐이며 주 납품물로 인정하지 않는다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## V2.2 현행 런타임·납품 계약

- actual_motion: 플레이어는 즉시 시전자 중심 원형 피해 판정 뒤 CAST한다. 몬스터는 축소 반경 판정이 실제 명중한 경우 CAST한다. 지연 레이어는 SpawnLayer 실행 시점의 시전자 좌표를 읽고, 스폰 뒤에는 맵 엔티티로 drift가 적용된다. L1 delay=0s duration=0.62s offset=(0.18,0)wu drift=(0.35,0)wu/s; L2 delay=0.12s duration=0.52s offset=(0.5,0)wu drift=(0,0)wu/s.
- runtime_effect: AREA_MANIFEST의 확정 기획 효과와 현행 비투사체 실행 경로를 따른다.
- required_roles: `APPROVED_REUSE`
- replacement_target_fields: `none`
- generation_ready: `READY_REUSE`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: AREA 00 승인 VFX/ICON 바이트 재사용
- generation_required: false
- runtime_use: approved_existing
- 새 그림 생성·교체 금지. approved_reuse/AREA_00의 파일과 해시를 유지한다.
- RUNTIME_VALIDATION과 ART_APPROVAL은 AREA 00 승인 기록을 인용하며 V2.2에서 재실행하지 않는다.
