# Runtime Role Map — m_jr_yeti / s_mon_jr_yeti

## Current V2.2 contract

- confirmed design effect (preserved): 보유만 해도 STR +1; 중복 1장당 +0.25, 5장 최대 +2
- runtime_effect: 보유 수량 기반 STR 컬렉션 포인트 계산 후보. GameDataVerify/PlayerStats 지원 여부는 별도 런타임 상태를 따른다.
- actual_motion: CAST 호출 없음. PlayerStats가 보유 수량을 읽어 스탯을 계산한다. REFERENCE_VFX는 제작 검수용이며 runtime_use=false다.
- required_roles: `REFERENCE_VFX|ICON`
- replacement_target_fields: `none|icon_ruid`
- generation_ready: `READY`

- 역할: REFERENCE_VFX + ICON
- runtime_use: false (REFERENCE_VFX) / ui (ICON)
- REFERENCE_VFX 필요 파일: `VFX/F00...F05.png`, 6장 × 256×256 RGBA, 0.10s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- REFERENCE_VFX는 labeled preview에서만 one-shot으로 재생해 소재·리듬을 검수한다. SkillTable CAST/effect/layer 필드에 자동 연결하지 않는다.
- 보유 효과는 PlayerStats 계산 경로이며 그림 재생과 분리한다.
- 반복/좌표/FlipX: 런타임 미사용이므로 적용하지 않는다. Preview 안에서만 동일 캔버스·중심축을 유지한다.

## Coordinate and timing evidence

- CAST delay가 0보다 크면 Timer가 끝난 뒤 SpawnLayer가 그 순간의 caster.WorldPosition을 읽는다 (`SkillEffect.mlua:55-60,83-94`).
- 스폰된 CAST는 맵 엔티티이며 이후 SkillCastEffect가 drift를 적용한다. 시전자 추적 부착물이 아니다.
- PROJECTILE은 `SkillProjectile`이 위치 보간과 ZRotation을 수행한다. PROJECTILE 경로에는 FlipX 또는 진행 방향 자동 정렬 코드가 없다.
- `skill.range`는 targeting 거리이고 투사체 착탄 피해 반경은 GameBalance `projectile_hit_radius=0.8`다.
