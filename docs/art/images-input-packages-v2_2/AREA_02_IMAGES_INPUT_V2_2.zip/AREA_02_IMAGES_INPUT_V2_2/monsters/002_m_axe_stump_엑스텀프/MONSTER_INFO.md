# Monster Reference — 엑스텀프

- 작업 순번: 002
- level: 18
- Area: `area_02` / 페리온
- monster_id: `m_axe_stump`
- model_id: `axestump`
- image RUID: `9d4f9e8f572548f692438ffa817eb52d`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_axe_stump`
- skill name/type: 도끼 휘두르기 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/AxeStump.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `97f514160b2848d2a2352fa8b5ba0f0521df49f3edc99c7a4a47479b55b656e7`
- image: 320×240 RGBA / alpha 0~255 / bbox [60, 0, 261, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
