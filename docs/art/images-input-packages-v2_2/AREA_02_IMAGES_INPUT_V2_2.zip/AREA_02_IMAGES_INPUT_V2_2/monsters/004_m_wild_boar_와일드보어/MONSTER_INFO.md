# Monster Reference — 와일드보어

- 작업 순번: 004
- level: 26
- Area: `area_02` / 페리온
- monster_id: `m_wild_boar`
- model_id: `wildboar`
- image RUID: `af64c62c1dcf427998c3c52f0a060fec`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_wild_boar`
- skill name/type: 저돌 맹진 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/WildBoar.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `f620027b677baa72da586d2a6b6447fdb2ad2ea055a9f2e062bba4e0588ff7da`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 43, 315, 214]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
