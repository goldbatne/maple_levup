# Monster Reference — 스톤골렘

- 작업 순번: 001
- level: 10
- Area: `area_02` / 페리온
- monster_id: `m_stone_golem`
- model_id: `stone_golem`
- image RUID: `23761b84fca14bbfa671436791e4e0bb`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_stone`
- skill name/type: 암석 피부 / 버프

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/StoneGolem.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `7cf9ac67709238b811d84b7a308bfa31822483745393c24d6559e2f7ac9549ff`
- image: 320×240 RGBA / alpha 0~255 / bbox [24, 0, 296, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
