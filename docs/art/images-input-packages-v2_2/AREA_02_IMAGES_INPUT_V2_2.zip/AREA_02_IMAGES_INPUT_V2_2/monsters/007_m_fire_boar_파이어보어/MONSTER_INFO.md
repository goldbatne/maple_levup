# Monster Reference — 파이어보어

- 작업 순번: 007
- level: 32
- Area: `area_02` / 페리온
- monster_id: `m_fire_boar`
- model_id: `fireboar`
- image RUID: `67523b05f66f470cb86b2c6cc46af861`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_fire_boar`
- skill name/type: 화염 돌풍 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/FireBoar.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `9111fb8531c9843f11494aaf250206a17e61b285f6923ea10788b492e6429202`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 32, 318, 227]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
