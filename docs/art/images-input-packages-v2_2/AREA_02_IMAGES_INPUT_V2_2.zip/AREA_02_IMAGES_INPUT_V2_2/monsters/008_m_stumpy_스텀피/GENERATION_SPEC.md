# GENERATION SPEC — 스텀피 / 고목의 생기탄

## 확정 데이터

- 작업 순번: 008
- 레벨: 42
- Area: `area_02` / 페리온
- monster_id: `m_stumpy`
- 몬스터 이름: 스텀피
- monster image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- skill_id: `s_mon_stumpy`
- 최종 스킬 이름: **고목의 생기탄**
- 스킬 타입: **액티브**
- 보스 여부: 보스
- 확정 기획 효과(보존 원문): INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- 확인된 런타임 효과: INT 계수 1.9; skill.range=5wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- 확인된 런타임 동작: skill.range=5wu는 플레이어 조준 거리이며 몬스터 사용 시 3.335wu로 대상 탐색한다. projectile_ruid c6b3f052e977479ea5ad5329ce0981ca를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. CAST 레이어 없음.

## 원작/지역 연결

[P][A] 고목형 몬스터와 생기는 연결 가능하나 ‘빼앗은 생기’와 생기탄은 확인되지 않았다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.

## 시각 번역

- 핵심 소재: 고목 나이테에서 싹이 돋아 응축된 생기탄. 몬스터 본체는 넣지 않는다.
- 주 색상: 고목 갈색 #75533A / 보조 색상: 생기 연두 #8ED35B.
- 효과 발생 위치: 움직이는 projectile entity의 로컬 중심.
- 진행 방향: 원화 자체는 방향 중립. 엔진은 위치 보간과 Z축 회전만 하며 FlipX·진행 방향 자동 정렬은 하지 않는다.
- 대상 표현: 타깃 캐릭터와 조준 범위를 이미지에 넣지 않는다. 전용 IMPACT VFX도 만들지 않는다.
- 화면 점유율: 핵심 소재 70%, 외곽 파편 85% 이내. 이펙트 밀도는 보스 체급이되 투사체 실루엣을 흐리지 않는다.
- 시간 흐름: F00 응축 → F01 발광 상승 → F02 절정 → F03 안정/잔광. 0.32초 안에 한 번 완결된다.
- 아이콘 핵심 모티브: 싹튼 나이테 + 작은 생기 코어. 64px에서도 두 형상이 읽혀야 한다.

## 출력 프로필

- profile: `BOSS_PROJECTILE_V2_2`
- PROJECTILE: 4 frames, 각 512×512 RGBA PNG, 정확히 0.08 sec/frame (총 0.32초)
- 동일 캔버스·동일 기준축·방향 중립·non-loop one-shot
- ICON: 256×256 RGBA PNG 1장
- 주 납품물은 PROJECTILE/F00...F03 개별 PNG다. contact sheet는 선택 검수물일 뿐이다.

## V2.2 현행 런타임·납품 계약

- actual_motion: skill.range=5wu는 플레이어 조준 거리이며 몬스터 사용 시 3.335wu로 대상 탐색한다. projectile_ruid c6b3f052e977479ea5ad5329ce0981ca를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. CAST 레이어 없음.
- runtime_effect: INT 계수 1.9; skill.range=5wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- required_roles: `PROJECTILE|ICON`
- replacement_target_fields: `projectile_ruid|icon_ruid`
- generation_ready: `READY`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: PROJECTILE + ICON. CAST_VFX는 만들지 않는다.
- current fields: effect_ruid 비어 있음 / layer_ruids 비어 있음 / projectile_ruid=`c6b3f052e977479ea5ad5329ce0981ca`
- PROJECTILE 교체 대상: `projectile_ruid`
- PROJECTILE 필요 파일: `PROJECTILE/F00.png`~`PROJECTILE/F03.png`, 4장 × 512×512 RGBA, 0.08s/frame
- 재생 계약: non-loop one-shot 4×0.08=0.32초를 0.35초 엔티티 수명 안에 완전 재생한다. 0.03초는 프레임/삭제 경계 여유이며 비행시간·피해시점은 변경하지 않는다.
- 실제 모델/코드는 AnimationClip 재생속도·Loop·FlipX를 설정하지 않는다. 반입 시 AnimationClip 자체를 0.08s/frame non-loop로 구성해야 하며 이는 RUNTIME_VALIDATION 대상이다.
- 엔진 동작: 시전자+h→목표+h 위치 보간과 ZRotation만 수행한다. 진행 방향 자동 정렬과 FlipX는 없다.
- 원화 동작: 캔버스 중심에서 형태 변화·맥동만 표현하고 캔버스 안 좌→우 이동이나 방향 자동 정렬을 가정하지 않는다.
- 착탄: 0.35초 뒤 반경 0.8wu 판정. 전용 IMPACT 파일/필드는 없다.
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA.
