# Runtime Role Map — m_stumpy / s_mon_stumpy

## Current V2.2 contract

- confirmed design effect (preserved): INT 계수 1.9로 반경 5 범위 대상 제한 없음 피해; 7초 재사용; 5장 보유 시 계수 ×1.8
- runtime_effect: INT 계수 1.9; skill.range=5wu는 조준/탐색 거리; 0.35초 뒤 착탄점 반경 0.8wu에서 제한 없음 피해 판정.
- actual_motion: skill.range=5wu는 플레이어 조준 거리이며 몬스터 사용 시 3.335wu로 대상 탐색한다. projectile_ruid c6b3f052e977479ea5ad5329ce0981ca를 시전자+h에서 목표+h로 0.35초 동안 이동·Z회전시킨 뒤, 착탄점 반경 0.8wu에서 최대 제한 없음 피해를 판정한다. CAST 레이어 없음.
- required_roles: `PROJECTILE|ICON`
- replacement_target_fields: `projectile_ruid|icon_ruid`
- generation_ready: `READY`

- 역할: PROJECTILE + ICON. CAST_VFX는 만들지 않는다.
- current fields: effect_ruid 비어 있음 / layer_ruids 비어 있음 / projectile_ruid=`c6b3f052e977479ea5ad5329ce0981ca`
- PROJECTILE 교체 대상: `projectile_ruid`
- PROJECTILE 필요 파일: `PROJECTILE/F00.png`~`PROJECTILE/F03.png`, 4장 × 512×512 RGBA, 0.08s/frame
- 재생 계약: non-loop one-shot 4×0.08=0.32초를 0.35초 엔티티 수명 안에 완전 재생한다. 0.03초는 프레임/삭제 경계 여유이며 비행시간·피해시점은 변경하지 않는다.
- 실제 모델/코드는 AnimationClip 재생속도·Loop·FlipX를 설정하지 않는다. 반입 시 AnimationClip 자체를 0.08s/frame non-loop로 구성해야 하며 이는 RUNTIME_VALIDATION 대상이다.
- 엔진 동작: 시전자+h→목표+h 위치 보간과 ZRotation만 수행한다. 진행 방향 자동 정렬과 FlipX는 없다.
- 원화 동작: 캔버스 중심에서 형태 변화·맥동만 표현하고 캔버스 안 좌→우 이동이나 방향 자동 정렬을 가정하지 않는다.
- 착탄: 0.35초 뒤 반경 0.8wu 판정. 전용 IMPACT 파일/필드는 없다.
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA.

## Coordinate and timing evidence

- CAST delay가 0보다 크면 Timer가 끝난 뒤 SpawnLayer가 그 순간의 caster.WorldPosition을 읽는다 (`SkillEffect.mlua:55-60,83-94`).
- 스폰된 CAST는 맵 엔티티이며 이후 SkillCastEffect가 drift를 적용한다. 시전자 추적 부착물이 아니다.
- PROJECTILE은 `SkillProjectile`이 위치 보간과 ZRotation을 수행한다. PROJECTILE 경로에는 FlipX 또는 진행 방향 자동 정렬 코드가 없다.
- `skill.range`는 targeting 거리이고 투사체 착탄 피해 반경은 GameBalance `projectile_hit_radius=0.8`다.
