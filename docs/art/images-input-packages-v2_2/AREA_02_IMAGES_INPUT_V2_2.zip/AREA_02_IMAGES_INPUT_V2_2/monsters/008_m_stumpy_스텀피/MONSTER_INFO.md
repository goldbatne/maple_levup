# Monster Reference — 스텀피

- 작업 순번: 008
- level: 42
- Area: `area_02` / 페리온
- monster_id: `m_stumpy`
- model_id: `stumpy`
- image RUID: `0b6c2f6faccc44da980ce832ab636bf6`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_stumpy`
- skill name/type: 고목의 생기탄 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/Stumpy.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `7cbcf6f7464dc68bb746457f71ef78b181eae6994dd5b996a298c93dda84d906`
- image: 320×240 RGBA / alpha 0~255 / bbox [36, 2, 281, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
