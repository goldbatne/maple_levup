# Monster Reference — 다크 엑스텀프

- 작업 순번: 003
- level: 22
- Area: `area_02` / 페리온
- monster_id: `m_dark_axe_stump`
- model_id: `darkaxestump`
- image RUID: `fd35894dd92c4e3b8885e59b0f4d3394`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_dark_axe_stump`
- skill name/type: 어둠의 뿌리 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/DarkAxeStump.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `bc28759834980bad44a132869de416eb5929df3b9ab777b42a5e4b0d14fa9671`
- image: 320×240 RGBA / alpha 0~255 / bbox [60, 0, 261, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
