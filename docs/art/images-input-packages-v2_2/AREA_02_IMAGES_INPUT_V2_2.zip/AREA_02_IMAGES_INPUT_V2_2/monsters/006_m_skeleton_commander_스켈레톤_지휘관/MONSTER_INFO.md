# Monster Reference — 스켈레톤 지휘관

- 작업 순번: 006
- level: 30
- Area: `area_02` / 페리온
- monster_id: `m_skeleton_commander`
- model_id: `skeletoncommander`
- image RUID: `ed882269a5d543318ad73e7032632960`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_skeleton_commander`
- skill name/type: 뼈 무덤 / 액티브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/SkeletonCommander.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `8cabfe4d200a728c9ab615b8f6a1618b6502f8ed19a8f457483d5a3b896af31f`
- image: 320×240 RGBA / alpha 0~255 / bbox [53, 3, 268, 240]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
