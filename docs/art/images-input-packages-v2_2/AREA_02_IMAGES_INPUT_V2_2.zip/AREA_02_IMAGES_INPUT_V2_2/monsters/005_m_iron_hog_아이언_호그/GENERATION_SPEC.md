# GENERATION SPEC — 아이언 호그 / 강철 발굽

## 확정 데이터

- 작업 순번: 005
- 레벨: 28
- Area: `area_02` / 페리온
- monster_id: `m_iron_hog`
- 몬스터 이름: 아이언 호그
- monster image RUID: `eadfe08070d343a9afafe0fd6290f1c6`
- skill_id: `s_mon_iron_hog`
- 최종 스킬 이름: **강철 발굽**
- 스킬 타입: **패시브**
- 보스 여부: 일반 몬스터
- 확정 기획 효과(보존 원문): 보유만 해도 DEX +1; 중복 1장당 +0.25, 5장 최대 +2
- 확인된 런타임 효과: 보유 수량 기반 DEX 컬렉션 포인트 계산 후보. GameDataVerify/PlayerStats 지원 여부는 별도 런타임 상태를 따른다.
- 확인된 런타임 동작: CAST 호출 없음. PlayerStats가 보유 수량을 읽어 스탯을 계산한다. REFERENCE_VFX는 제작 검수용이며 runtime_use=false다.

## 원작/지역 연결

[P][A] 현행 모델/방 배치에서 아이언 호그의 모델 ID·RUID와 페리온 배치를 확인했다. 스킬명은 몬스터 고유명·종족명 또는 지역 핵심어를 직접 사용한다. 원작의 공식 스킬명으로 확인된 것은 아니다.

## 시각 번역

- 핵심 소재: 철제 발굽이 지면을 찍는 반달 충격과 쇳가루. ‘아이언 호그 / 강철 발굽’ 전용 소재이며 몬스터 본체는 VFX에 직접 넣지 않음
- 주 색상: 강철 청회 #64798A; 핵심 실루엣의 중간톤과 어두운 외곽에 사용
- 보조 색상: 충돌 백황 #E8D28A; 타격 코어·잔상·소수 입자에만 사용해 같은 Area의 다른 몬스터와 구분
- 런타임 역할: ICON=런타임 필수; REFERENCE_VFX=기존 제작 범위에 포함된 비전투 참고 산출물(런타임 미사용·자동 반입 금지)
- 효과 발생 위치: 런타임 시전자/발생점 없음. PlayerStats와 UI가 보유 수를 읽고 정액 스탯을 적용한다.
- 진행 방향·엔진 이동: 방향·FlipX·엔진 이동 없음. 없음
- 대상 표현: 런타임 대상 없음. 아이콘은 보유 효과를 식별하는 UI 자산이며 몬스터 본체 전체를 넣지 않는다.
- 화면 점유율: 작음(캐릭터 몸통의 0.5~0.8배); 핵심 소재 전체가 캔버스 안전영역 70% 안에 들고 외곽 파편은 85%를 넘지 않음
- 이펙트 밀도: 낮음; 대표 형상 1개, 보조 궤적/층 1~3개, 식별용 파편 3~7개만 사용
- 시간 흐름: REFERENCE_VFX를 만들 경우 정지 모티브의 짧은 호흡만 표현한다. 공격 준비·타격광·투사체·폭발 단계는 넣지 않는다.
- 판정 정렬: 피해 판정·시전·재생시간·반복 없음.
- 아이콘 핵심 모티브: 대표 실루엣 1개는 ‘강철 발굽’, 보조 효과 1개는 ‘지면 충격선’. 64px 축소에서도 두 형상의 겹침과 방향이 읽혀야 함
- 몬스터 본체 금지 범위: 몸·얼굴·전신 실루엣은 VFX에 넣지 않는다. 다만 확정 핵심 소재인 인형·손자국·가면·껍질·뿔·장비 파편은 해당 명세대로 유지한다.

## 해석 주의

- 확정 스킬명·타입·효과·동작을 바꾸지 않는다.
- 몬스터 본체를 VFX 안에 직접 그리지 않는다.
- 기존 플레이어 스킬의 무기·캐릭터·실루엣을 복제하지 않는다.
- 현행 패시브에는 런타임 VFX가 없다. VFX 결과는 비전투 참고 모티브로 표시하고 자동 반입하지 않는다.

## 출력 프로필

- profile: `PASSIVE_REFERENCE_ONLY`
- REFERENCE_VFX: 6 frames, 각 256×256 RGBA PNG, 약 0.10 sec/frame
- runtime_use=false. labeled preview에서만 one-shot으로 재생한다.
- ICON: 256×256 RGBA PNG 1장
- 주 납품물은 VFX/F00... 개별 PNG와 ICON이다. CAST_VFX 납품물은 없다.

## V2.2 현행 런타임·납품 계약

- actual_motion: CAST 호출 없음. PlayerStats가 보유 수량을 읽어 스탯을 계산한다. REFERENCE_VFX는 제작 검수용이며 runtime_use=false다.
- runtime_effect: 보유 수량 기반 DEX 컬렉션 포인트 계산 후보. GameDataVerify/PlayerStats 지원 여부는 별도 런타임 상태를 따른다.
- required_roles: `REFERENCE_VFX|ICON`
- replacement_target_fields: `none|icon_ruid`
- generation_ready: `READY`
- 몬스터별 `PREVIEW/labeled_preview.png`와 Area 루트 `AREA_OVERVIEW_PREVIEW.png`는 필수 검수물이다.
- 별도 contact sheet는 선택 검수물이며 위 두 Preview를 대체하지 않는다.
- 동일 캔버스·중심축·실제 alpha를 유지하고 autocrop/recenter하지 않는다.

- 역할: REFERENCE_VFX + ICON
- runtime_use: false (REFERENCE_VFX) / ui (ICON)
- REFERENCE_VFX 필요 파일: `VFX/F00...F05.png`, 6장 × 256×256 RGBA, 0.10s/frame
- ICON 필요 파일: `ICON/icon.png`, 256×256 RGBA
- REFERENCE_VFX는 labeled preview에서만 one-shot으로 재생해 소재·리듬을 검수한다. SkillTable CAST/effect/layer 필드에 자동 연결하지 않는다.
- 보유 효과는 PlayerStats 계산 경로이며 그림 재생과 분리한다.
- 반복/좌표/FlipX: 런타임 미사용이므로 적용하지 않는다. Preview 안에서만 동일 캔버스·중심축을 유지한다.
