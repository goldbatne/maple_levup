# Monster Reference — 아이언 호그

- 작업 순번: 005
- level: 28
- Area: `area_02` / 페리온
- monster_id: `m_iron_hog`
- model_id: `ironhog`
- image RUID: `eadfe08070d343a9afafe0fd6290f1c6`
- image status: **확보**
- image format: 320×240 RGBA PNG
- alpha range: 0~255
- skill_id: `s_mon_iron_hog`
- skill name/type: 강철 발굽 / 패시브

MONSTER_IMAGE는 외형·색상·실루엣·부위 특징을 이해하기 위한 레퍼런스다. 최종 VFX에 몬스터 본체를 그대로 넣지 않는다.

## V2 source check

- model file: `RootDesk/MyDesk/Models/Monsters/IronHog.model`
- model SpriteRUID match: PASS
- MONSTER_IMAGE SHA-256: `e4e177dba66f1983033b94e7a3755c641e6d9e96eeeed54c358d651a482f8f10`
- image: 320×240 RGBA / alpha 0~255 / bbox [0, 12, 320, 228]
- 원 다운로드 원본/선택 프레임 메타데이터는 기존 패키지에 남아 있지 않아 미확인이다. 해시 일치만으로 몬스터 적합성을 주장하지 않는다.
