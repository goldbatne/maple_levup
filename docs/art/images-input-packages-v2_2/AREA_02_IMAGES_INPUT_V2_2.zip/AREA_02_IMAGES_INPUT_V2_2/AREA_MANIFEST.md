# AREA MANIFEST — V2.2

`actual_effect`는 V2.1의 확정 기획/CSV 설명을 바이트 의미상 보존한 값이며 런타임 반경 설명이 아니다. 실제 실행은 `runtime_effect`, `targeting_range`, `impact_radius`, `impact_delay`, `max_targets` 열을 따른다.

| order | monster_id | skill_id | type | required roles | target fields | generation | runtime |
|---:|---|---|---|---|---|---|---|
| 1 | `m_stone_golem` | `s_mon_stone` | 버프 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 2 | `m_axe_stump` | `s_mon_axe_stump` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 3 | `m_dark_axe_stump` | `s_mon_dark_axe_stump` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 4 | `m_wild_boar` | `s_mon_wild_boar` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 5 | `m_iron_hog` | `s_mon_iron_hog` | 패시브 | REFERENCE_VFX|ICON | none|icon_ruid | READY | NOT_RUN |
| 6 | `m_skeleton_commander` | `s_mon_skeleton_commander` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 7 | `m_fire_boar` | `s_mon_fire_boar` | 액티브 | CAST_VFX|ICON | layer_ruids|icon_ruid | READY | NOT_RUN |
| 8 | `m_stumpy` | `s_mon_stumpy` | 액티브 | PROJECTILE|ICON | projectile_ruid|icon_ruid | READY | NOT_RUN |

## Projectile runtime fields

| monster_id | skill_id | data range | player targeting | monster targeting | impact radius | delay | max targets |
|---|---|---:|---:|---:|---:|---:|---|
| `m_stumpy` | `s_mon_stumpy` | 5 | 5 | 3.335 | 0.8 | 0.35 | unlimited |
