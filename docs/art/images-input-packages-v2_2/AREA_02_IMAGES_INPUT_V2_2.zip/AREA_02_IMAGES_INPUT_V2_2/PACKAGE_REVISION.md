# Package Revision V2

```json
{
  "revision": "V2",
  "base_zip": "docs/art/images-input-packages/AREA_02_IMAGES_INPUT.zip",
  "base_zip_sha256": "c5199249151a782eb2cf23798738bb7bcc982dc43236482583fa1fcd852290ee",
  "area_id": "area_02",
  "area_name": "페리온",
  "scope": "INPUT 문서·검증·재사용 파일 보정만; 게임 데이터/아트/리소스 미변경",
  "skill_table_source": {
    "source": "git:HEAD:RootDesk/MyDesk/GameData/SkillTable.csv",
    "state": "HEAD_fallback_working_file_missing",
    "sha256": "f0cb65e6390c3f154d91abbcc622b76c93aa1ca8bf0baf81d57bfe8f3b0f0d69"
  },
  "status": "READY",
  "unresolved": []
}
```
